import { useState } from "react";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight, TrendingUp } from "lucide-react";
import ProductCard from "./ProductCard";

import smartSwitchImg from "@/assets/smart-switch.jpg";
import smartPlugImg from "@/assets/smart-plug.jpg";
import ledStripImg from "@/assets/led-strip.jpg";
import smartControllerImg from "@/assets/smart-controller.jpg";

// Error boundary component to catch ProductCard errors
const ErrorBoundary = ({ children }) => {
  try {
    return children;
  } catch (error) {
    console.error("Error in ProductCard:", error);
    return <div>Error rendering product card. Check console for details.</div>;
  }
};

const BestSelling = () => {
  const [startIndex, setStartIndex] = useState(0);
  const [isRTL, setIsRTL] = useState(false); // Set to true for RTL or use document.dir

  // Mock products data - 8 products for multiple slides
  const products = [
    {
      id: "1",
      name: "Halox Smart Touch Switch 4-Way",
      price: 1299,
      originalPrice: 1699,
      rating: 4.8,
      image: smartSwitchImg,
      category: "Smart Switches",
      isBestSeller: true,
      isOnSale: true,
      features: ["WiFi", "Smart Control"],
    },
    {
      id: "2",
      name: "Halox Smart Plug 16A Heavy Duty",
      price: 899,
      originalPrice: 1199,
      rating: 4.7,
      image: smartPlugImg,
      category: "Smart Plugs",
      isBestSeller: true,
      isOnSale: true,
      features: ["WiFi", "Power Monitoring"],
    },
    {
      id: "3",
      name: "Halox RGB LED Strip 5m",
      price: 2499,
      originalPrice: 3499,
      rating: 4.9,
      image: ledStripImg,
      category: "LED Strips",
      isBestSeller: false,
      isOnSale: true,
      features: ["WiFi", "16M Colors"],
    },
    {
      id: "4",
      name: "Halox Smart Fan Controller",
      price: 1899,
      originalPrice: 2499,
      rating: 4.6,
      image: smartControllerImg,
      category: "Controllers",
      isBestSeller: false,
      isOnSale: false,
      features: ["WiFi", "Speed Control"],
    },
    {
      id: "5",
      name: "Halox Smart Bulb",
      price: 799,
      originalPrice: 999,
      rating: 4.5,
      image: smartSwitchImg,
      category: "Smart Bulbs",
      isBestSeller: false,
      isOnSale: false,
      features: ["WiFi", "Dimmable"],
    },
    {
      id: "6",
      name: "Halox Smart Camera",
      price: 2999,
      originalPrice: 3999,
      rating: 4.4,
      image: smartPlugImg,
      category: "Security",
      isBestSeller: false,
      isOnSale: false,
      features: ["WiFi", "Night Vision"],
    },
    {
      id: "7",
      name: "Halox Smart Thermostat",
      price: 3999,
      originalPrice: 4999,
      rating: 4.3,
      image: smartControllerImg,
      category: "Controllers",
      isBestSeller: false,
      isOnSale: false,
      features: ["WiFi", "Temperature Control"],
    },
    {
      id: "8",
      name: "Hal at 06:28 PM IST on Wednesday, August 13, 2025. ox Smart Doorbell",
      price: 4999,
      originalPrice: 5999,
      rating: 4.2,
      image: smartSwitchImg,
      category: "Security",
      isBestSeller: false,
      isOnSale: false,
      features: ["WiFi", "Motion Detection"],
    },
  ];

  const itemsPerPage = 4; // Show 4 cards at a time on large screens
  const maxIndex = Math.max(0, products.length - itemsPerPage); // Ensure non-negative

  // Handle next button click (slides right to left)
  const nextSlide = () => {
    console.log("Next clicked, startIndex:", startIndex);
    if (startIndex < maxIndex) {
      setStartIndex((prev) => prev + 1);
    }
  };

  // Handle previous button click (slides left to right)
  const prevSlide = () => {
    console.log("Previous clicked, startIndex:", startIndex);
    if (startIndex > 0) {
      setStartIndex((prev) => prev - 1);
    }
  };

  // Calculate transform for smooth scrolling
  const transform = isRTL
    ? `translateX(${startIndex * (100 / itemsPerPage)}%)`
    : `translateX(-${startIndex * (100 / itemsPerPage)}%)`;

  // Debugging: Log rendering
  console.log("Rendering BestSelling, startIndex:", startIndex, "products:", products.length);

  return (
    <section className="py-16 bg-gradient-card">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <div className="text-center space-y-4 mb-12">
          <div className="flex items-center justify-center gap-2 mb-4">
            <TrendingUp className="h-6 w-6 text-secondary" />
            <span className="text-secondary font-semibold uppercase tracking-wide text-sm">
              Best Sellers
            </span>
          </div>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-display font-bold text-foreground text-green-600">
            Customer Favorites
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Discover our most loved smart home devices that are making Indian homes smarter every day.
          </p>
        </div>

        {/* Products Carousel */}
        <div className="relative overflow-hidden">
          {/* Navigation Buttons (Top Right) */}
          <div className="absolute top-0 right-0 flex gap-2 z-10">
            <Button
              variant="outline"
              size="icon"
              onClick={prevSlide}
              disabled={startIndex === 0}
              className="rounded-full bg-blue-500 text-white hover:bg-blue-600 disabled:opacity-50 border-none"
              aria-label="Previous Card"
            >
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <Button
              variant="outline"
              size="icon"
              onClick={nextSlide}
              disabled={startIndex >= maxIndex}
              className="rounded-full bg-blue-500 text-white hover:bg-blue-600 disabled:opacity-50 border-none"
              aria-label="Next Card"
            >
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>

          {/* Products Container */}
          <div
            className="flex transition-transform duration-300 ease-in-out"
            style={{ transform }}
          >
            {products.map((product) => (
              <div
                key={product.id}
                className="flex-none w-full sm:w-1/2 lg:w-1/4 px-3"
              >
                <ErrorBoundary>
                  <ProductCard {...product} />
                </ErrorBoundary>
              </div>
            ))}
          </div>

          {/* Navigation Buttons (Mobile) */}
          <div className="flex md:hidden justify-center gap-2 mt-8">
            <Button
              variant="outline"
              size="sm"
              onClick={prevSlide}
              disabled={startIndex === 0}
              className="bg-blue-500 text-white hover:bg-blue-600 disabled:opacity-50 border-none"
            >
              <ChevronLeft className="h-4 w-4 mr-1" />
              Previous
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={nextSlide}
              disabled={startIndex >= maxIndex}
              className="bg-blue-500 text-white hover:bg-blue-600 disabled:opacity-50 border-none"
            >
              Next
              <ChevronRight className="h-4 w-4 ml-1" /> 
            </Button>
          </div>

          {/* Slide Indicators */}
          <div className="flex justify-center gap-2 mt-8">
            {[...Array(products.length - itemsPerPage + 1)].map((_, index) => (
              <button
                key={index}
                onClick={() => setStartIndex(index)}
                className={`w-2 h-2 rounded-full transition-all duration-300 ${
                  index === startIndex
                    ? "bg-blue-500 w-8"
                    : "bg-muted-foreground/30"
                }`}
                aria-label={`Go to card ${index + 1}`}
              />
            ))}
          </div>
        </div>

        {/* CTA */}
        <div className="text-center mt-12">
          <Button size="lg" variant="outline" className="font-semibold">
            View All Products
            <ChevronRight className="ml-2 h-4 w-4" />
          </Button>
        </div>
      </div>
    </section>
  );
};

export default BestSelling;