import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Shield, MapPin, Lock, Users, CheckCircle, X, Zap } from "lucide-react";

const IndianPrivacy = () => {
  const comparisonData = [
    {
      feature: "Data Storage Location",
      halox: "India 🇮🇳",
      foreign: "China/USA",
      haloxIcon: MapPin,
      foreignIcon: X
    },
    {
      feature: "Government Compliance",
      halox: "Full Compliance",
      foreign: "Limited",
      haloxIcon: CheckCircle,
      foreignIcon: X
    },
    {
      feature: "User Data Control",
      halox: "Complete Control",
      foreign: "Restricted",
      haloxIcon: Lock,
      foreignIcon: X
    },
    {
      feature: "Local Support",
      halox: "24/7 Indian Support",
      foreign: "Outsourced",
      haloxIcon: Users,
      foreignIcon: X
    }
  ];

  return (
    <section className="py-16 bg-gradient-to-br from-primary/5 via-background to-accent/5">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <div className="text-center space-y-4 mb-12">
          <div className="flex items-center justify-center gap-2 mb-4">
            <Shield className="h-6 w-6 text-accent" />
            <Badge className="bg-secondary/10 text-secondary border-secondary/20">
              Made in India
            </Badge>
          </div>
          
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-display font-bold text-foreground">
            Indian Brand with
            <span className="block text-accent">Strong Privacy</span>
          </h2>
          
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Built in India, for India. Your data stays secure within Indian borders with full compliance and transparency.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Content - Brand Story */}
          <div className="space-y-8">
            <div className="space-y-6">
              <div className="flex items-center gap-4 p-4 bg-gradient-card rounded-xl border border-border/50">
                <div className="bg-secondary/10 p-3 rounded-lg">
                  <MapPin className="h-6 w-6 text-secondary" />
                </div>
                <div>
                  <h3 className="font-semibold text-foreground">Built in India. Built for India.</h3>
                  <p className="text-sm text-muted-foreground">Proudly developed by Indian engineers</p>
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <CheckCircle className="h-5 w-5 text-accent" />
                  <span className="text-foreground">Data hosted in Indian servers only</span>
                </div>
                <div className="flex items-center gap-3">
                  <CheckCircle className="h-5 w-5 text-accent" />
                  <span className="text-foreground">No Chinese cloud dependency</span>
                </div>
                <div className="flex items-center gap-3">
                  <CheckCircle className="h-5 w-5 text-accent" />
                  <span className="text-foreground">Full user control over privacy settings</span>
                </div>
                <div className="flex items-center gap-3">
                  <CheckCircle className="h-5 w-5 text-accent" />
                  <span className="text-foreground">Transparent data usage policies</span>
                </div>
              </div>
            </div>

            <div className="bg-gradient-to-r from-secondary/10 via-transparent to-accent/10 p-6 rounded-xl border border-secondary/20">
              <div className="flex items-center gap-3 mb-3">
                <Shield className="h-5 w-5 text-secondary" />
                <span className="font-semibold text-foreground">Privacy Guarantee</span>
              </div>
              <p className="text-sm text-muted-foreground">
                "We believe your smart home data belongs to you, not to us. That's why we've built 
                our infrastructure with privacy-by-design principles."
              </p>
              <p className="text-xs text-muted-foreground mt-2 font-medium">
                - Halox Privacy Team
              </p>
            </div>
          </div>

          {/* Right Content - Comparison Table */}
          <div className="space-y-6">
            <Card className="overflow-hidden">
              <CardContent className="p-0">
                {/* Table Header */}
                <div className="grid grid-cols-3 bg-muted/50">
                  <div className="p-4 text-center">
                    <span className="text-sm font-semibold text-muted-foreground">Feature</span>
                  </div>
                  <div className="p-4 text-center bg-primary/10 border-l border-r border-border/50">
                    <div className="flex items-center justify-center gap-2">
                      <Zap className="h-4 w-4 text-primary" />
                      <span className="text-sm font-bold text-primary">Halox</span>
                    </div>
                  </div>
                  <div className="p-4 text-center">
                    <span className="text-sm font-semibold text-muted-foreground">Foreign Brands</span>
                  </div>
                </div>

                {/* Comparison Rows */}
                {comparisonData.map((item, index) => (
                  <div key={item.feature} className={`grid grid-cols-3 ${index % 2 === 0 ? 'bg-background' : 'bg-muted/20'}`}>
                    <div className="p-4">
                      <span className="text-sm font-medium text-foreground">{item.feature}</span>
                    </div>
                    <div className="p-4 bg-primary/5 border-l border-r border-border/50">
                      <div className="flex items-center justify-center gap-2">
                        <item.haloxIcon className="h-4 w-4 text-accent" />
                        <span className="text-sm font-semibold text-foreground">{item.halox}</span>
                      </div>
                    </div>
                    <div className="p-4">
                      <div className="flex items-center justify-center gap-2">
                        <item.foreignIcon className="h-4 w-4 text-destructive" />
                        <span className="text-sm text-muted-foreground">{item.foreign}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Trust Badges */}
            {/* <div className="grid grid-cols-2 gap-4">
              <div className="text-center p-4 bg-gradient-card rounded-lg border border-border/50">
                <Shield className="h-8 w-8 text-accent mx-auto mb-2" />
                <div className="text-sm font-semibold text-foreground">ISO 27001</div>
                <div className="text-xs text-muted-foreground">Certified</div>
              </div>
              <div className="text-center p-4 bg-gradient-card rounded-lg border border-border/50">
                <Lock className="h-8 w-8 text-primary mx-auto mb-2" />
                <div className="text-sm font-semibold text-foreground">GDPR</div>
                <div className="text-xs text-muted-foreground">Compliant</div>
              </div>
            </div> */}

            <Button size="lg" className="w-full">
              Learn About Our Privacy Policy
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default IndianPrivacy;