import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Play, Download, Zap, Shield, Users, Star, ArrowRight, Smartphone, Globe, Lock } from "lucide-react";
import { Link } from "react-router-dom";
import { useEffect, useState } from "react";

const Hero = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    setIsVisible(true);
  }, []);

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-gradient-to-br from-indigo-900 via-purple-900 to-pink-900 pt-20 pb-20">
      {/* Enhanced Background Pattern */}
      <div className="absolute inset-0">
        {/* Animated Grid Pattern */}
        <div className="absolute inset-0 bg-white/5 bg-[radial-gradient(circle_at_2px_2px,rgba(255,255,255,0.2)_2px,transparent_0)] bg-[length:30px_30px] animate-pulse opacity-50"></div>
        
        {/* Floating Orbs with Glow */}
        <div className="absolute top-10 left-10 w-48 h-48 bg-indigo-500/30 rounded-full blur-3xl animate-pulse glow-animation"></div>
        <div className="absolute bottom-10 right-10 w-64 h-64 bg-purple-500/30 rounded-full blur-3xl animate-pulse glow-animation" style={{animationDelay: "1s"}}></div>
        <div className="absolute top-1/2 left-1/4 w-32 h-32 bg-pink-500/30 rounded-full blur-2xl animate-pulse glow-animation" style={{animationDelay: "2s"}}></div>
        
        {/* Tech Circuit Lines */}
        <div className="absolute top-0 left-0 w-full h-full opacity-20">
          <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
            <path d="M0,50 Q25,25 50,50 T100,50" stroke="white" strokeWidth="0.6" fill="none" className="animate-pulse"/>
            <path d="M0,30 Q25,15 50,30 T100,30" stroke="white" strokeWidth="0.4" fill="none" className="animate-pulse" style={{animationDelay: "0.5s"}}/>
            <path d="M0,70 Q25,85 50,70 T100,70" stroke="white" strokeWidth="0.4" fill="none" className="animate-pulse" style={{animationDelay: "1s"}}/>
          </svg>
        </div>
      </div>
      
      <div className="container mx-auto px-6 relative z-10">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left Content - Enhanced */}
          <div className={`text-center lg:text-left space-y-8 transition-all duration-1000 ease-out ${
            isVisible ? 'translate-y-0 opacity-100' : 'translate-y-12 opacity-0'
          }`}>
            {/* Badge Section */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <Badge className="bg-white/20 text-white border-white/30 backdrop-blur-md hover:bg-white/30 transition-all duration-300 group">
                <Zap className="h-4 w-4 mr-2 group-hover:rotate-12 transition-transform duration-300" />
                Made in India 🇮🇳
              </Badge>
              <Badge className="bg-purple-500/20 text-purple-300 border-purple-400/30 backdrop-blur-md hover:bg-purple-500/30 transition-all duration-300 group">
                <Star className="h-4 w-4 mr-2 group-hover:scale-110 transition-transform duration-300" />
                #1 Smart Home Brand
              </Badge>
            </div>
            
            {/* Main Heading */}
            <div className="space-y-4">
              <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold text-white leading-tight tracking-tight">
                <span className="block">Smart Living,</span>
                <span className="block bg-gradient-to-r from-purple-400 via-pink-500 to-orange-400 bg-clip-text text-transparent">
                  Indian Way
                </span>
              </h1>
              
              <p className="text-xl md:text-2xl text-white/80 max-w-2xl leading-relaxed">
                Control your home with India's most trusted smart switches, plugs, and IoT devices. 
                Built with <span className="text-pink-300 font-semibold">privacy-first</span> approach and hosted in India.
              </p>
            </div>

            {/* Enhanced CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <Link to="/shop">
                <Button size="lg" className="relative overflow-hidden bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-semibold hover:from-indigo-700 hover:to-purple-700 group shadow-lg hover:shadow-xl transition-shadow duration-300">
                  <span className="relative z-10 flex items-center">
                    Shop Now
                    <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-2 transition-transform duration-300" />
                  </span>
                  <div className="absolute inset-0 bg-gradient-to-r from-pink-500/20 to-purple-500/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                </Button>
              </Link>
              
              <Button size="lg" variant="outline" className="border-white/40 bg-[#10c2e6] text-white hover:bg-white/10 hover:border-white/50 group shadow-lg hover:shadow-xl transition-all duration-300">
                <Play className="mr-2 h-5 w-5 group-hover:scale-110 transition-transform duration-300" />
                Watch Demo
              </Button>
            </div>

            {/* Enhanced App Download Section */}
            <div className="space-y-4">
              <div className="flex items-center justify-center lg:justify-start gap-2 text-white/70">
                <Smartphone className="h-5 w-5" />
                <span className="text-sm font-medium">Download the app:</span>
              </div>
              <div className="flex flex-col sm:flex-row gap-3 justify-center lg:justify-start">
                <Button variant="ghost" size="sm" className="bg-white/10 hover:bg-white/20 text-white backdrop-blur-md border border-white/20 hover:border-white/40 transition-all duration-300 group flex items-center">
                  <Download className="mr-2 h-5 w-5 group-hover:scale-110 transition-transform duration-300" />
                  <div className="text-left">
                    <div className="text-xs text-white/60">Get it on</div>
                    <div className="font-semibold">Google Play</div>
                  </div>
                </Button>
                <Button variant="ghost" size="sm" className="bg-white/10 hover:bg-white/20 text-white backdrop-blur-md border border-white/20 hover:border-white/40 transition-all duration-300 group flex items-center">
                  <Download className="mr-2 h-5 w-5 group-hover:scale-110 transition-transform duration-300" />
                  <div className="text-left">
                    <div className="text-xs text-white/60">Download on the</div>
                    <div className="font-semibold">App Store</div>
                  </div>
                </Button>
              </div>
            </div>

            {/* Trust Indicators */}
            <div className="flex flex-wrap items-center justify-center lg:justify-start gap-6 pt-4">
              <div className="flex items-center gap-2 text-white/80 hover:text-white transition-colors">
                <Shield className="h-5 w-5 text-pink-400" />
                <span className="text-sm font-medium">100% Secure</span>
              </div>
              <div className="flex items-center gap-2 text-white/80 hover:text-white transition-colors">
                <Globe className="h-5 w-5 text-purple-400" />
                <span className="text-sm font-medium">Made in India</span>
              </div>
              <div className="flex items-center gap-2 text-white/80 hover:text-white transition-colors">
                <Lock className="h-5 w-5 text-indigo-400" />
                <span className="text-sm font-medium">Privacy First</span>
              </div>
            </div>
          </div>

          {/* Right Content - Enhanced Product Showcase */}
          <div className={`relative transition-all duration-1000 delay-300 ease-out ${
            isVisible ? 'translate-y-0 opacity-100 scale-100' : 'translate-y-12 opacity-0 scale-95'
          }`}>
            <div className="relative mx-auto max-w-lg">
              {/* Main Device Mockup - Enhanced */}
              <div className="relative bg-white/10 backdrop-blur-lg rounded-3xl p-8 border border-white/20 shadow-elevated hover:shadow-glow transition-all duration-500 group">
                <div className="bg-white rounded-2xl p-6 space-y-6 shadow-lg">
                  <div className="flex items-center justify-between">
                    <h3 className="font-bold text-lg text-gray-900">Living Room</h3>
                    <Badge className="bg-green-100 text-green-700 animate-pulse">Online</Badge>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    {[
                      { name: "Smart Switch", status: "ON", color: "bg-green-500", icon: Zap },
                      { name: "Smart Plug", status: "OFF", color: "bg-red-500", icon: Zap },
                      { name: "LED Strip", status: "ON", color: "bg-green-500", icon: Zap },
                      { name: "Fan Control", status: "OFF", color: "bg-red-500", icon: Zap }
                    ].map((device) => (
                      <div key={device.name} className="bg-gray-100 rounded-xl p-4 text-center hover:bg-gray-200 transition-colors duration-300 group/device">
                        <div className={`h-10 w-10 rounded-full mx-auto mb-3 ${device.color} flex items-center justify-center group-hover/device:scale-110 transition-transform duration-300 shadow-md`}>
                          <device.icon className="h-5 w-5 text-white" />
                        </div>
                        <p className="text-sm font-medium text-gray-900">{device.name}</p>
                        <p className={`text-sm font-semibold ${device.status === 'ON' ? 'text-green-600' : 'text-red-600'}`}>
                          {device.status}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Enhanced Floating Elements */}
                <div className="absolute -top-8 -right-8 bg-purple-500/30 backdrop-blur-md rounded-full p-4 float-animation hover:scale-110 transition-transform duration-300 cursor-pointer group shadow-md">
                  <Shield className="h-6 w-6 text-purple-300 group-hover:text-purple-100" />
                </div>
                
                <div className="absolute -bottom-8 -left-8 bg-pink-500/30 backdrop-blur-md rounded-full p-4 float-animation hover:scale-110 transition-transform duration-300 cursor-pointer group shadow-md" style={{animationDelay: "1.5s"}}>
                  <Users className="h-6 w-6 text-pink-300 group-hover:text-pink-100" />
                </div>

                <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-indigo-500/30 backdrop-blur-md rounded-full p-3 float-animation hover:scale-110 transition-transform duration-300 cursor-pointer group shadow-md" style={{animationDelay: "0.75s"}}>
                  <Zap className="h-5 w-5 text-indigo-300 group-hover:text-indigo-100" />
                </div>
              </div>

              {/* Background Decorative Elements */}
              <div className="absolute -inset-6 bg-gradient-to-r from-indigo-500/10 to-purple-500/10 rounded-full blur-3xl -z-10 animate-pulse opacity-50"></div>
            </div>
          </div>
        </div>

        {/* Enhanced Stats Row */}
        {/* <div className={`grid grid-cols-2 md:grid-cols-4 gap-8 mt-20 pt-12 border-t border-white/20 transition-all duration-1000 delay-500 ease-out ${
          isVisible ? 'translate-y-0 opacity-100' : 'translate-y-12 opacity-0'
        }`}>
          {[
            { label: "Active Users", value: "1.2M+", icon: Users, color: "text-indigo-400" },
            { label: "Commands Daily", value: "5.8M", icon: Zap, color: "text-purple-400" },
            { label: "Cities", value: "500+", icon: Globe, color: "text-pink-400" },
            { label: "Devices Online", value: "2.5M", icon: Shield, color: "text-indigo-400" }
          ].map((stat) => (
            <div key={stat.label} className="text-center text-white group hover:scale-105 transition-transform duration-300">
              <div className={`${stat.color} mb-3`}>
                <stat.icon className="h-8 w-8 mx-auto group-hover:scale-110 transition-transform duration-300" />
              </div>
              <div className="text-3xl font-bold mb-1">{stat.value}</div>
              <div className="text-sm text-white/70 font-medium">{stat.label}</div>
            </div>
          ))}
        </div> */}
      </div>
    </section>
  );
};

export default Hero;