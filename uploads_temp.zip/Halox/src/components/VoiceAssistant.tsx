import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Mic, Volume2, MessageCircle, Zap, Play } from "lucide-react";

const VoiceAssistant = () => {
  const voiceCommands = [
    {
      command: "Turn on bedroom light",
      response: "Bedroom light is now on",
      icon: "💡"
    },
    {
      command: "Switch off plug after 1 hour", 
      response: "Smart plug will turn off in 1 hour",
      icon: "🔌"
    },
    {
      command: "Set living room temperature to 24",
      response: "AC set to 24°C in living room",
      icon: "❄️"
    },
    {
      command: "Good night",
      response: "Good night! Turning off all lights",
      icon: "🌙"
    }
  ];

  return (
    <section className="py-16 bg-gradient-to-br from-accent/5 via-background to-primary/5">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <div className="text-center space-y-4 mb-12">
          <div className="flex items-center justify-center gap-2 mb-4">
            <Mic className="h-6 w-6 text-accent animate-pulse" />
            <Badge className="bg-accent/10 text-accent border-accent/20">
              Voice Control
            </Badge>
          </div>
          
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-display font-bold text-foreground">
            Works with
            <span className="block">
              <span className="text-primary">Alexa</span> & <span className="text-accent">Google Assistant</span>
            </span>
          </h2>
          
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Control your smart home with simple voice commands. No complicated setup required.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Content - Voice Assistants */}
          <div className="space-y-8">
            {/* Assistant Logos */}
            <div className="grid grid-cols-2 gap-6">
              <Card className="p-6 text-center hover:shadow-lg transition-all duration-300 group cursor-pointer">
                <CardContent className="p-0 space-y-4">
                  <div className="bg-primary/10 w-16 h-16 rounded-full mx-auto flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                    <Volume2 className="h-8 w-8 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-bold text-lg text-foreground">Alexa</h3>
                    <p className="text-sm text-muted-foreground">Works with Alexa</p>
                  </div>
                </CardContent>
              </Card>

              <Card className="p-6 text-center hover:shadow-lg transition-all duration-300 group cursor-pointer">
                <CardContent className="p-0 space-y-4">
                  <div className="bg-accent/10 w-16 h-16 rounded-full mx-auto flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                    <MessageCircle className="h-8 w-8 text-accent" />
                  </div>
                  <div>
                    <h3 className="font-bold text-lg text-foreground">Google</h3>
                    <p className="text-sm text-muted-foreground">Hey Google</p>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Voice Demo */}
            <Card className="relative overflow-hidden">
              <CardContent className="p-6">
                <div className="flex items-center gap-3 mb-4">
                  <div className="bg-accent/20 p-2 rounded-full">
                    <Mic className="h-5 w-5 text-accent" />
                  </div>
                  <h3 className="font-semibold text-foreground">Try Voice Commands</h3>
                </div>

                <div className="grid grid-cols-1 gap-3">
                  {voiceCommands.slice(0, 2).map((cmd, index) => (
                    <div key={index} className="flex items-center gap-3 p-3 bg-muted/50 rounded-lg hover:bg-muted transition-colors">
                      <span className="text-lg">{cmd.icon}</span>
                      <div className="flex-1">
                        <div className="text-sm font-medium text-foreground">"{cmd.command}"</div>
                        <div className="text-xs text-muted-foreground">{cmd.response}</div>
                      </div>
                      <Button variant="ghost" size="icon" className="shrink-0">
                        <Play className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                </div>

                <Button variant="outline" size="sm" className="w-full mt-4">
                  View All Commands
                </Button>
              </CardContent>
            </Card>

            {/* Setup Steps */}
            <div className="space-y-4">
              <h3 className="font-semibold text-foreground">Easy Setup in 3 Steps:</h3>
              <div className="space-y-3">
                {[
                  "Connect Halox devices to your WiFi",
                  "Link Halox skill in Alexa/Google app", 
                  "Start controlling with your voice"
                ].map((step, index) => (
                  <div key={index} className="flex items-center gap-3">
                    <div className="bg-primary w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold text-white">
                      {index + 1}
                    </div>
                    <span className="text-sm text-foreground">{step}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Right Content - Interactive Demo */}
          <div className="relative">
            <div className="bg-gradient-to-br from-accent/10 via-transparent to-primary/10 rounded-3xl p-8 border border-border/50">
              {/* Voice Animation */}
              <div className="text-center mb-8">
                <div className="relative mx-auto w-32 h-32 bg-gradient-to-br from-primary/20 to-accent/20 rounded-full flex items-center justify-center">
                  <div className="w-20 h-20 bg-gradient-primary rounded-full flex items-center justify-center animate-pulse">
                    <Mic className="h-10 w-10 text-white" />
                  </div>
                  
                  {/* Sound Waves */}
                  {[...Array(3)].map((_, i) => (
                    <div
                      key={i}
                      className="absolute inset-0 border-2 border-primary/30 rounded-full animate-ping"
                      style={{
                        animationDelay: `${i * 0.5}s`,
                        animationDuration: '2s'
                      }}
                    />
                  ))}
                </div>
                
                <p className="text-sm text-muted-foreground mt-4">
                  Say "Hey Google, turn on living room light"
                </p>
              </div>

              {/* Command Examples */}
              <div className="space-y-3">
                <h4 className="font-semibold text-center text-foreground mb-4">Popular Commands</h4>
                {voiceCommands.map((cmd, index) => (
                  <div 
                    key={index} 
                    className="flex items-center gap-3 p-3 bg-white/50 backdrop-blur-sm rounded-lg border border-white/20 hover:bg-white/70 transition-all duration-300"
                  >
                    <span className="text-lg">{cmd.icon}</span>
                    <div className="flex-1 text-left">
                      <div className="text-sm font-medium text-foreground">"{cmd.command}"</div>
                    </div>
                    <Zap className="h-4 w-4 text-accent" />
                  </div>
                ))}
              </div>

              <div className="text-center mt-6">
                <Button className="w-full">
                  <Play className="mr-2 h-4 w-4" />
                  Watch Voice Demo
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Compatibility Banner */}
        <div className="mt-16 text-center">
          <Card className="max-w-4xl mx-auto">
            <CardContent className="p-8">
              <div className="grid md:grid-cols-3 gap-6 items-center">
                <div className="space-y-2">
                  <div className="text-2xl font-bold text-primary">100+</div>
                  <div className="text-sm text-muted-foreground">Voice Commands Supported</div>
                </div>
                <div className="space-y-2">
                  <div className="text-2xl font-bold text-accent">2 Languages</div>
                  <div className="text-sm text-muted-foreground">English & Hindi Support</div>
                </div>
                <div className="space-y-2">
                  <div className="text-2xl font-bold text-secondary">99%</div>
                  <div className="text-sm text-muted-foreground">Recognition Accuracy</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
};

export default VoiceAssistant;