import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Clock, Calendar, Zap, Sun, Moon, Coffee, Bed, Play } from "lucide-react";

const AutomationSchedule = () => {
  const automationScenarios = [
    {
      title: "Good Morning",
      time: "7:00 AM",
      icon: Sun,
      color: "text-secondary",
      bgColor: "bg-secondary/10",
      actions: [
        "Turn on bedroom lights",
        "Start coffee maker", 
        "Set AC to 26°C",
        "Open smart curtains"
      ]
    },
    {
      title: "Work From Home",
      time: "9:00 AM",
      icon: Coffee,
      color: "text-primary",
      bgColor: "bg-primary/10", 
      actions: [
        "Turn on study lights",
        "Enable focus mode",
        "Set Do Not Disturb",
        "Start air purifier"
      ]
    },
    {
      title: "Evening Wind Down",
      time: "7:00 PM",
      icon: Moon,
      color: "text-accent",
      bgColor: "bg-accent/10",
      actions: [
        "Dim living room lights",
        "Turn on ambient lighting",
        "Set relaxing music",
        "Close smart curtains"
      ]
    },
    {
      title: "Good Night",
      time: "11:00 PM", 
      icon: Bed,
      color: "text-purple-600",
      bgColor: "bg-purple-100",
      actions: [
        "Turn off all lights",
        // "Lock smart doors",
        // "Set security mode",
        "Turn off all plugs"
      ]
    }
  ];

  const timerExamples = [
    { device: "Water Heater", duration: "30 minutes", savings: "₹15/day" },
    { device: "AC", duration: "2 hours", savings: "₹25/day" },
    { device: "Study Lights", duration: "4 hours", savings: "₹8/day" },
    { device: "Phone Charger", duration: "3 hours", savings: "₹3/day" }
  ];

  return (
    <section className="py-16 bg-background">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <div className="text-center space-y-4 mb-12">
          <div className="flex items-center justify-center gap-2 mb-4">
            <Clock className="h-6 w-6 text-primary animate-pulse" />
            <Badge className="bg-primary/10 text-primary border-primary/20">
              Automation & Scheduling
            </Badge>
          </div>
          
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-display font-bold text-foreground">
            Smart Automation
            <span className="block text-primary">Made Simple</span>
          </h2>
          
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Set up intelligent schedules and automation to make your home work for you, saving time and energy.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-start">
          {/* Left Content - Automation Scenarios */}
          <div className="space-y-8">
            <div className="space-y-6">
              <h3 className="text-2xl font-semibold text-foreground flex items-center gap-3">
                <Calendar className="h-6 w-6 text-primary" />
                Daily Automation Scenes
              </h3>
              
              {automationScenarios.map((scenario, index) => (
                <Card key={scenario.title} className="group hover:shadow-lg transition-all duration-300">
                  <CardContent className="p-6">
                    <div className="flex items-start gap-4">
                      <div className={`${scenario.bgColor} p-3 rounded-lg group-hover:scale-110 transition-transform duration-300`}>
                        <scenario.icon className={`h-6 w-6 ${scenario.color}`} />
                      </div>
                      
                      <div className="flex-1 space-y-3">
                        <div className="flex items-center justify-between">
                          <h4 className="font-semibold text-foreground group-hover:text-primary transition-colors">
                            {scenario.title}
                          </h4>
                          <Badge variant="outline" className="text-xs">
                            {scenario.time}
                          </Badge>
                        </div>
                        
                        <div className="grid grid-cols-2 gap-2">
                          {scenario.actions.map((action, actionIndex) => (
                            <div key={actionIndex} className="flex items-center gap-2 text-sm text-muted-foreground">
                              <Zap className="h-3 w-3 text-accent" />
                              <span>{action}</span>
                            </div>
                          ))}
                        </div>
                        
                        <Button variant="outline" size="sm" className="mt-2">
                          <Play className="mr-2 h-3 w-3" />
                          Set Up Scene
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            <div className="bg-gradient-to-r from-primary/10 via-transparent to-accent/10 p-6 rounded-xl border border-primary/20">
              <div className="flex items-center gap-3 mb-3">
                <Zap className="h-5 w-5 text-primary" />
                <span className="font-semibold text-foreground">Smart Learning</span>
              </div>
              <p className="text-sm text-muted-foreground">
                Halox learns your daily patterns and suggests optimal automation schedules 
                to maximize comfort and energy savings.
              </p>
            </div>
          </div>

          {/* Right Content - Timer & Schedule Interface */}
          <div className="space-y-8">
            {/* App Interface Mockup */}
            <div className="relative">
              <div className="bg-gradient-to-br from-primary/10 via-transparent to-accent/10 rounded-3xl p-8 border border-border/50">
                <div className="space-y-6">
                  <div className="text-center">
                    <h3 className="font-semibold text-foreground mb-2">Smart Timer Interface</h3>
                    <p className="text-sm text-muted-foreground">Set timers and schedules with simple gestures</p>
                  </div>

                  {/* Mock Interface */}
                  <div className="bg-white rounded-2xl p-6 shadow-lg">
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <h4 className="font-semibold text-foreground">Active Timers</h4>
                        <Badge className="bg-accent text-accent-foreground">4 Running</Badge>
                      </div>
                      
                      {timerExamples.map((timer, index) => (
                        <div key={timer.device} className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                          <div className="flex items-center gap-3">
                            <div className="w-2 h-2 bg-accent rounded-full animate-pulse"></div>
                            <div>
                              <div className="text-sm font-medium text-foreground">{timer.device}</div>
                              <div className="text-xs text-muted-foreground">{timer.duration} remaining</div>
                            </div>
                          </div>
                          <div className="text-right">
                            <div className="text-xs text-accent font-medium">{timer.savings}</div>
                            <div className="text-xs text-muted-foreground">saved</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <Button variant="outline" size="sm" className="w-full">
                      <Clock className="mr-2 h-4 w-4" />
                      Set Timer
                    </Button>
                    <Button variant="outline" size="sm" className="w-full">
                      <Calendar className="mr-2 h-4 w-4" />
                      Schedule
                    </Button>
                  </div>
                </div>
              </div>
            </div>

            {/* Features Grid */}
            <div className="grid grid-cols-2 gap-4">
              <div className="text-center p-4 bg-gradient-card rounded-lg border border-border/50">
                <Clock className="h-8 w-8 text-primary mx-auto mb-2" />
                <div className="text-sm font-semibold text-foreground">Countdown Timers</div>
                <div className="text-xs text-muted-foreground">Auto shut-off</div>
              </div>
              <div className="text-center p-4 bg-gradient-card rounded-lg border border-border/50">
                <Calendar className="h-8 w-8 text-secondary mx-auto mb-2" />
                <div className="text-sm font-semibold text-foreground">Weekly Schedules</div>
                <div className="text-xs text-muted-foreground">Repeat patterns</div>
              </div>
              <div className="text-center p-4 bg-gradient-card rounded-lg border border-border/50">
                <Sun className="h-8 w-8 text-accent mx-auto mb-2" />
                <div className="text-sm font-semibold text-foreground">Sunrise/Sunset</div>
                <div className="text-xs text-muted-foreground">Natural timing</div>
              </div>
              <div className="text-center p-4 bg-gradient-card rounded-lg border border-border/50">
                <Zap className="h-8 w-8 text-purple-600 mx-auto mb-2" />
                <div className="text-sm font-semibold text-foreground">Smart Triggers</div>
                <div className="text-xs text-muted-foreground">Condition-based</div>
              </div>
            </div>

            {/* CTA */}
            <Card>
              <CardContent className="p-6 text-center space-y-4">
                <h4 className="font-semibold text-foreground">Ready to Automate?</h4>
                <p className="text-sm text-muted-foreground">
                  Start with simple schedules and gradually build complex automation scenes.
                </p>
                <Button className="w-full">
                  <Play className="mr-2 h-4 w-4" />
                  Watch Setup Tutorial
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Stats */}
        <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-6">
          {[
            { label: "Energy Saved", value: "35%", description: "Average reduction in bills" },
            { label: "Time Saved", value: "2hrs", description: "Daily automation benefits" },
            { label: "Scenes Available", value: "50+", description: "Pre-built automation" },
            { label: "User Satisfaction", value: "98%", description: "Love our automation" }
          ].map((stat) => (
            <div key={stat.label} className="text-center">
              <div className="text-2xl md:text-3xl font-bold text-primary">{stat.value}</div>
              <div className="text-sm font-semibold text-foreground">{stat.label}</div>
              <div className="text-xs text-muted-foreground">{stat.description}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default AutomationSchedule;