import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Users, 
  Zap, 
  MapPin, 
  Wifi, 
  TrendingUp, 
  Activity,
  Globe,
  Shield 
} from "lucide-react";

const RealTimeStats = () => {
  const [stats, setStats] = useState({
    activeUsers: 1234567,
    commandsDaily: 5876543,
    devicesOnline: 2345678,
    cities: 534
  });

  // Simulate real-time updates
  useEffect(() => {
    const interval = setInterval(() => {
      setStats(prev => ({
        activeUsers: prev.activeUsers + Math.floor(Math.random() * 10),
        commandsDaily: prev.commandsDaily + Math.floor(Math.random() * 100),
        devicesOnline: prev.devicesOnline + Math.floor(Math.random() * 50),
        cities: prev.cities + (Math.random() > 0.98 ? 1 : 0) // Occasionally add new city
      }));
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  const formatNumber = (num: number) => {
    if (num >= 1000000) {
      return (num / 1000000).toFixed(1) + 'M';
    }
    if (num >= 1000) {
      return (num / 1000).toFixed(1) + 'K';
    }
    return num.toLocaleString();
  };

  const statCards = [
    {
      icon: Users,
      label: "Active Users",
      value: formatNumber(stats.activeUsers),
      description: "Smart homes connected",
      color: "text-primary",
      bgColor: "bg-primary/10"
    },
    {
      icon: Zap,
      label: "Commands Daily",
      value: formatNumber(stats.commandsDaily),
      description: "Voice & app commands",
      color: "text-secondary",
      bgColor: "bg-secondary/10"
    },
    {
      icon: Wifi,
      label: "Devices Online",
      value: formatNumber(stats.devicesOnline),
      description: "Smart devices active",
      color: "text-accent",
      bgColor: "bg-accent/10"
    },
    {
      icon: MapPin,
      label: "Cities Covered",
      value: stats.cities.toString(),
      description: "Across India",
      color: "text-purple-600",
      bgColor: "bg-purple-100"
    }
  ];

  return (
    <section className="py-16 bg-background">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <div className="text-center space-y-4 mb-12">
          <div className="flex items-center justify-center gap-2 mb-4">
            <Activity className="h-6 w-6 text-accent animate-pulse" />
            <Badge variant="outline" className="border-accent text-accent">
              <div className="w-2 h-2 bg-accent rounded-full mr-2 animate-pulse"></div>
              Live Data
            </Badge>
          </div>
          
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-display font-bold text-foreground">
            Real-Time Usage
            <span className="block text-primary">Across India</span>
          </h2>
          
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            See how millions of Indians are making their homes smarter with Halox devices right now.
          </p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {statCards.map((stat, index) => (
            <Card key={stat.label} className="relative overflow-hidden group hover:shadow-lg transition-all duration-300">
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className={`${stat.bgColor} p-3 rounded-lg`}>
                    <stat.icon className={`h-6 w-6 ${stat.color}`} />
                  </div>
                  <TrendingUp className="h-4 w-4 text-accent" />
                </div>
                
                <div className="space-y-2">
                  <div className="text-2xl md:text-3xl font-bold text-foreground animate-pulse">
                    {stat.value}
                  </div>
                  <div className="text-sm font-semibold text-foreground">
                    {stat.label}
                  </div>
                  <div className="text-xs text-muted-foreground">
                    {stat.description}
                  </div>
                </div>

                {/* Animated background effect */}
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000"></div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* India Map Visualization */}
        <Card className="relative overflow-hidden bg-gradient-to-br from-primary/5 via-transparent to-accent/5">
          <CardContent className="p-8">
            <div className="grid lg:grid-cols-2 gap-8 items-center">
              {/* Left Content */}
              <div className="space-y-6">
                <div className="space-y-2">
                  <Badge className="bg-primary/10 text-primary border-primary/20">
                    <Globe className="h-3 w-3 mr-1" />
                    Pan-India Coverage
                  </Badge>
                  <h3 className="text-2xl md:text-3xl font-display font-bold text-foreground">
                    Connecting Smart Homes
                    <span className="block text-primary">From Kashmir to Kerala</span>
                  </h3>
                </div>
                
                <p className="text-muted-foreground">
                  Our network spans across {stats.cities}+ cities, making Halox the most trusted 
                  smart home brand in India. Join millions of satisfied customers.
                </p>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <div className="text-lg font-bold text-foreground">99.9%</div>
                    <div className="text-xs text-muted-foreground">Uptime Guarantee</div>
                  </div>
                  <div className="space-y-1">
                    <div className="text-lg font-bold text-foreground">&lt;50ms</div>
                    <div className="text-xs text-muted-foreground">Response Time</div>
                  </div>
                  <div className="space-y-1">
                    <div className="text-lg font-bold text-foreground">24/7</div>
                    <div className="text-xs text-muted-foreground">Support</div>
                  </div>
                  <div className="space-y-1">
                    <div className="text-lg font-bold text-foreground">Indian</div>
                    <div className="text-xs text-muted-foreground">Data Centers</div>
                  </div>
                </div>
              </div>

              {/* Right Content - Map Visualization */}
              <div className="relative">
                <div className="bg-gradient-to-br from-primary/10 to-accent/10 rounded-2xl p-8 relative overflow-hidden">
                  {/* Simplified India Map Icon */}
                  <div className="text-center space-y-4">
                    <div className="relative mx-auto w-48 h-48 bg-gradient-to-br from-primary/20 to-accent/20 rounded-full flex items-center justify-center">
                      <MapPin className="h-16 w-16 text-primary" />
                      
                      {/* Animated Pins */}
                      {[...Array(6)].map((_, i) => (
                        <div
                          key={i}
                          className="absolute w-3 h-3 bg-secondary rounded-full animate-ping"
                          style={{
                            top: `${20 + Math.random() * 60}%`,
                            left: `${20 + Math.random() * 60}%`,
                            animationDelay: `${i * 0.5}s`
                          }}
                        />
                      ))}
                    </div>
                    
                    <div className="text-center">
                      <div className="text-sm font-semibold text-foreground">Live Connections</div>
                      <div className="text-xs text-muted-foreground">Updating every second</div>
                    </div>
                  </div>

                  {/* Trust Indicators */}
                  <div className="absolute top-4 right-4">
                    <div className="flex items-center gap-1 bg-white/90 backdrop-blur-sm rounded-full px-3 py-1">
                      <Shield className="h-3 w-3 text-accent" />
                      <span className="text-xs font-medium">Secure</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </section>
  );
};

export default RealTimeStats;