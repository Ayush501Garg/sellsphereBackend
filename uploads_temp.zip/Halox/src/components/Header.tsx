import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Badge } from "@/components/ui/badge";
import {
  Menu,
  ShoppingCart,
  User,
  Smartphone,
  Zap,
  Home,
  Download,
  Package,
  BookOpen,
} from "lucide-react";
import { Link } from "react-router-dom";

const Header = ({ cartCount }) => {
  const [isOpen, setIsOpen] = useState(false);

  const navItems = [
    { href: "/", label: "Home", icon: Home },
    // { href: "/products", label: "Products", icon: Package },
    { href: "/shop", label: "Shop", icon: Zap },
    { href: "/app", label: "App", icon: Smartphone },
    { href: "/blog", label: "Blog", icon: BookOpen },
    { href: "/support", label: "Support", icon: User },
  ];

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container mx-auto flex h-20 items-center justify-between px-4">
        {/* Logo */}
        <Link to="/" className="flex items-center space-x-2 group">
          <img
            src="/logo.jpg"
            alt="Halox Logo"
            className="h-12 w-12 transition-transform duration-300 group-hover:scale-105"
          />
          <span className="text-2xl font-['Dancing_Script'] font-bold text-[#10c2e6] group-hover:text-[#0ea5c8] transition-colors duration-300">
            Halox
          </span>
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-6">
          {navItems.map((item) => (
            <Link
              key={item.href}
              to={item.href}
              className="flex items-center space-x-1 text-sm font-medium text-muted-foreground hover:text-[#10c2e6] transition-colors duration-300 group"
            >
              <item.icon className="h-4 w-4 group-hover:scale-110 transition-transform duration-300" />
              <span>{item.label}</span>
            </Link>
          ))}
        </nav>

        {/* Right side buttons */}
        <div className="flex items-center space-x-4">
          <Link to={"/cart"} className="relative">
            <Button
              variant="ghost"
              size="icon"
              className="relative hover:bg-[#10c2e6]/10 transition-colors duration-300"
            >
              <ShoppingCart className="h-5 w-5 text-[#10c2e6] hover:scale-110 transition-transform duration-300" />
              <Badge className="absolute -top-2 -right-2 h-5 w-5 rounded-full p-0 flex items-center justify-center text-xs bg-[#10c2e6] text-white">
                {cartCount || 0}
              </Badge>
            </Button>
          </Link>

          <Button
            asChild
            className="hidden sm:flex bg-gradient-to-r from-[#10c2e6] to-blue-500 text-white hover:from-[#0ea5c8] hover:to-blue-600 shadow-lg transition-all duration-300"
            size="sm"
          >
            <Link to="/download" className="flex items-center space-x-1">
              <Download className="h-4 w-4" />
              <span>Download App</span>
            </Link>
          </Button>

          {/* Mobile menu */}
          <Sheet open={isOpen} onOpenChange={setIsOpen}>
            <SheetTrigger asChild className="md:hidden">
              <Button
                variant="ghost"
                size="icon"
                className="hover:bg-[#10c2e6]/10 transition-colors duration-300"
              >
                <Menu className="h-5 w-5 text-[#10c2e6] hover:scale-110 transition-transform duration-300" />
              </Button>
            </SheetTrigger>
            <SheetContent
              side="right"
              className="w-80 bg-gradient-to-b from-blue-50 to-white"
            >
              <div className="flex flex-col space-y-4 mt-8">
                {navItems.map((item) => (
                  <Link
                    key={item.href}
                    to={item.href}
                    onClick={() => setIsOpen(false)}
                    className="flex items-center space-x-3 text-lg font-medium text-foreground hover:text-[#10c2e6] transition-colors duration-300 p-2 group"
                  >
                    <item.icon className="h-5 w-5 group-hover:scale-110 transition-transform duration-300" />
                    <span>{item.label}</span>
                  </Link>
                ))}
                <div className="pt-4 border-t border-[#10c2e6]/20">
                  <Button
                    asChild
                    className="w-full bg-gradient-to-r from-[#10c2e6] to-blue-500 text-white hover:from-[#0ea5c8] hover:to-blue-600 shadow-lg transition-all duration-300"
                    size="lg"
                  >
                    <Link
                      to="/download"
                      className="flex items-center justify-center space-x-2"
                    >
                      <Download className="h-5 w-5" />
                      <span>Download App</span>
                    </Link>
                  </Button>
                </div>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
};

export default Header;
