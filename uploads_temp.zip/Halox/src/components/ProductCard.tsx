import React from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Star, ShoppingCart, Zap, Wifi } from "lucide-react";
import { Link } from "react-router-dom";

interface ProductCardProps {
  id: string;
  name: string;
  price: number;
  originalPrice?: number;
  rating: number;
  image: string;
  category: string;
  isOnSale?: boolean;
  isBestSeller?: boolean;
  features?: string[];
  onAddToCart: () => void;
}

const ProductCard = ({
  id,
  name,
  price,
  originalPrice,
  rating,
  image,
  category,
  isOnSale = false,
  isBestSeller = false,
  features = [],
  onAddToCart,
}: ProductCardProps) => {
  return (
    <Card className="product-card group cursor-pointer relative overflow-hidden">
      {/* Badges */}
      <div className="absolute top-3 left-3 z-10 flex flex-col gap-2">
        {isBestSeller && (
          <Badge className="bg-secondary text-secondary-foreground">
            Best Seller
          </Badge>
        )}
        {isOnSale && (
          <Badge className="bg-destructive text-destructive-foreground">
            Sale
          </Badge>
        )}
      </div>

      <CardContent className="p-0">
        {/* Product Image */}
        <div className="relative aspect-square overflow-hidden rounded-t-xl">
          <img
            src={image}
            alt={name}
            className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
          
          {/* Quick Action Button */}
          <Button
            size="icon"
            className="absolute bottom-3 right-3 opacity-0 group-hover:opacity-100 transition-all duration-300 transform translate-y-2 group-hover:translate-y-0 shadow-lg"
            onClick={onAddToCart}
          >
            <ShoppingCart className="h-4 w-4" />
          </Button>
        </div>

        {/* Product Info */}
        <div className="p-4 space-y-3">
          <div className="space-y-1">
            <p className="text-xs text-muted-foreground uppercase tracking-wide font-medium">
              {category}
            </p>
            <Link to={`/product/${id}`}>
              <h3 className="font-semibold text-foreground group-hover:text-primary transition-colors line-clamp-2">
                {name}
              </h3>
            </Link>
          </div>

          {/* Features */}
          {features.length > 0 && (
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              {features.slice(0, 2).map((feature, index) => (
                <div key={index} className="flex items-center gap-1">
                  {feature === "WiFi" && <Wifi className="h-3 w-3" />}
                  {feature === "Smart Control" && <Zap className="h-3 w-3" />}
                  <span>{feature}</span>
                </div>
              ))}
            </div>
          )}

          {/* Rating */}
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1">
              {[...Array(5)].map((_, i) => (
                <Star
                  key={i}
                  className={`h-3 w-3 ${
                    i < Math.floor(rating)
                      ? "text-yellow-400 fill-current"
                      : "text-muted-foreground"
                  }`}
                />
              ))}
            </div>
            <span className="text-xs text-muted-foreground">({rating})</span>
          </div>

          {/* Price and CTA */}
          <div className="flex items-center justify-between pt-2">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <span className="text-lg font-bold text-foreground">
                  ₹{price.toLocaleString()}
                </span>
                {originalPrice && (
                  <span className="text-sm text-muted-foreground line-through">
                    ₹{originalPrice.toLocaleString()}
                  </span>
                )}
              </div>
              {originalPrice && (
                <span className="text-xs text-accent font-medium">
                  Save ₹{(originalPrice - price).toLocaleString()}
                </span>
              )}
            </div>

            <Button size="sm" className="shrink-0" onClick={onAddToCart}>
              Add to Cart
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default ProductCard;