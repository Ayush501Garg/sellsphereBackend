import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import { 
  Facebook, 
  Twitter, 
  Instagram, 
  Youtube, 
  Mail, 
  Phone, 
  MapPin, 
  Zap,
  Smartphone,
  Download
} from "lucide-react";
import { Link } from "react-router-dom";

const Footer = () => {
  const footerSections = [
    {
      title: "Shop",
      links: [
        { label: "Smart Switches", href: "/shop/switches" },
        { label: "Smart Plugs", href: "/shop/plugs" },
        { label: "LED Strips", href: "/shop/led-strips" },
        { label: "Controllers", href: "/shop/controllers" },
        // { label: "Bundles", href: "/shop/bundles" }
      ]
    },
    {
      title: "Support",
      links: [
        { label: "Help Center", href: "/support" },
        { label: "Installation Guide", href: "/support/installation" },
        { label: "Warranty", href: "/support/warranty" },
        { label: "Contact Us", href: "/contactUs" },
        // { label: "Service Centers", href: "/support/service-centers" }
      ]
    },
    {
      title: "Company",
      links: [
        { label: "About Halox", href: "/about" },
        // { label: "Careers", href: "/careers" },
        { label: "Blog", href: "/blog" },
        { label: "Press Kit", href: "/press" },
        { label: "Partner with Us", href: "/partners" }
      ]
    },
    {
      title: "Legal",
      links: [
        { label: "Privacy Policy", href: "/privacy" },
        { label: "Terms of Service", href: "/terms" },
        { label: "Cancellation Policy", href: "/cancel" },
        { label: "Refund Policy", href: "/return-policy" },
        { label: "Shipping Policy", href: "/shipping-policy" }
      ]
    }
  ];

  const socialLinks = [
    { icon: Facebook, href: "https://www.facebook.com/people/Halox/61557673532988/", label: "Facebook" },
    // { icon: Twitter, href: "https://twitter.com/haloxsmart", label: "Twitter" },
    { icon: Instagram, href: "https://www.instagram.com/halox_smart/", label: "Instagram" },
    { icon: Youtube, href: "https://www.youtube.com/@haloxsmart", label: "YouTube" }
  ];

  return (
    <footer className="bg-gradient-to-br from-foreground via-foreground/95 to-foreground/90 text-white">
      {/* Newsletter Section */}
      <div className="border-b border-white/10">
        <div className="container mx-auto px-4 py-12">
          <div className="grid lg:grid-cols-2 gap-8 items-center">
            <div className="space-y-4">
              <h3 className="text-2xl md:text-3xl font-display font-bold">
                Stay Updated with Halox
              </h3>
              <p className="text-white/70">
                Get the latest updates on new products, smart home tips, and exclusive offers.
              </p>
            </div>
            <div className="space-y-4">
              <div className="flex gap-3">
                <Input
                  type="email"
                  placeholder="Enter your email"
                  className="bg-white/10 border-white/20 text-white placeholder:text-white/50"
                />
                <Button className="bg-secondary hover:bg-secondary/90 text-white">
                  <Mail className="mr-2 h-4 w-4" />
                  Subscribe
                </Button>
              </div>
              <p className="text-xs text-white/50">
                Join 100,000+ smart home enthusiasts. Unsubscribe anytime.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Footer Content */}
      <div className="container mx-auto px-4 py-16">
        <div className="grid lg:grid-cols-6 gap-8">
          {/* Brand Section */}
          <div className="lg:col-span-2 space-y-6">
            <div className="space-y-4">
              <Link to="/" className="flex items-center space-x-2">
                <div className="h-10 w-10 rounded-lg bg-gradient-primary flex items-center justify-center">
                  <Zap className="h-6 w-6 text-white" />
                </div>
                <span className="text-2xl font-display font-bold">
                  Halox Smart
                </span>
              </Link>
              <p className="text-white/70 text-sm leading-relaxed">
                India's leading smart home automation brand. Making Indian homes smarter, 
                safer, and more efficient with cutting-edge IoT technology.
              </p>
            </div>

            {/* App Download */}
            <div className="space-y-3">
              <h4 className="font-semibold text-white">Download Our App</h4>
              <div className="flex gap-3">
                <Button variant="outline" size="sm" className="bg-white/10 border-white/20 hover:bg-white/20 text-white">
                  <Download className="mr-2 h-4 w-4" />
                  Play Store
                </Button>
                <Button variant="outline" size="sm" className="bg-white/10 border-white/20 hover:bg-white/20 text-white">
                  <Download className="mr-2 h-4 w-4" />
                  App Store
                </Button>
              </div>
            </div>

            {/* Social Links */}
            <div className="space-y-3">
              <h4 className="font-semibold text-white">Follow Us</h4>
              <div className="flex gap-3">
                {socialLinks.map((social) => (
                  <a
                    key={social.label}
                    href={social.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="bg-white/10 hover:bg-white/20 p-2 rounded-lg transition-colors"
                    aria-label={social.label}
                  >
                    <social.icon className="h-5 w-5" />
                  </a>
                ))}
              </div>
            </div>
          </div>

          {/* Footer Links */}
          {footerSections.map((section) => (
            <div key={section.title} className="space-y-4">
              <h4 className="font-semibold text-white">{section.title}</h4>
              <ul className="space-y-2">
                {section.links.map((link) => (
                  <li key={link.label}>
                    <Link
                      to={link.href}
                      className="text-white/70 hover:text-white text-sm transition-colors"
                    >
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>

      {/* Contact Info Banner */}
      <div className="border-t border-white/10">
        <div className="container mx-auto px-4 py-8">
          <div className="grid md:grid-cols-3 gap-6 text-center md:text-left">
            <div className="flex items-center justify-center md:justify-start gap-3">
              <div className="bg-primary/20 p-2 rounded-lg">
                <Phone className="h-5 w-5 text-primary" />
              </div>
              <div>
                <div className="text-sm text-white/70">Support Email</div>
                <div className="font-semibold">care@thelivsmart.com</div>
              </div>
            </div>
            <div className="flex items-center justify-center md:justify-start gap-3">
              <div className="bg-secondary/20 p-2 rounded-lg">
                <Mail className="h-5 w-5 text-secondary" />
              </div>
              <div>
                <div className="text-sm text-white/70">Info Email</div>
                <div className="font-semibold">info@thelivsmart.com</div>
              </div>
            </div>
            <div className="flex items-center justify-center md:justify-start gap-3">
              <div className="bg-accent/20 p-2 rounded-lg">
                <MapPin className="h-5 w-5 text-accent" />
              </div>
              <div>
                <div className="text-sm text-white/70">Headquarters</div>
                <div className="font-semibold">Noida, India</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Separator className="bg-white/10" />

      {/* Bottom Bar */}
      <div className="container mx-auto px-4 py-6">
        <div className="flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="flex items-center gap-4 text-sm text-white/70">
            <span>© 2025 Halox Smart Technologies Pvt. Ltd.</span>
            <span className="hidden md:inline">•</span>
            <div className="flex items-center gap-2">
              <span>Made in India</span>
              <span className="text-lg">🇮🇳</span>
            </div>
          </div>
          <div className="flex items-center gap-6 text-sm text-white/70">
            <span>All rights reserved</span>
            <span>•</span>
            <span>GST: 29ABCDE1234F1Z5</span>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;