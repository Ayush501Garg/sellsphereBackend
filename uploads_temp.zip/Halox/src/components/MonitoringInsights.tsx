import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge"; 
import { Button } from "@/components/ui/button";
import { BarChart3, Activity, Clock, TrendingUp, Smartphone, Eye, Zap } from "lucide-react";

const MonitoringInsights = () => {
  const features = [
    {
      icon: Activity,
      title: "Device Usage History",
      description: "Track when and how your devices are used throughout the day",
      color: "text-primary",
      bgColor: "bg-primary/10"
    },
    {
      icon: Clock,
      title: "On/Off Logs",
      description: "Complete timeline of all device state changes with timestamps", 
      color: "text-secondary",
      bgColor: "bg-secondary/10"
    },
    {
      icon: BarChart3,
      title: "Power Consumption Patterns",
      description: "Analyze energy usage patterns to optimize your electricity bills",
      color: "text-accent",
      bgColor: "bg-accent/10"
    },
    {
      icon: TrendingUp,
      title: "Smart Analytics",
      description: "AI-powered insights to help you make better decisions",
      color: "text-purple-600",
      bgColor: "bg-purple-100"
    }
  ];

  return (
    <section className="py-16 bg-background">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <div className="text-center space-y-4 mb-12">
          <div className="flex items-center justify-center gap-2 mb-4">
            <Eye className="h-6 w-6 text-primary" />
            <Badge className="bg-primary/10 text-primary border-primary/20">
              Monitor & Insights  
            </Badge>
          </div>
          
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-display font-bold text-foreground">
            Stay Informed,
            <span className="block text-primary">Stay Efficient</span>
          </h2>
          
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Get detailed insights into your smart home usage with comprehensive monitoring and analytics.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Content - App Mockup */}
          <div className="relative">
            <div className="relative mx-auto max-w-sm">
              {/* Phone Frame */}
              <div className="bg-gradient-to-br from-foreground to-foreground/80 rounded-[2.5rem] p-2 shadow-elevated">
                <div className="bg-background rounded-[2rem] overflow-hidden">
                  {/* Status Bar */}
                  <div className="bg-gradient-primary h-12 flex items-center justify-between px-6 text-white text-sm">
                    <span className="font-semibold">Halox Insights</span>
                    <div className="flex items-center gap-1">
                      <div className="w-1 h-1 bg-white rounded-full"></div>
                      <div className="w-1 h-1 bg-white rounded-full"></div>
                      <div className="w-1 h-1 bg-white rounded-full"></div>
                    </div>
                  </div>

                  {/* App Content */}
                  <div className="p-4 space-y-4 h-96 overflow-hidden">
                    {/* Usage Chart */}
                    <Card>
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between mb-3">
                          <h3 className="font-semibold text-sm">Today's Usage</h3>
                          <Badge variant="outline" className="text-xs">Live</Badge>
                        </div>
                        <div className="space-y-2">
                          {/* Mock Chart Bars */}
                          {[
                            { time: "6AM", usage: 80, color: "bg-primary" },
                            { time: "12PM", usage: 60, color: "bg-secondary" },
                            { time: "6PM", usage: 90, color: "bg-accent" },
                            { time: "Now", usage: 45, color: "bg-purple-500" }
                          ].map((bar) => (
                            <div key={bar.time} className="flex items-center gap-3">
                              <span className="text-xs text-muted-foreground w-8">{bar.time}</span>
                              <div className="flex-1 bg-muted rounded-full h-2">
                                <div 
                                  className={`${bar.color} h-2 rounded-full transition-all duration-1000`}
                                  style={{ width: `${bar.usage}%` }}
                                ></div>
                              </div>
                              <span className="text-xs font-medium w-8">{bar.usage}%</span>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>

                    {/* Device Status */}
                    <div className="grid grid-cols-2 gap-2">
                      {[
                        { name: "Living Room", status: "ON", power: "12W", color: "text-accent" },
                        { name: "Bedroom", status: "OFF", power: "0W", color: "text-muted-foreground" },
                        { name: "Kitchen", status: "ON", power: "8W", color: "text-secondary" },
                        { name: "Study", status: "ON", power: "15W", color: "text-primary" }
                      ].map((device) => (
                        <div key={device.name} className="bg-muted/50 rounded-lg p-2">
                          <div className="flex items-center gap-1 mb-1">
                            <Zap className={`h-3 w-3 ${device.color}`} />
                            <span className="text-xs font-medium">{device.name}</span>
                          </div>
                          <div className="text-xs text-muted-foreground">{device.status} • {device.power}</div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* Floating Icons */}
              <div className="absolute -top-4 -right-4 bg-primary/20 backdrop-blur-sm rounded-full p-3 animate-pulse">
                <BarChart3 className="h-5 w-5 text-primary" />
              </div>
              <div className="absolute -bottom-4 -left-4 bg-accent/20 backdrop-blur-sm rounded-full p-3 animate-pulse" style={{animationDelay: "1s"}}>
                <Activity className="h-5 w-5 text-accent" />
              </div>
            </div>
          </div>

          {/* Right Content - Features */}
          <div className="space-y-8">
            <div className="space-y-6">
              {features.map((feature, index) => (
                <div key={feature.title} className="flex items-start gap-4 p-4 rounded-xl hover:bg-gradient-card transition-all duration-300 group">
                  <div className={`${feature.bgColor} p-3 rounded-lg group-hover:scale-110 transition-transform duration-300`}>
                    <feature.icon className={`h-6 w-6 ${feature.color}`} />
                  </div>
                  <div className="space-y-2">
                    <h3 className="font-semibold text-foreground group-hover:text-primary transition-colors">
                      {feature.title}
                    </h3>
                    <p className="text-sm text-muted-foreground">
                      {feature.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>

            {/* Stats */}
            <div className="grid grid-cols-2 gap-4">
              <div className="text-center p-4 bg-gradient-to-br from-primary/10 to-transparent rounded-lg border border-primary/20">
                <div className="text-2xl font-bold text-primary">99.9%</div>
                <div className="text-xs text-muted-foreground">Data Accuracy</div>
              </div>
              <div className="text-center p-4 bg-gradient-to-br from-accent/10 to-transparent rounded-lg border border-accent/20">
                <div className="text-2xl font-bold text-accent">Real-time</div>
                <div className="text-xs text-muted-foreground">Updates</div>
              </div>
            </div>

            <div className="space-y-4">
              <Button size="lg" className="w-full">
                <Smartphone className="mr-2 h-5 w-5" />
                Download App to Start Monitoring
              </Button>
              <p className="text-xs text-center text-muted-foreground">
                Available on iOS and Android • Free with any Halox device
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default MonitoringInsights;