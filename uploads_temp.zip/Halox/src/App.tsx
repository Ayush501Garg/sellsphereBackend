import { useEffect } from "react";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, useLocation } from "react-router-dom";
import { HelmetProvider } from "react-helmet-async";
import Index from "./pages/Index";
import Shop from "./pages/Shop";
import NotFound from "./pages/NotFound";
import AppPage from "./pages/AppPage";
import Support from "./pages/Support";
import Download from "./pages/Download";
import Cart from "./pages/Cart";
import Privacy from "./pages/Privacy";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import Terms from "./pages/Terms";
import ShippingPolicy from "./pages/ShippingPolicy";
import ReturnPolicy from "./pages/ReturnPolicy";
import Returns from "./pages/Returns";
import CancellationPolicy from "./pages/CancellationPolicy";
import About from "./pages/About";
import Careers from "./pages/Careers";
import Blog from "./pages/Blog";
import ContactUs from "./pages/ContactUs";
import ProductCard from "./components/ProductCard";
import ProductPage from "./pages/ProductPage";
import ProductOne from "./pages/ProductOne";
import BlogOne from "./pages/BlogOne";

const queryClient = new QueryClient();

// Scroll to Top Component
const ScrollToTop = () => {
  const { pathname } = useLocation();

  useEffect(() => {
    // Scroll to top when route changes
    window.scrollTo({
      top: 0,
      left: 0,
      behavior: 'smooth'
    });
  }, [pathname]);

  return null;
};

const App = () => (
  <QueryClientProvider client={queryClient}>
    <HelmetProvider>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <ScrollToTop />
          <Routes>
            <Route path="/" element={<Index />} />
            <Route path="/shop" element={<Shop />} />
            <Route path="/cart" element={<Cart />} />
            <Route path="/contactUs" element={<ContactUs />} />
            
            {/* Main Pages */}
            <Route path="/shop/:category" element={<Shop />} />
            <Route path="/product/:id" element={<Index />} />
            <Route path="/app" element={<AppPage />} />
            <Route path="/support" element={<Support />} />
            <Route path="/privacy" element={<Privacy />} />
            <Route path="terms" element={<Terms />} />
            <Route path="/shipping-policy" element={<ShippingPolicy />} />
            <Route path="/return-policy" element={<ReturnPolicy />} />
            <Route path="/cancel" element={<CancellationPolicy />} />
            <Route path="/return" element={<Returns />} />
            <Route path="/about" element={<About />} />
            <Route path="/careers" element={<Careers />} />
            <Route path="/blog" element={<Blog />} />
            <Route path="/blogOne" element={<BlogOne />} />
            {/* <Route path="/products" element={<ProductPage />} /> */}
            <Route path="/productOne" element={<ProductOne />} />
            
            {/* Static Pages */}
            
            {/* Custom Routes */}
            <Route path="/download" element={<Download />} />
            {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>        
      </TooltipProvider>
    </HelmetProvider>
  </QueryClientProvider>
);

export default App;