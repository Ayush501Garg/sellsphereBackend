import { useState } from "react";
import {
  Shield,
  Lock,
  Eye,
  Database,
  Users,
  FileText,
  CheckCircle,
  Mail,
  Phone,
  Globe,
  UserCheck,
  Settings,
  AlertCircle,
  ChevronDown,
} from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

const Privacy = () => {
  const [activeSection, setActiveSection] = useState("");
  const [openAccordionItem, setOpenAccordionItem] = useState(null);

  const toggleAccordion = (index) => {
    setOpenAccordionItem(openAccordionItem === index ? null : index);
  };

  const privacySections = [
    {
      id: "information-collection",
      title: "Information We Collect",
      icon: Database,
      content: {
        personal:
          "When you visit our website or make a purchase, we may collect personal information such as your name, email address, shipping address, billing address, phone number, and payment information.",
        device:
          "We may collect information about the device you use to access our website, including your IP address, browser type, operating system, and other technical details.",
        cookies:
          "We use cookies and similar tracking technologies to enhance your browsing experience, analyze website traffic, and personalize content. You can control cookies through your browser settings, but please note that disabling cookies may affect the functionality of our website.",
      },
    },
    {
      id: "information-usage",
      title: "How We Use Your Information",
      icon: Settings,
      content: {
        processing:
          "We use your personal information to process and fulfill your orders, communicate with you about your purchases, and provide customer support.",
        marketing:
          "With your consent, we may send you promotional emails about our products, special offers, and other updates. You can opt-out of receiving these communications at any time by following the unsubscribe instructions included in the emails or contacting us directly.",
        analytics:
          "We use information collected through cookies and other tracking technologies to analyze website traffic, monitor the effectiveness of our marketing efforts, and improve our website and services.",
      },
    },
    {
      id: "information-sharing",
      title: "Information Sharing",
      icon: Users,
      content: {
        thirdParty:
          "We may share your personal information with third-party service providers and partners who assist us in operating our website, processing payments, fulfilling orders, and providing other services. These service providers are contractually obligated to protect your information and may only use it for the purposes specified by us.",
        legal:
          "We may also disclose your information in response to legal requests, to protect our rights or property, or to enforce our Terms of Service.",
      },
    },
    {
      id: "data-security",
      title: "Data Security",
      icon: Shield,
      content: {
        security:
          "We take reasonable measures to protect your personal information from unauthorized access, disclosure, alteration, or destruction. However, no method of transmission over the internet or electronic storage is 100% secure, and we cannot guarantee absolute security.",
      },
    },
    {
      id: "childrens-privacy",
      title: "Children's Privacy",
      icon: UserCheck,
      content: {
        policy:
          "Our website is not intended for children under the age of 13. We do not knowingly collect personal information from children under 13. If you are a parent or guardian and believe that your child has provided us with personal information, please contact us, and we will take appropriate steps to remove the information from our records.",
      },
    },
  ];

  const faqs = [
    {
      question: "What personal information does Halox Smart collect?",
      answer:
        "We collect information such as your name, email address, shipping and billing addresses, phone number, and payment information when you make purchases. We also collect device information like IP address and browser type for website functionality and analytics.",
    },
    {
      question: "How is my payment information protected?",
      answer:
        "We use industry-standard security measures to protect your payment information. All payment data is encrypted during transmission and we work with trusted payment processors who comply with PCI DSS standards.",
    },
    {
      question: "Can I opt out of marketing communications?",
      answer:
        "Yes, you can opt out of marketing emails at any time by clicking the unsubscribe link in any email or by contacting us directly at info@thelivsmart.com. You'll still receive important order-related communications.",
    },
    {
      question: "Do you share my information with third parties?",
      answer:
        "We only share your information with trusted service providers who help us operate our business, such as payment processors and shipping companies. These partners are contractually obligated to protect your information and can only use it for specified purposes.",
    },
    {
      question: "How long do you keep my personal information?",
      answer:
        "We retain your personal information for as long as necessary to provide our services, comply with legal obligations, and resolve disputes. You can request deletion of your personal information by contacting us.",
    },
    {
      question: "How can I access or update my personal information?",
      answer:
        "You can access and update your personal information through your account settings on our website. If you need assistance or want to delete your information, please contact us at info@thelivsmart.com.",
    },
  ];

  const faqLd = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: faqs.map((f) => ({
      "@type": "Question",
      name: f.question,
      acceptedAnswer: { "@type": "Answer", text: f.answer },
    })),
  };

  const canonical =
    typeof window !== "undefined"
      ? `${window.location.origin}/privacy`
      : "/privacy";

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main>
        {/* Hero Section */}
        <section className="relative min-h-[80vh] flex items-center justify-center overflow-hidden bg-gradient-to-br from-emerald-600 via-teal-600 to-cyan-600">
          <div className="absolute inset-0 opacity-10">
            <div className="absolute inset-0 bg-white/5 bg-[radial-gradient(circle_at_1px_1px,rgba(255,255,255,0.15)_1px,transparent_0)] bg-[length:20px_20px] animate-pulse"></div>
          </div>
          <div className="container mx-auto px-4 relative z-10">
            <div className="text-center space-y-8">
              <div className="inline-flex items-center bg-white/20 text-white border border-white/30 backdrop-blur-sm rounded-full px-4 py-2">
                <Shield className="h-4 w-4 mr-2" />
                Privacy Protected
              </div>
              <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold text-white leading-tight">
                Your Privacy
                <span className="block text-cyan-300">Is Our Priority</span>
              </h1>
              <p className="text-lg md:text-xl text-white/80 max-w-3xl mx-auto">
                We're committed to protecting your personal information and
                being transparent about how we collect, use, and safeguard your
                data.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <button
                  onClick={() =>
                    document
                      .getElementById("privacy-sections")
                      ?.scrollIntoView({ behavior: "smooth" })
                  }
                  className="bg-cyan-500 hover:bg-cyan-600 text-white px-8 py-4 rounded-lg font-semibold shadow-lg transition-all flex items-center justify-center"
                >
                  <FileText className="mr-2 h-5 w-5" />
                  Read Full Policy
                </button>
                <button className="border border-white text-white hover:bg-white hover:text-teal-600 px-8 py-4 rounded-lg font-semibold transition-all flex items-center justify-center">
                  <Mail className="mr-2 h-5 w-5" />
                  Contact Us
                </button>
              </div>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mt-16 pt-8 border-t border-white/20">
              {[
                {
                  label: "Data Protected",
                  value: "100%",
                  icon: Shield,
                },
                { label: "Security Standards", value: "ISO 27001", icon: Lock },
                { label: "Transparency", value: "Complete", icon: Eye },
                { label: "User Control", value: "Full", icon: Settings },
              ].map((stat) => (
                <div key={stat.label} className="text-center text-white">
                  <stat.icon className="h-6 w-6 mx-auto mb-2 text-cyan-300" />
                  <div className="text-2xl font-bold">{stat.value}</div>
                  <div className="text-sm text-white/60">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Privacy Principles Section */}
        <section className="py-24 bg-white">
          <div className="container mx-auto px-4">
            <div className="text-center mb-16">
              <div className="inline-block mb-4 bg-emerald-100 text-emerald-600 px-4 py-2 rounded-full text-sm font-medium">
                Our Principles
              </div>
              <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
                Privacy by Design
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                We build privacy protection into every aspect of our products
                and services from the ground up.
              </p>
            </div>
            <div className="grid md:grid-cols-3 gap-8">
              {[
                {
                  icon: Lock,
                  title: "Data Minimization",
                  description:
                    "We only collect the information we need to provide you with the best smart home experience.",
                  color: "from-emerald-400 to-emerald-600",
                  bgColor: "from-emerald-50 to-emerald-100",
                },
                {
                  icon: Eye,
                  title: "Transparency",
                  description:
                    "We're clear about what data we collect, how we use it, and who we share it with.",
                  color: "from-teal-400 to-teal-600",
                  bgColor: "from-teal-50 to-teal-100",
                },
                {
                  icon: UserCheck,
                  title: "User Control",
                  description:
                    "You have complete control over your data with easy access, update, and deletion options.",
                  color: "from-cyan-400 to-cyan-600",
                  bgColor: "from-cyan-50 to-cyan-100",
                },
              ].map((principle) => (
                <div
                  key={principle.title}
                  className="group bg-gradient-to-br from-white to-gray-50 rounded-3xl p-8 border border-gray-100 hover:border-transparent hover:shadow-2xl transition-all duration-500 hover:transform hover:-translate-y-2 cursor-pointer relative overflow-hidden"
                >
                  <div
                    className={`absolute inset-0 bg-gradient-to-br ${principle.bgColor} opacity-0 group-hover:opacity-100 transition-opacity duration-500`}
                  ></div>
                  <div
                    className={`w-16 h-16 rounded-2xl flex items-center justify-center mb-6 shadow-lg group-hover:shadow-xl transition-all duration-300 group-hover:scale-110 relative z-10 bg-gradient-to-br ${principle.color}`}
                  >
                    <principle.icon className="h-8 w-8 text-white transition-transform duration-300 group-hover:scale-110" />
                    <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-white/20 to-transparent"></div>
                  </div>
                  <div className="relative z-10">
                    <h3 className="text-2xl font-bold text-gray-900 mb-4 group-hover:text-emerald-700 transition-colors duration-300">
                      {principle.title}
                    </h3>
                    <p className="text-gray-600 leading-relaxed group-hover:text-gray-700 transition-colors duration-300">
                      {principle.description}
                    </p>
                  </div>
                  <div
                    className={`absolute top-0 right-0 w-24 h-24 bg-gradient-to-br ${principle.color} opacity-10 rounded-full transform translate-x-8 -translate-y-8 group-hover:scale-150 transition-transform duration-500`}
                  ></div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Privacy Policy Sections */}
        <section id="privacy-sections" className="py-24 bg-gray-50">
          <div className="container mx-auto px-4 max-w-4xl">
            <div className="text-center mb-16">
              <div className="inline-block mb-4 bg-teal-100 text-teal-600 px-4 py-2 rounded-full text-sm font-medium">
                Policy Details
              </div>
              <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
                Privacy Policy
              </h2>
              <p className="text-xl text-gray-600">
                Detailed information about how we handle your personal data.
              </p>
            </div>

            <div className="space-y-8">
              {privacySections.map((section) => (
                <div
                  key={section.id}
                  className="bg-white rounded-2xl p-8 shadow-lg border border-gray-100 hover:shadow-xl transition-all duration-300"
                >
                  <div className="flex items-start gap-4 mb-6">
                    <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-teal-500 to-cyan-600 flex items-center justify-center shadow-lg">
                      <section.icon className="h-6 w-6 text-white" />
                    </div>
                    <div>
                      <h3 className="text-2xl font-bold text-gray-900 mb-2">
                        {section.title}
                      </h3>
                    </div>
                  </div>

                  <div className="space-y-4 ml-16">
                    {Object.entries(section.content).map(([key, value]) => (
                      <div
                        key={key}
                        className="border-l-4 border-teal-200 pl-6"
                      >
                        <p className="text-gray-700 leading-relaxed">{value}</p>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>

            {/* Additional Important Information */}
            <div className="mt-12 bg-white rounded-2xl p-8 shadow-lg border border-gray-100">
              <div className="flex items-start gap-4 mb-6">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-orange-500 to-red-600 flex items-center justify-center shadow-lg">
                  <AlertCircle className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-gray-900 mb-2">
                    Changes to This Privacy Policy
                  </h3>
                </div>
              </div>

              <div className="ml-16">
                <div className="border-l-4 border-orange-200 pl-6">
                  <p className="text-gray-700 leading-relaxed mb-4">
                    We may update this Privacy Policy from time to time to
                    reflect changes in our practices or for other operational,
                    legal, or regulatory reasons. We will notify you of any
                    material changes by posting the updated Privacy Policy on
                    our website with a new effective date.
                  </p>
                  <div className="bg-orange-50 rounded-lg p-4 mt-4">
                    <p className="text-sm text-orange-800">
                      <strong>Last Updated:</strong> By using our website, you
                      consent to the collection, use, and disclosure of your
                      personal information as described in this Privacy Policy.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Contact Information */}
        <section className="py-24 bg-white">
          <div className="container mx-auto px-4 max-w-3xl">
            <div className="text-center mb-16">
              <div className="inline-block mb-4 bg-cyan-100 text-cyan-600 px-4 py-2 rounded-full text-sm font-medium">
                Get in Touch
              </div>
              <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
                Privacy Questions?
              </h2>
              <p className="text-xl text-gray-600">
                If you have any questions or concerns about this Privacy Policy
                or our privacy practices, please contact us.
              </p>
            </div>

            <div className="bg-gradient-to-br from-gray-50 to-white rounded-3xl p-8 shadow-lg border border-gray-100">
              <div className="grid md:grid-cols-2 gap-8">
                <div className="space-y-6">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-teal-500 to-cyan-600 flex items-center justify-center shadow-lg">
                      <Mail className="h-6 w-6 text-white" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900">Email Us</h4>
                      <p className="text-gray-600">info@thelivsmart.com</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center shadow-lg">
                      <Globe className="h-6 w-6 text-white" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900">Company</h4>
                      <p className="text-gray-600">
                        LivSmart Automation and Security LLP
                      </p>
                    </div>
                  </div>
                </div>

                <div className="bg-white rounded-2xl p-6 shadow-md">
                  <h4 className="font-semibold text-gray-900 mb-4">
                    Your Rights
                  </h4>
                  <ul className="space-y-2 text-sm text-gray-600">
                    <li className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-emerald-500" />
                      Access your personal data
                    </li>
                    <li className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-emerald-500" />
                      Update or correct information
                    </li>
                    <li className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-emerald-500" />
                      Request data deletion
                    </li>
                    <li className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-emerald-500" />
                      Opt-out of communications
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* FAQ Section */}
        <section className="py-24 bg-gray-50">
          <div className="container mx-auto px-4 max-w-4xl">
            <div className="text-center mb-16">
              <div className="inline-block mb-4 bg-indigo-100 text-indigo-600 px-4 py-2 rounded-full text-sm font-medium">
                FAQ
              </div>
              <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
                Privacy FAQ
              </h2>
              <p className="text-xl text-gray-600">
                Common questions about our privacy practices and your data
                rights.
              </p>
            </div>
            <div className="w-full">
              {faqs.map((faq, index) => (
                <div
                  key={index}
                  className="border border-gray-200 rounded-lg mb-4"
                >
                  <button
                    onClick={() => toggleAccordion(index)}
                    className="w-full px-6 py-4 text-left flex justify-between items-center hover:bg-gray-50 transition-colors"
                  >
                    <span className="font-semibold text-gray-900">
                      {faq.question}
                    </span>
                    <ChevronDown
                      className={`h-5 w-5 text-gray-500 transition-transform ${
                        openAccordionItem === index ? "rotate-180" : ""
                      }`}
                    />
                  </button>
                  {openAccordionItem === index && (
                    <div className="px-6 pb-4 text-gray-600 leading-relaxed">
                      {faq.answer}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-24 bg-gradient-to-br from-teal-600 via-emerald-600 to-cyan-800 text-white">
          <div className="container mx-auto px-4 text-center">
            <div className="max-w-3xl mx-auto space-y-8">
              <h2 className="text-4xl md:text-5xl font-bold">
                Trust & Transparency
              </h2>
              <p className="text-xl text-white/80">
                Your privacy is fundamental to how we operate. We're committed
                to earning and maintaining your trust through transparent data
                practices.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <button className="bg-white text-teal-600 hover:bg-gray-100 px-8 py-4 rounded-lg font-semibold shadow-lg transition-all inline-flex items-center justify-center">
                  <Shield className="mr-2 h-5 w-5" />
                  View Security Features
                </button>
                <button className="border border-white text-white hover:bg-white hover:text-teal-600 px-8 py-4 rounded-lg font-semibold transition-all inline-flex items-center justify-center">
                  <Mail className="mr-2 h-5 w-5" />
                  Contact Privacy Team
                </button>
              </div>
              <div className="flex flex-wrap justify-center items-center gap-8 pt-8 opacity-80">
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-5 w-5" />
                  <span>GDPR Compliant</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-5 w-5" />
                  <span>ISO 27001 Certified</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-5 w-5" />
                  <span>Data Encrypted</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-5 w-5" />
                  <span>Regular Audits</span>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default Privacy;
