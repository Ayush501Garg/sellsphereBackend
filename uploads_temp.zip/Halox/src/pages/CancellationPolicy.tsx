import { useState } from "react";
import {
  Mail,
  XCircle,
  Timer,
  FileText,
  Ban,
  CheckCircle,
  AlertTriangle,
} from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import {
  Accordion,
  AccordionItem,
  AccordionTrigger,
  AccordionContent,
} from "@/components/ui/accordion";
import { Helmet } from "react-helmet-async";
import { motion } from "framer-motion";

const CancellationPolicy = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: "",
  });

  const faqs = [
    {
      question: "How long do I have to cancel my order?",
      answer:
        "Orders can be canceled within 24 hours of placement. After this period, cancellation is not possible as the order may already be processed and shipped.",
    },
    {
      question: "How do I cancel my order?",
      answer:
        "To cancel, contact our customer service team immediately at info@thelivsmart.com with your order number and reason for cancellation.",
    },
    {
      question: "Will I get a full refund if I cancel?",
      answer:
        "Yes, if the cancellation request is made within 24 hours, a full refund will be issued to the original payment method.",
    },
    {
      question: "How long does the refund take to show up?",
      answer:
        "Refunds are processed within 30 business days. Depending on your bank or financial institution, additional time may be required for the funds to appear.",
    },
    {
      question: "Can I cancel after my order is shipped?",
      answer:
        "No, orders that have already been shipped cannot be canceled. You may instead refer to the Return Policy once the item is delivered.",
    },
    {
      question: "Can the cancellation policy change?",
      answer:
        "Yes. LivSmart Automation and Security reserves the right to modify or update this policy at any time without prior notice.",
    },
  ];

  const faqLd = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: faqs.map((f) => ({
      "@type": "Question",
      name: f.question,
      acceptedAnswer: { "@type": "Answer", text: f.answer },
    })),
  };

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.MouseEvent<HTMLButtonElement>) => {
    e.preventDefault();
    console.log("Form submitted:", formData);
    setFormData({ name: "", email: "", message: "" });
  };

  const canonical =
    typeof window !== "undefined"
      ? `${window.location.origin}/cancellation-policy`
      : "/cancellation-policy";

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Halox Cancellation Policy | LivSmart Automation</title>
        <meta
          name="description"
          content="Review Halox's Cancellation Policy. Learn about cancellation timelines, refund process, exceptions, and steps to cancel your order."
        />
        <link rel="canonical" href={canonical} />
        <script type="application/ld+json">{JSON.stringify(faqLd)}</script>
      </Helmet>

      <Header />

      <main>
        {/* Hero Section */}
        <section className="relative min-h-[80vh] flex items-center justify-center overflow-hidden bg-gradient-to-br from-red-700 via-pink-600 to-purple-700">
          <div className="absolute inset-0 opacity-20">
            <div className="absolute inset-0 bg-white/10 bg-[radial-gradient(circle_at_1px_1px,rgba(255,255,255,0.25)_1px,transparent_0)] bg-[length:20px_20px] animate-pulse"></div>
          </div>
          <div className="container mx-auto px-4 relative z-10">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="text-center space-y-8"
            >
              <div className="inline-flex items-center bg-white/20 text-white border border-white/40 backdrop-blur-md rounded-full px-5 py-2">
                <XCircle className="h-5 w-5 mr-2" />
                Cancellation Policy
              </div>
              <h1 className="text-4xl md:text-6xl lg:text-7xl font-extrabold text-white leading-tight">
                Simple & Transparent Cancellations
                <span className="block text-orange-300 mt-2">
                  Hassle-Free Process
                </span>
              </h1>
              <p className="text-lg md:text-xl text-white/80 max-w-3xl mx-auto">
                Orders can be cancelled within 24 hours. Learn more about our
                refund and cancellation process.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="bg-orange-500 hover:bg-orange-600 text-white px-8 py-4 rounded-xl font-semibold shadow-lg transition flex items-center justify-center"
                >
                  <Mail className="mr-2 h-5 w-5" />
                  Contact Support
                </motion.button>
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="border border-white text-white hover:bg-white hover:text-red-700 px-8 py-4 rounded-xl font-semibold transition flex items-center justify-center"
                >
                  <FileText className="mr-2 h-5 w-5" />
                  View Policy
                </motion.button>
              </div>
            </motion.div>
          </div>
        </section>

        {/* Policy Highlights */}
        <section className="py-24 bg-gradient-to-b from-white to-gray-50">
          <div className="container mx-auto px-4 grid md:grid-cols-3 gap-10">
            {[
              {
                icon: Timer,
                title: "24-Hour Window",
                description:
                  "Cancel your order within 24 hours of placement for a full refund.",
              },
              {
                icon: Mail,
                title: "Easy Process",
                description:
                  "Email us with your order number and reason — our team will confirm promptly.",
              },
              {
                icon: CheckCircle,
                title: "Full Refund",
                description:
                  "Refunds for cancellations are issued in full to the original payment method.",
              },
              {
                icon: Ban,
                title: "Exceptions",
                description:
                  "Orders already shipped cannot be canceled. Please use our Return Policy instead.",
              },
              {
                icon: AlertTriangle,
                title: "Refund Timeline",
                description:
                  "Refunds are processed within 30 business days, subject to bank processing times.",
              },
            ].map((item, idx) => (
              <motion.div
                key={item.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: idx * 0.1 }}
                className="bg-white p-8 rounded-3xl shadow-md border hover:shadow-xl transition"
              >
                <item.icon className="h-10 w-10 text-red-600 mb-4" />
                <h3 className="text-xl font-semibold mb-2">{item.title}</h3>
                <p className="text-gray-600 leading-relaxed">
                  {item.description}
                </p>
              </motion.div>
            ))}
          </div>
        </section>

        {/* Contact Form */}
        <section className="py-24 bg-gray-50">
          <div className="container mx-auto px-4 max-w-3xl">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
              className="text-center mb-16"
            >
              <div className="inline-block mb-4 bg-red-100 text-red-600 px-4 py-2 rounded-full text-sm font-medium">
                Get in Touch
              </div>
              <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
                Need Help Canceling?
              </h2>
              <p className="text-xl text-gray-600">
                Contact us at{" "}
                <span className="font-semibold">care@thelivsmart.com</span> for
                quick assistance with cancellation.
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="bg-white rounded-3xl p-8 shadow-lg border border-gray-100"
            >
              <div className="space-y-6">
                <div>
                  <label
                    htmlFor="name"
                    className="block text-sm font-medium text-gray-700 mb-2"
                  >
                    Name
                  </label>
                  <input
                    type="text"
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-red-500 focus:border-transparent"
                    placeholder="Your Name"
                  />
                </div>
                <div>
                  <label
                    htmlFor="email"
                    className="block text-sm font-medium text-gray-700 mb-2"
                  >
                    Email
                  </label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-red-500 focus:border-transparent"
                    placeholder="Your Email"
                  />
                </div>
                <div>
                  <label
                    htmlFor="message"
                    className="block text-sm font-medium text-gray-700 mb-2"
                  >
                    Message
                  </label>
                  <textarea
                    id="message"
                    name="message"
                    value={formData.message}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-red-500 h-32"
                    placeholder="How can we assist you with cancellation?"
                  ></textarea>
                </div>
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={handleSubmit}
                  className="w-full bg-red-600 hover:bg-red-700 text-white px-8 py-3 rounded-lg font-semibold flex items-center justify-center"
                >
                  <Mail className="mr-2 h-5 w-5" />
                  Send Message
                </motion.button>
              </div>
            </motion.div>
          </div>
        </section>

        {/* FAQ Section */}
        <section className="py-24 bg-white">
          <div className="container mx-auto px-4 max-w-4xl">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
              className="text-center mb-16"
            >
              <div className="inline-block mb-4 bg-red-100 text-red-600 px-4 py-2 rounded-full text-sm font-medium">
                FAQ
              </div>
              <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
                Cancellation FAQs
              </h2>
              <p className="text-xl text-gray-600">
                Get answers to common questions about cancellations and refunds.
              </p>
            </motion.div>
            <Accordion type="single" collapsible className="w-full">
              {faqs.map((faq, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                >
                  <AccordionItem value={`item-${index}`}>
                    <AccordionTrigger className="text-left text-lg font-semibold">
                      {faq.question}
                    </AccordionTrigger>
                    <AccordionContent className="text-gray-600">
                      {faq.answer}
                    </AccordionContent>
                  </AccordionItem>
                </motion.div>
              ))}
            </Accordion>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
};

export default CancellationPolicy;
