import React from "react";
import { useState } from "react";
import {
  Download,
  Smartphone,
  CheckCircle,
  Play,
  Star,
  ArrowRight,
  Phone,
  Mail,
} from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import {
  Accordion,
  AccordionItem,
  AccordionTrigger,
  AccordionContent,
} from "@/components/ui/accordion";
import { Helmet } from "react-helmet-async";

const DownloadPage = () => {
  const [activePlatform, setActivePlatform] = useState(0);

  const platforms = [
    {
      icon: Smartphone,
      title: "Android",
      description:
        "Download Halox Smart on your Android device from the Google Play Store. Compatible with Android 6.0+.",
      color: "bg-green-100 text-green-600",
      storeLink: "#android",
      demo: "Install in under 1 minute",
    },
    {
      icon: Smartphone,
      title: "iOS",
      description:
        "Get Halox Smart on your iPhone or iPad from the App Store. Requires iOS 12.0 or later.",
      color: "bg-blue-100 text-blue-600",
      storeLink: "#ios",
      demo: "Seamless Apple integration",
    },
  ];

  const faqs = [
    {
      question: "Is the Halox Smart app free to download?",
      answer:
        "Yes, the Halox Smart app is completely free to download and use on both Android and iOS. There are no subscription fees or hidden charges.",
    },
    {
      question: "What are the system requirements for the app?",
      answer:
        "For Android, the app requires Android 6.0 or higher. For iOS, it requires iOS 12.0 or later. Ensure your device has an active internet connection for optimal performance.",
    },
    {
      question: "Can I download the app outside India?",
      answer:
        "Yes, Halox Smart is available in 15+ countries. You can download it from the Google Play Store or App Store in supported regions.",
    },
    {
      question: "How do I update the Halox Smart app?",
      answer:
        "Enable auto-updates in your device's app store settings, or manually check for updates in the Google Play Store or App Store to get the latest features and security improvements.",
    },
    {
      question: "Is there a desktop version of the Halox Smart app?",
      answer:
        "Currently, Halox Smart is designed for mobile devices. However, you can access some features via our web portal using a browser on your desktop.",
    },
  ];

  const faqLd = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: faqs.map((f) => ({
      "@type": "Question",
      name: f.question,
      acceptedAnswer: { "@type": "Answer", text: f.answer },
    })),
  };

  const canonical =
    typeof window !== "undefined"
      ? `${window.location.origin}/download`
      : "/download";

  return (          
    <div className="min-h-screen bg-background">
      <Header />
      {/* SEO Meta Tags */}
      <Helmet>
        <title>Download Halox Smart App | Android & iOS</title>
        <meta
          name="description"
          content="Download Halox Smart app for Android and iOS. Control your smart home with India's most advanced IoT app, free and secure."
        />
        <link rel="canonical" href={canonical} />
        <script type="application/ld+json">{JSON.stringify(faqLd)}</script>
      </Helmet>


      <main>
        {/* Hero Section */}
        <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-gradient-to-br from-blue-600 via-purple-600 to-blue-800">
          <div className="absolute inset-0 opacity-10">
            <div className="absolute inset-0 bg-white/5 bg-[radial-gradient(circle_at_1px_1px,rgba(255,255,255,0.15)_1px,transparent_0)] bg-[length:20px_20px] animate-pulse"></div>
          </div>

          <div className="container mx-auto px-4 relative z-10">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <div className="text-center lg:text-left space-y-8">
                <div className="space-y-4">
                  <div className="inline-flex items-center bg-white/20 text-white border border-white/30 backdrop-blur-sm rounded-full px-4 py-2">
                    <Smartphone className="h-3 w-3 mr-1" />
                    Made in India 🇮🇳
                  </div>
                  <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold text-white leading-tight">
                    Download
                    <span className="block text-orange-300">Halox Smart</span>
                  </h1>
                  <p className="text-lg md:text-xl text-white/80 max-w-2xl">
                    Get India's most advanced IoT app on your Android or iOS
                    device. Control your smart home anytime, anywhere.
                  </p>
                </div>
                <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
                  <button className="bg-orange-500 hover:bg-orange-600 text-white px-8 py-4 rounded-lg font-semibold shadow-lg transition-all flex items-center justify-center">
                    <Download className="mr-2 h-5 w-5" />
                    Download for Android
                  </button>
                  <button className="border border-white text-white hover:bg-white hover:text-blue-600 px-8 py-4 rounded-lg font-semibold transition-all flex items-center justify-center">
                    <Download className="mr-2 h-5 w-5" />
                    Download for iOS
                  </button>
                </div>
                <div className="flex flex-col sm:flex-row gap-4 items-center justify-center lg:justify-start pt-4">
                  <span className="text-white/60 text-sm">Available on:</span>
                  <div className="flex gap-3">
                    <button className="bg-white/10 hover:bg-white/20 text-white px-4 py-2 rounded-lg text-sm transition-all flex items-center">
                      <Download className="mr-2 h-4 w-4" />
                      Play Store
                    </button>
                    <button className="bg-white/10 hover:bg-white/20 text-white px-4 py-2 rounded-lg text-sm transition-all flex items-center">
                      <Download className="mr-2 h-4 w-4" />
                      App Store
                    </button>
                  </div>
                </div>
              </div>
              <div className="relative">
                <div className="relative mx-auto max-w-sm">
                  <div className="relative bg-gray-900 rounded-[3rem] p-3 shadow-2xl">
                    <div className="bg-black rounded-[2.5rem] overflow-hidden">
                      <div className="bg-gradient-to-br from-blue-50 to-purple-50 min-h-[640px] relative">
                        <div className="flex justify-between items-center p-4 text-black text-sm">
                          <span className="font-medium">9:41</span>
                          <div className="flex items-center gap-1">
                            <div className="w-4 h-2 bg-green-500 rounded-sm"></div>
                            <span className="text-xs">100%</span>
                          </div>
                        </div>
                        <div className="px-6 py-4">
                          <div className="flex items-center justify-between mb-6">
                            <div>
                              <h2 className="text-2xl font-bold text-gray-900">
                                Download Now
                              </h2>
                              <p className="text-gray-600">
                                Get started with Halox Smart
                              </p>
                            </div>
                            <div className="bg-white rounded-full p-3 shadow-sm">
                              <Download className="h-6 w-6 text-blue-600" />
                            </div>
                          </div>
                          <div className="space-y-4">
                            <button className="w-full bg-green-500 text-white rounded-xl p-4 flex items-center justify-between shadow-sm">
                              <div className="flex items-center gap-3">
                                <Smartphone className="h-8 w-8" />
                                <div>
                                  <p className="font-medium text-left">
                                    Google Play Store
                                  </p>
                                  <p className="text-xs">Android 6.0+</p>
                                </div>
                              </div>
                              <Download className="h-5 w-5" />
                            </button>
                            <button className="w-full bg-blue-500 text-white rounded-xl p-4 flex items-center justify-between shadow-sm">
                              <div className="flex items-center gap-3">
                                <Smartphone className="h-8 w-8" />
                                <div>
                                  <p className="font-medium text-left">
                                    App Store
                                  </p>
                                  <p className="text-xs">iOS 12.0+</p>
                                </div>
                              </div>
                              <Download className="h-5 w-5" />
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="absolute -top-6 -right-6 bg-orange-500/20 backdrop-blur-sm rounded-full p-4 animate-bounce">
                    <Download className="h-6 w-6 text-orange-500" />
                  </div>
                  <div className="absolute -bottom-6 -left-6 bg-blue-500/20 backdrop-blur-sm rounded-full p-4 animate-pulse">
                    <Smartphone className="h-6 w-6 text-blue-500" />
                  </div>
                </div>
              </div>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mt-16 pt-8 border-t border-white/20">
              {[
                { label: "App Downloads", value: "2.5M+", icon: Download },
                { label: "App Rating", value: "4.8★", icon: Star },
                { label: "Countries", value: "15+", icon: Smartphone },
                { label: "Install Time", value: "< 1 min", icon: CheckCircle },
              ].map((stat) => (
                <div key={stat.label} className="text-center text-white">
                  <stat.icon className="h-6 w-6 mx-auto mb-2 text-orange-300" />
                  <div className="text-2xl font-bold">{stat.value}</div>
                  <div className="text-sm text-white/60">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Download Platforms Section */}
        <section className="py-24 bg-white">
          <div className="container mx-auto px-4">
            <div className="text-center mb-16">
              <div className="inline-block mb-4 bg-blue-100 text-blue-600 px-4 py-2 rounded-full text-sm font-medium">
                Platforms
              </div>
              <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
                Available on Android & iOS
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Download Halox Smart on your preferred platform and start
                controlling your smart home today.
              </p>
            </div>
            <div className="grid md:grid-cols-2 gap-8">
              {platforms.map((platform, index) => (
                <div
                  key={platform.title}
                  className="group bg-gradient-to-br from-white to-gray-50 rounded-3xl p-8 border border-gray-100 hover:border-transparent hover:shadow-2xl transition-all duration-500 hover:transform hover:-translate-y-2 cursor-pointer relative overflow-hidden"
                  onMouseEnter={() => setActivePlatform(index)}
                >
                  <div className="absolute inset-0 bg-gradient-to-br from-blue-600/5 via-purple-600/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                  <div
                    className={`${platform.color} w-16 h-16 rounded-2xl flex items-center justify-center mb-6 shadow-lg group-hover:shadow-xl transition-all duration-300 group-hover:scale-110 relative z-10`}
                  >
                    <platform.icon className="h-8 w-8 transition-transform duration-300 group-hover:scale-110" />
                    <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-white/20 to-transparent"></div>
                  </div>
                  <div className="relative z-10">
                    <h3 className="text-2xl font-bold text-gray-900 mb-4 group-hover:text-blue-700 transition-colors duration-300">
                      {platform.title}
                    </h3>
                    <p className="text-gray-600 mb-4 leading-relaxed group-hover:text-gray-700 transition-colors duration-300">
                      {platform.description}
                    </p>
                    <div className="inline-flex items-center gap-2 text-sm font-semibold px-4 py-2 bg-blue-50 text-blue-600 rounded-full group-hover:bg-blue-100 transition-all duration-300">
                      <div className="w-2 h-2 bg-blue-400 rounded-full animate-pulse"></div>
                      {platform.demo}
                    </div>
                  </div>
                  <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-br from-blue-400/10 to-purple-400/10 rounded-full transform translate-x-8 -translate-y-8 group-hover:scale-150 transition-transform duration-500"></div>
                  <div className="absolute bottom-0 left-0 w-16 h-16 bg-gradient-to-tr from-orange-400/10 to-pink-400/10 rounded-full transform -translate-x-4 translate-y-4 group-hover:scale-125 transition-transform duration-500"></div>
                </div>
              ))}
            </div>
            <div className="text-center mt-12">
              <button className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 rounded-lg font-semibold transition-all inline-flex items-center">
                Watch Installation Guide
                <Play className="ml-2 h-4 w-4" />
              </button>
            </div>
          </div>
        </section>

        {/* FAQ Section */}
        <section className="py-24 bg-white">
          <div className="container mx-auto px-4 max-w-4xl">
            <div className="text-center mb-16">
              <div className="inline-block mb-4 bg-indigo-100 text-indigo-600 px-4 py-2 rounded-full text-sm font-medium">
                FAQ
              </div>
              <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
                Frequently Asked Questions
              </h2>
              <p className="text-xl text-gray-600">
                Everything you need to know about downloading Halox Smart.
              </p>
            </div>
            <Accordion type="single" collapsible className="w-full">
              {faqs.map((faq, index) => (
                <AccordionItem key={index} value={`item-${index}`}>
                  <AccordionTrigger>{faq.question}</AccordionTrigger>
                  <AccordionContent>{faq.answer}</AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </div>
        </section>

        {/* Final CTA Section */}
        <section className="py-24 bg-gradient-to-br from-blue-600 via-purple-600 to-blue-800 text-white">
          <div className="container mx-auto px-4 text-center">
            <div className="max-w-3xl mx-auto space-y-8">
              <h2 className="text-4xl md:text-5xl font-bold">
                Start Your Smart Home Journey
              </h2>
              <p className="text-xl text-white/80">
                Download Halox Smart now and take control of your smart home
                with ease. Free, secure, and built for India.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <button className="bg-white text-blue-600 hover:bg-gray-100 px-8 py-4 rounded-lg font-semibold shadow-lg transition-all inline-flex items-center justify-center">
                  <Download className="mr-2 h-5 w-5" />
                  Download for Android
                </button>
                <button className="border border-white text-white hover:bg-white hover:text-blue-600 px-8 py-4 rounded-lg font-semibold transition-all inline-flex items-center justify-center">
                  <Download className="mr-2 h-5 w-5" />
                  Download for iOS
                </button>
              </div>
              <div className="flex flex-wrap justify-center items-center gap-8 pt-8 opacity-80">
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-5 w-5" />
                  <span>Free Download</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-5 w-5" />
                  <span>No Ads</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-5 w-5" />
                  <span>Regular Updates</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-5 w-5" />
                  <span>24/7 Support</span>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
};

export default DownloadPage;
