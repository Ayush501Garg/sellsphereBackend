import { useState, useEffect } from "react";
import {
  Zap,
  Wifi,
  Smartphone,
  Clock,
  Shield,
  Star,
  CheckCircle,
  Mail,
  Phone,
  Truck,
  RefreshCw,
  CreditCard,
  ChevronDown,
  ShoppingCart,
  Heart,
  Share2,
  Volume2,
  Settings,
  Timer,
  Home,
  Lightbulb,
  Coffee,
  Filter,
  Search,
  Grid3x3,
  List,
  Eye,
  ArrowRight,
  Tag,
  Palette,
  Music,
  ToggleLeft,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

const ProductsPage = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [sortBy, setSortBy] = useState("popularity");
  const [viewMode, setViewMode] = useState("grid");
  const [priceFilter, setPriceFilter] = useState("all");
  const [currentSlide, setCurrentSlide] = useState(0);

  const products = [
    {
      id: 1,
      name: "Wi-Fi Smart Plug 10A",
      category: "smart-plugs",
      price: 499,
      originalPrice: 1199,
      rating: 4.8,
      reviews: 234,
      inStock: 45,
      image: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=1920&h=1080&fit=crop",
      description: "Control your devices remotely with this 10A smart plug compatible with Alexa and Google Home.",
      features: ["10A Rating", "Wi-Fi Control", "Voice Control", "App Control", "Timer Function"],
      badge: "Best Seller"
    },
    {
      id: 2,
      name: "Wi-Fi Smart Plug 16A",
      category: "smart-plugs",
      price: 699,
      originalPrice: 1599,
      rating: 4.9,
      reviews: 189,
      inStock: 32,
      image: "https://images.unsplash.com/photo-1518639192441-8fce0c17836b?w=1920&h=1080&fit=crop",
      description: "Heavy-duty 16A smart plug perfect for ACs, geysers, and high-power appliances.",
      features: ["16A Heavy Duty", "3520W Max Load", "Wi-Fi Control", "Voice Control", "Energy Monitoring"],
      badge: "Heavy Duty"
    },
    {
      id: 3,
      name: "4 Gang Smart Touch Switch (Black)",
      category: "switches",
      price: 999,
      originalPrice: 4999,
      rating: 4.7,
      reviews: 156,
      inStock: 28,
      image: "https://images.unsplash.com/photo-1621905251918-48416bd8575a?w=1920&h=1080&fit=crop",
      description: "Premium 4-gang touch switch with sleek black finish for modern homes.",
      features: ["4 Gang Control", "Touch Interface", "Wi-Fi Enabled", "Voice Control", "Modern Design"],
      badge: "Premium"
    },
    {
      id: 4,
      name: "4 Gang Smart Touch Switch (White)",
      category: "switches",
      price: 999,
      originalPrice: 4999,
      rating: 4.7,
      reviews: 142,
      inStock: 35,
      image: "https://images.unsplash.com/photo-1581092160562-40aa08e78837?w=1920&h=1080&fit=crop",
      description: "Elegant white 4-gang touch switch perfect for contemporary interiors.",
      features: ["4 Gang Control", "Touch Interface", "Wi-Fi Enabled", "Voice Control", "Elegant White"],
      badge: "Popular"
    },
    {
      id: 5,
      name: "24A Smart Touch Switch (Black)",
      category: "switches",
      price: 1999,
      originalPrice: 4999,
      rating: 4.6,
      reviews: 98,
      inStock: 18,
      image: "https://images.unsplash.com/photo-1558618047-3c8c76ca7d13?w=1920&h=1080&fit=crop",
      description: "High-capacity 24A touch switch for controlling heavy electrical loads.",
      features: ["24A High Load", "Touch Control", "Wi-Fi Enabled", "Safety Certified", "Premium Build"],
      badge: "High Power"
    },
    {
      id: 6,
      name: "24A Smart Touch Switch (White)",
      category: "switches",
      price: 1999,
      originalPrice: 4999,
      rating: 4.6,
      reviews: 87,
      inStock: 22,
      image: "https://images.unsplash.com/photo-1547036967-23d11aacaee0?w=1920&h=1080&fit=crop",
      description: "Professional white 24A touch switch for commercial and residential use.",
      features: ["24A High Load", "Touch Control", "Wi-Fi Enabled", "Professional Grade", "White Finish"],
      badge: "Professional"
    },
    {
      id: 7,
      name: "Smart Fan Regulator Touch Switch",
      category: "switches",
      price: 1999,
      originalPrice: 4999,
      rating: 4.5,
      reviews: 125,
      inStock: 26,
      image: "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=1920&h=1080&fit=crop",
      description: "Variable speed fan control with smart features and remote access.",
      features: ["Fan Speed Control", "Touch Interface", "Remote Control", "Timer Function", "Energy Saving"],
      badge: "Smart Control"
    },
    {
      id: 8,
      name: "Smart Fan Touch Switch (Black)",
      category: "switches",
      price: 1999,
      originalPrice: 4999,
      rating: 4.5,
      reviews: 103,
      inStock: 31,
      image: "https://images.unsplash.com/photo-1574269909862-7e1d70bb8078?w=1920&h=1080&fit=crop",
      description: "Sleek black fan control switch with smart connectivity and touch control.",
      features: ["Fan Control", "Touch Interface", "Wi-Fi Enabled", "Black Design", "Speed Control"],
      badge: "Stylish"
    },
    {
      id: 9,
      name: "Multicolor LED Strip Kit (Waterproof)",
      category: "lighting",
      price: 1999,
      originalPrice: 2599,
      rating: 4.8,
      reviews: 267,
      inStock: 58,
      image: "https://images.unsplash.com/photo-1518709268805-4e9042af2176?w=1920&h=1080&fit=crop",
      description: "5-meter waterproof RGB LED strip with music sync and voice control.",
      features: ["5M Waterproof", "Music Sync", "16M Colors", "Voice Control", "No Hub Required"],
      badge: "Trending"
    },
    {
      id: 10,
      name: "Smart LED Strip Kit (Indoor)",
      category: "lighting",
      price: 1099,
      originalPrice: 1999,
      rating: 4.7,
      reviews: 198,
      inStock: 42,
      image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=1920&h=1080&fit=crop",
      description: "5-meter indoor RGB LED strip with app control and music synchronization.",
      features: ["5M Length", "Music Sync", "App Control", "Easy Install", "Multiple Effects"],
      badge: "Value Pack"
    },
    {
      id: 11,
      name: "Smart LED Bulb 9W (RGB)",
      category: "lighting",
      price: 499,
      originalPrice: 899,
      rating: 4.6,
      reviews: 156,
      inStock: 80,
      image: "https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?w=1920&h=1080&fit=crop",
      description: "Energy-efficient 9W RGB smart bulb with voice and app control.",
      features: ["9W LED", "16M Colors", "Wi-Fi Enabled", "Alexa & Google Home", "Schedules"],
      badge: "Energy Saver"
    },
    {
      id: 12,
      name: "Smart LED Bulb 12W (Warm White)",
      category: "lighting",
      price: 599,
      originalPrice: 1099,
      rating: 4.5,
      reviews: 120,
      inStock: 65,
      image: "https://images.unsplash.com/photo-1504384308090-c894fdcc538d?w=1920&h=1080&fit=crop",
      description: "Bright 12W warm white smart bulb for home and office lighting.",
      features: ["12W Bright", "Warm White", "App Control", "Energy Efficient", "Dimmable"],
      badge: "Bright"
    },
    {
      id: 13,
      name: "Smart Motion Sensor",
      category: "sensors",
      price: 899,
      originalPrice: 1599,
      rating: 4.6,
      reviews: 89,
      inStock: 50,
      image: "https://images.unsplash.com/photo-1597764692802-084d0f312ed1?w=1920&h=1080&fit=crop",
      description: "Detects motion and integrates with smart home systems for automation.",
      features: ["Motion Detection", "Wi-Fi", "App Alerts", "Compact", "Battery Operated"],
      badge: "Secure"
    },
    {
      id: 14,
      name: "Smart Door Sensor",
      category: "sensors",
      price: 799,
      originalPrice: 1499,
      rating: 4.5,
      reviews: 110,
      inStock: 45,
      image: "https://images.unsplash.com/photo-1588776814546-d6893faba8f9?w=1920&h=1080&fit=crop",
      description: "Get notified when doors or windows open or close.",
      features: ["Magnetic Sensor", "Wi-Fi Enabled", "Instant Alerts", "Easy Setup", "Compact"],
      badge: "Home Safe"
    },
    {
      id: 15,
      name: "Smart Security Camera (Indoor)",
      category: "cameras",
      price: 2499,
      originalPrice: 4999,
      rating: 4.7,
      reviews: 214,
      inStock: 38,
      image: "https://images.unsplash.com/photo-1587049352848-8e7a0b2d2c64?w=1920&h=1080&fit=crop",
      description: "1080p indoor camera with night vision and motion alerts.",
      features: ["1080p HD", "Night Vision", "Two-Way Audio", "Wi-Fi Enabled", "Motion Detection"],
      badge: "Top Pick"
    },
    {
      id: 16,
      name: "Smart Security Camera (Outdoor)",
      category: "cameras",
      price: 3499,
      originalPrice: 6999,
      rating: 4.8,
      reviews: 176,
      inStock: 27,
      image: "https://images.unsplash.com/photo-1557324232-b8917d3c3dcb?w=1920&h=1080&fit=crop",
      description: "Weatherproof outdoor camera with HD video and cloud storage.",
      features: ["Weatherproof", "1080p HD", "Wi-Fi", "Motion Alerts", "Cloud Storage"],
      badge: "Outdoor Ready"
    },
    {
      id: 17,
      name: "Smart Video Doorbell",
      category: "cameras",
      price: 3999,
      originalPrice: 7999,
      rating: 4.6,
      reviews: 142,
      inStock: 30,
      image: "https://images.unsplash.com/photo-1617727553256-4f41fddc4e1f?w=1920&h=1080&fit=crop",
      description: "Answer your door from anywhere with live video and two-way audio.",
      features: ["HD Video", "Two-Way Audio", "Motion Alerts", "Wi-Fi Enabled", "Cloud Storage"],
      badge: "Visitor Guard"
    },
    {
      id: 18,
      name: "Smart Thermostat",
      category: "climate",
      price: 4999,
      originalPrice: 9999,
      rating: 4.7,
      reviews: 105,
      inStock: 22,
      image: "https://images.unsplash.com/photo-1581167763386-e9a3a4d3fba7?w=1920&h=1080&fit=crop",
      description: "Control your home’s temperature intelligently with energy savings.",
      features: ["Auto Scheduling", "Wi-Fi Control", "Voice Assistant", "Energy Reports", "Touch Screen"],
      badge: "Energy Saver"
    },
    {
      id: 19,
      name: "Smart Air Purifier",
      category: "climate",
      price: 6999,
      originalPrice: 12999,
      rating: 4.8,
      reviews: 88,
      inStock: 18,
      image: "https://images.unsplash.com/photo-1618220029939-9fddda63a6e0?w=1920&h=1080&fit=crop",
      description: "HEPA filter smart purifier with app and voice control.",
      features: ["HEPA Filter", "Wi-Fi", "Voice Control", "App Monitor", "Compact Design"],
      badge: "Clean Air"
    },
    {
      id: 20,
      name: "Smart Curtain Controller",
      category: "automation",
      price: 3499,
      originalPrice: 6999,
      rating: 4.6,
      reviews: 77,
      inStock: 25,
      image: "https://images.unsplash.com/photo-1607746882042-944635dfe10e?w=1920&h=1080&fit=crop",
      description: "Automate your curtains with app and voice commands.",
      features: ["Wi-Fi", "Voice Control", "Timer Function", "Easy Install", "Remote Access"],
      badge: "Smart Living"
    },
    {
      id: 21,
      name: "Smart Wi-Fi Router Plug",
      category: "smart-plugs",
      price: 799,
      originalPrice: 1599,
      rating: 4.4,
      reviews: 65,
      inStock: 34,
      image: "https://images.unsplash.com/photo-1527443154391-507e9dc6c5cc?w=1920&h=1080&fit=crop",
      description: "Special plug to auto restart routers with scheduled power cycles.",
      features: ["Auto Restart", "Wi-Fi Enabled", "App Control", "Energy Saver", "Safe Load"],
      badge: "Router Saver"
    },
    {
      id: 22,
      name: "Smart Coffee Maker",
      category: "kitchen",
      price: 5999,
      originalPrice: 9999,
      rating: 4.5,
      reviews: 56,
      inStock: 15,
      image: "https://images.unsplash.com/photo-1509042239860-f550ce710b93?w=1920&h=1080&fit=crop",
      description: "Brew coffee from your phone or voice assistant.",
      features: ["Wi-Fi Control", "Voice Assistant", "Timer", "Custom Recipes", "Stylish Design"],
      badge: "Morning Essential"
    },
    {
      id: 23,
      name: "Smart Water Leak Sensor",
      category: "sensors",
      price: 899,
      originalPrice: 1699,
      rating: 4.7,
      reviews: 78,
      inStock: 41,
      image: "https://images.unsplash.com/photo-1551218808-94e220e084d2?w=1920&h=1080&fit=crop",
      description: "Get alerts if water leakage is detected.",
      features: ["Leak Detection", "Wi-Fi Alerts", "Compact", "Battery Powered", "App Notifications"],
      badge: "Water Guard"
    },
    {
      id: 24,
      name: "Smart Smoke Detector",
      category: "sensors",
      price: 1299,
      originalPrice: 2499,
      rating: 4.8,
      reviews: 112,
      inStock: 37,
      image: "https://images.unsplash.com/photo-1581092334804-6c72bbf35d02?w=1920&h=1080&fit=crop",
      description: "Smart smoke and fire detection with instant alerts.",
      features: ["Smoke Detection", "Wi-Fi Enabled", "Instant Alerts", "Compact Design", "Easy Install"],
      badge: "Safety"
    },
    {
      id: 25,
      name: "Smart Vacuum Cleaner",
      category: "home-appliances",
      price: 14999,
      originalPrice: 24999,
      rating: 4.7,
      reviews: 201,
      inStock: 19,
      image: "https://images.unsplash.com/photo-1585421514738-01798e348b17?w=1920&h=1080&fit=crop",
      description: "Robotic vacuum with smart mapping and voice control.",
      features: ["Auto Cleaning", "Smart Mapping", "Wi-Fi", "Voice Control", "Recharge Dock"],
      badge: "Robot"
    },
    {
      id: 26,
      name: "Smart Washing Machine Controller",
      category: "home-appliances",
      price: 2599,
      originalPrice: 4999,
      rating: 4.6,
      reviews: 73,
      inStock: 27,
      image: "https://images.unsplash.com/photo-1622551541162-34c238d9cbf4?w=1920&h=1080&fit=crop",
      description: "Add smart control to your washing machine with Wi-Fi.",
      features: ["Wi-Fi Control", "Timer", "Voice Assistant", "Energy Monitoring", "Easy Setup"],
      badge: "Upgrade"
    },
    {
      id: 27,
      name: "Smart IR Remote Controller",
      category: "automation",
      price: 1299,
      originalPrice: 2499,
      rating: 4.6,
      reviews: 92,
      inStock: 39,
      image: "https://images.unsplash.com/photo-1586015559033-986f51b1e9f4?w=1920&h=1080&fit=crop",
      description: "Control all IR devices like AC, TV, and music systems via app.",
      features: ["Universal Remote", "Wi-Fi", "Voice Control", "Compact", "App Integration"],
      badge: "Universal"
    },
  ];

  const categories = [
    { id: "all", name: "All Products", count: products.length },
    { id: "smart-plugs", name: "Smart Plugs", count: products.filter(p => p.category === "smart-plugs").length },
    { id: "switches", name: "Smart Switches", count: products.filter(p => p.category === "switches").length },
    { id: "lighting", name: "Smart Lighting", count: products.filter(p => p.category === "lighting").length },
  ];

  const filteredProducts = products.filter(product => {
    const matchesSearch = product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         product.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === "all" || product.category === selectedCategory;
    const matchesPrice = priceFilter === "all" ||
                        (priceFilter === "under-1000" && product.price < 1000) ||
                        (priceFilter === "1000-2000" && product.price >= 1000 && product.price < 2000) ||
                        (priceFilter === "above-2000" && product.price >= 2000);
    
    return matchesSearch && matchesCategory && matchesPrice;
  });

  const sortedProducts = [...filteredProducts].sort((a, b) => {
    switch (sortBy) {
      case "price-low":
        return a.price - b.price;
      case "price-high":
        return b.price - a.price;
      case "rating":
        return b.rating - a.rating;
      case "newest":
        return b.id - a.id;
      default: // popularity
        return b.reviews - a.reviews;
    }
  });

  // Select featured products for carousel (top-rated products)
  const featuredProducts = products
    .filter(p => p.rating >= 4.7)
    .slice(0, 4);

  // Auto-slide effect for carousel
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % featuredProducts.length);
    }, 5000); // Slide every 5 seconds
    return () => clearInterval(interval);
  }, [featuredProducts.length]);

  // Handle navigation for arrow buttons
  const prevSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % featuredProducts.length); // Left arrow moves to next slide
  };

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + featuredProducts.length) % featuredProducts.length); // Right arrow moves to previous slide
  };

  const ProductCard = ({ product }) => {
    const discount = Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100);
    
    return (
      <div className="group bg-white rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-500 overflow-hidden border border-gray-100 hover:border-transparent">
        <div className="relative overflow-hidden">
          <img
            src={product.image}
            alt={product.name}
            className="w-full h-64 object-cover group-hover:scale-110 transition-transform duration-500"
          />
          <div className="absolute top-4 left-4 flex flex-col gap-2">
            <div className="bg-red-500 text-white px-3 py-1 rounded-full text-xs font-semibold">
              {discount}% OFF
            </div>
            {product.badge && (
              <div className="bg-emerald-500 text-white px-3 py-1 rounded-full text-xs font-semibold">
                {product.badge}
              </div>
            )}
          </div>
          <div className="absolute top-4 right-4 flex flex-col gap-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
            <button className="w-10 h-10 bg-white/90 backdrop-blur-sm rounded-full flex items-center justify-center hover:bg-white transition-colors">
              <Heart className="w-5 h-5 text-gray-600" />
            </button>
            <button className="w-10 h-10 bg-white/90 backdrop-blur-sm rounded-full flex items-center justify-center hover:bg-white transition-colors">
              <Eye className="w-5 h-5 text-gray-600" />
            </button>
            <button className="w-10 h-10 bg-white/90 backdrop-blur-sm rounded-full flex items-center justify-center hover:bg-white transition-colors">
              <Share2 className="w-5 h-5 text-gray-600" />
            </button>
          </div>
        </div>
        
        <div className="p-6">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-1">
              {[1,2,3,4,5].map((star) => (
                <Star key={star} className={`w-4 h-4 ${star <= Math.floor(product.rating) ? 'text-yellow-400 fill-current' : 'text-gray-300'}`} />
              ))}
              <span className="text-sm text-gray-600 ml-1">({product.reviews})</span>
            </div>
            <div className="text-sm text-emerald-600 font-medium">{product.inStock} in stock</div>
          </div>
          
          <h3 className="text-lg font-bold text-gray-900 mb-2 line-clamp-2 group-hover:text-emerald-700 transition-colors">
            {product.name}
          </h3>
          
          <p className="text-gray-600 text-sm mb-4 line-clamp-2">
            {product.description}
          </p>
          
          <div className="flex flex-wrap gap-1 mb-4">
            {product.features.slice(0, 3).map((feature, index) => (
              <span key={index} className="bg-gray-100 text-gray-700 px-2 py-1 rounded-full text-xs">
                {feature}
              </span>
            ))}
            {product.features.length > 3 && (
              <span className="text-gray-500 text-xs">+{product.features.length - 3} more</span>
            )}
          </div>
          
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-baseline gap-2">
              <span className="text-2xl font-bold text-gray-900">
                ₹{product.price.toLocaleString()}
              </span>
              <span className="text-sm text-gray-500 line-through">
                ₹{product.originalPrice.toLocaleString()}
              </span>
            </div>
          </div>
          
          <div className="flex gap-2">
            <button className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold py-3 px-4 rounded-lg flex items-center justify-center gap-2 transition-colors">
              <ShoppingCart className="w-4 h-4" />
              Add to Cart
            </button>
            <button className="px-4 py-3 border border-emerald-600 text-emerald-600 hover:bg-emerald-50 rounded-lg transition-colors">
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />

      {/* Hero Section with Background Carousel */}
      <section className="relative py-16 bg-gradient-to-br from-emerald-600 via-teal-600 to-cyan-600 overflow-hidden">
        <div className="absolute inset-0">
          <div className="relative w-full h-full">
            {featuredProducts.map((product, index) => (
              <div
                key={product.id}
                className={`absolute inset-0 transition-opacity duration-1000 ease-in-out ${
                  index === currentSlide ? "opacity-100" : "opacity-0"
                }`}
              >
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-black/50"></div>
                <div className="absolute bottom-4 left-4 text-white">
                  <div className="inline-flex items-center bg-emerald-500 text-white px-3 py-1 rounded-full text-sm font-semibold mb-2">
                    {product.badge}
                  </div>
                  <h2 className="text-xl md:text-2xl font-bold">{product.name}</h2>
                </div>
              </div>
            ))}
          </div>
          {/* Navigation Arrows */}
          <button
            onClick={prevSlide}
            className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-white/20 text-white p-3 rounded-full hover:bg-white/30 transition-all"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
          <button
            onClick={nextSlide}
            className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-white/20 text-white p-3 rounded-full hover:bg-white/30 transition-all"
          >
            <ChevronRight className="w-6 h-6" />
          </button>
          {/* Navigation Dots */}
          <div className="absolute bottom-4 left-0 right-0 flex justify-center gap-2">
            {featuredProducts.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentSlide(index)}
                className={`w-3 h-3 rounded-full transition-all ${
                  currentSlide === index ? "bg-white scale-125" : "bg-white/50"
                }`}
              ></button>
            ))}
          </div>
        </div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="text-center space-y-6">
            <div className="inline-flex items-center bg-white/20 text-white border border-white/30 backdrop-blur-sm rounded-full px-4 py-2">
              <Zap className="h-4 w-4 mr-2" />
              Smart Home Products
            </div>
            <h1 className="text-4xl md:text-6xl font-bold text-white leading-tight">
              Transform Your Home
              <span className="block text-cyan-300">Into a Smart Home</span>
            </h1>
            <p className="text-lg md:text-xl text-white/80 max-w-3xl mx-auto">
              Discover our complete range of smart home automation products designed and manufactured in India.
            </p>
            <div className="flex flex-wrap justify-center items-center gap-8 pt-8 opacity-80">
              <div className="flex items-center gap-2 text-white">
                <CheckCircle className="h-5 w-5" />
                <span>Made in India</span>
              </div>
              <div className="flex items-center gap-2 text-white">
                <CheckCircle className="h-5 w-5" />
                <span>1 Year Warranty</span>
              </div>
              <div className="flex items-center gap-2 text-white">
                <CheckCircle className="h-5 w-5" />
                <span>Free Shipping</span>
              </div>
              <div className="flex items-center gap-2 text-white">
                <CheckCircle className="h-5 w-5" />
                <span>Easy Returns</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Filters and Search */}
      <section className="py-8 bg-white border-b border-gray-200">
        <div className="container mx-auto px-4">
          <div className="flex flex-col lg:flex-row gap-6 items-start lg:items-center justify-between">
            {/* Search */}
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="text"
                placeholder="Search products..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
              />
            </div>
            
            {/* Filters */}
            <div className="flex flex-wrap gap-4 items-center">
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500"
              >
                {categories.map(category => (
                  <option key={category.id} value={category.id}>
                    {category.name} ({category.count})
                  </option>
                ))}
              </select>
              
              <select
                value={priceFilter}
                onChange={(e) => setPriceFilter(e.target.value)}
                className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500"
              >
                <option value="all">All Prices</option>
                <option value="under-1000">Under ₹1,000</option>
                <option value="1000-2000">₹1,000 - ₹2,000</option>
                <option value="above-2000">Above ₹2,000</option>
              </select>
              
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500"
              >
                <option value="popularity">Sort by Popularity</option>
                <option value="price-low">Price: Low to High</option>
                <option value="price-high">Price: High to Low</option>
                <option value="rating">Highest Rated</option>
                <option value="newest">Newest First</option>
              </select>
              
              <div className="flex border border-gray-300 rounded-lg overflow-hidden">
                <button
                  onClick={() => setViewMode("grid")}
                  className={`p-2 ${viewMode === "grid" ? "bg-emerald-500 text-white" : "bg-white text-gray-700"} transition-colors`}
                >
                  <Grid3x3 className="w-5 h-5" />
                </button>
                <button
                  onClick={() => setViewMode("list")}
                  className={`p-2 ${viewMode === "list" ? "bg-emerald-500 text-white" : "bg-white text-gray-700"} transition-colors`}
                >
                  <List className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Products Grid */}
      <section className="py-12">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h2 className="text-2xl font-bold text-gray-900">
                {selectedCategory === "all" ? "All Products" : categories.find(c => c.id === selectedCategory)?.name}
              </h2>
              <p className="text-gray-600">
                Showing {sortedProducts.length} of {products.length} products
              </p>
            </div>
          </div>
          
          {sortedProducts.length === 0 ? (
            <div className="text-center py-16">
              <div className="text-gray-400 mb-4">
                <Search className="w-16 h-16 mx-auto" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">No products found</h3>
              <p className="text-gray-600">Try adjusting your search or filter criteria</p>
            </div>
          ) : (
            <div className={`grid ${viewMode === "grid" ? "md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4" : "grid-cols-1"} gap-8`}>
              {sortedProducts.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Why Choose Halox Smart Products?
            </h2>
            <p className="text-xl text-gray-600">
              Experience the best in Indian smart home technology
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                icon: Shield,
                title: "1 Year Warranty",
                description: "Comprehensive warranty coverage on all products",
                color: "from-emerald-400 to-emerald-600",
              },
              {
                icon: Truck,
                title: "Free Shipping",
                description: "Free delivery across India on all orders",
                color: "from-blue-400 to-blue-600",
              },
              {
                icon: Volume2,
                title: "Voice Control",
                description: "Compatible with Alexa and Google Assistant",
                color: "from-purple-400 to-purple-600",
              },
              {
                icon: Smartphone,
                title: "Smart App",
                description: "Easy control through our mobile app",
                color: "from-orange-400 to-orange-600",
              },
            ].map((feature, index) => (
              <div key={index} className="text-center group">
                <div className={`w-16 h-16 rounded-2xl flex items-center justify-center mb-4 mx-auto shadow-lg group-hover:shadow-xl transition-all duration-300 group-hover:scale-110 bg-gradient-to-br ${feature.color}`}>
                  <feature.icon className="h-8 w-8 text-white transition-transform duration-300 group-hover:scale-110" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-br from-emerald-600 via-teal-600 to-cyan-800 text-white">
        <div className="container mx-auto px-4 text-center">
          <div className="max-w-3xl mx-auto space-y-8">
            <h2 className="text-3xl md:text-4xl font-bold">
              Ready to Make Your Home Smart?
            </h2>
            <p className="text-xl text-white/80">
              Join thousands of satisfied customers who have transformed their homes with Halox Smart products.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button className="bg-white text-emerald-600 hover:bg-gray-100 px-8 py-4 rounded-lg font-semibold shadow-lg transition-all inline-flex items-center justify-center">
                <ShoppingCart className="mr-2 h-5 w-5" />
                Shop Now
              </button>
              <button className="border border-white text-white hover:bg-white hover:text-emerald-600 px-8 py-4 rounded-lg font-semibold transition-all inline-flex items-center justify-center">
                <Phone className="mr-2 h-5 w-5" />
                Contact Support
              </button>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default ProductsPage;