import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { 
  Search, 
  Filter, 
  Grid3X3, 
  List, 
  ChevronRight,
  Zap,
  Plug,
  Lightbulb,
  Settings,
  ShoppingBag,
  Star,
  TrendingUp,
  Sparkles,
  ShieldCheck,
  Truck,
  Award,
  PlayCircle,
  ArrowRight
} from "lucide-react";

const Shop = () => {
  const [viewMode, setViewMode] = useState('grid');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [currentSlide, setCurrentSlide] = useState(0);

  const heroProducts = [
    { name: "Smart Touch Switch", image: "🎛️", price: "₹1,299" },
    { name: "Smart Plug Pro", image: "🔌", price: "₹899" },
    { name: "LED Strip RGB", image: "💡", price: "₹2,499" }
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % heroProducts.length);
    }, 3000);
    return () => clearInterval(timer);
  }, []);

  const categories = [
    { 
      id: 'smart-plugs', 
      name: 'Smart Plugs', 
      icon: Plug,
      count: 24,
      description: 'Remote control power outlets'
    },
    { 
      id: 'touch-switches', 
      name: 'Touch Switches', 
      icon: Zap,
      count: 18,
      description: 'Modern touch control switches'
    },
    { 
      id: 'led-strips', 
      name: 'LED Strips', 
      icon: Lightbulb,
      count: 12,
      description: 'Colorful ambient lighting'
    },
    { 
      id: 'controllers', 
      name: 'Controllers', 
      icon: Settings,
      count: 8,
      description: 'Advanced device controllers'
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Enhanced Hero Section */}
      <section className="relative min-h-[90vh] bg-gradient-to-br from-slate-900 via-blue-900 to-indigo-900 overflow-hidden">
        {/* Animated Background Elements */}
        <div className="absolute inset-0">
          {/* Floating Orbs */}
          <div className="absolute top-20 left-10 w-32 h-32 bg-blue-500/20 rounded-full blur-xl animate-pulse"></div>
          <div className="absolute top-40 right-20 w-48 h-48 bg-purple-500/20 rounded-full blur-2xl animate-pulse" style={{animationDelay: '1s'}}></div>
          <div className="absolute bottom-20 left-1/4 w-40 h-40 bg-cyan-500/20 rounded-full blur-xl animate-pulse" style={{animationDelay: '2s'}}></div>
          
          {/* Grid Pattern */}
          <div className="absolute inset-0 opacity-10">
            <div className="absolute inset-0 bg-white/5 bg-[radial-gradient(circle_at_1px_1px,rgba(255,255,255,0.15)_1px,transparent_0)] bg-[length:40px_40px]"></div>
          </div>
          
          {/* Gradient Overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent"></div>
        </div>

        <div className="container mx-auto px-4 relative z-10 flex items-center min-h-[90vh]">
          <div className="grid lg:grid-cols-2 gap-12 items-center w-full">
            {/* Left Content */}
            <div className="space-y-8 text-white">
              {/* Badge */}
              <div className="flex items-center gap-4">
                <Badge className="bg-gradient-to-r from-blue-500/20 to-purple-500/20 text-white border-blue-400/30 backdrop-blur-sm px-4 py-2">
                  <Sparkles className="h-4 w-4 mr-2" />
                  Premium Smart Home Collection
                </Badge>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                  <span className="text-green-400 text-sm font-medium">Live Now</span>
                </div>
              </div>
              
              {/* Main Heading */}
              <div className="space-y-6">
                <h1 className="text-5xl md:text-7xl lg:text-8xl font-black leading-none">
                  <span className="block bg-gradient-to-r from-white via-blue-100 to-purple-100 bg-clip-text text-transparent">
                    Transform
                  </span>
                  <span className="block bg-gradient-to-r from-blue-400 via-purple-400 to-cyan-400 bg-clip-text text-transparent animate-pulse">
                    Your Home
                  </span>
                </h1>
                
                <p className="text-xl md:text-2xl text-blue-100 max-w-2xl leading-relaxed">
                  Experience the future with our premium collection of smart switches, plugs, and automation devices. 
                  <span className="text-cyan-400 font-semibold"> Made in India</span> for Indian homes.
                </p>
              </div>

              {/* CTA Buttons */}
              <div className="flex flex-col sm:flex-row gap-4">
                <Button size="lg" className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-bold px-8 py-4 text-lg shadow-2xl hover:shadow-blue-500/25 transform hover:scale-105 transition-all duration-300 group">
                  <ShoppingBag className="mr-2 h-5 w-5 group-hover:scale-110 transition-transform" />
                  Shop Now
                  <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
                </Button>
                
                <Button variant="outline" size="lg" className="border-2 border-white/30 text-white hover:bg-white/10 backdrop-blur-sm px-8 py-4 text-lg group">
                  <PlayCircle className="mr-2 h-5 w-5 group-hover:scale-110 transition-transform" />
                  Watch Demo
                </Button>
              </div>

              {/* Trust Indicators */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-8">
                {[
                  { icon: ShieldCheck, label: "2 Year Warranty", value: "Premium" },
                  { icon: Truck, label: "Free Shipping", value: "₹999+" },
                  { icon: Star, label: "Rating", value: "4.8/5" },
                  { icon: Award, label: "Made in India", value: "Certified" }
                ].map((item, index) => (
                  <div key={item.label} className="text-center group" style={{animationDelay: `${index * 0.1}s`}}>
                    <div className="bg-white/10 backdrop-blur-sm rounded-xl p-3 mb-2 mx-auto w-fit group-hover:bg-white/20 transition-all duration-300">
                      <item.icon className="h-6 w-6 text-cyan-400 mx-auto" />
                    </div>
                    <div className="text-lg font-bold text-white">{item.value}</div>
                    <div className="text-sm text-blue-200">{item.label}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Right Content - Product Showcase */}
            <div className="relative">
              {/* Main Product Display */}
              <div className="relative">
                <div className="absolute inset-0 bg-gradient-to-br from-blue-500/20 via-purple-500/20 to-cyan-500/20 rounded-3xl blur-3xl"></div>
                <Card className="relative z-10 bg-white/10 backdrop-blur-xl border-white/20 shadow-2xl">
                  <CardContent className="p-8">
                    <div className="text-center space-y-6">
                      {/* Product Image */}
                      <div className="text-8xl mb-4 animate-bounce">
                        {heroProducts[currentSlide].image}
                      </div>
                      
                      <div className="space-y-4">
                        <h3 className="text-2xl font-bold text-white">
                          {heroProducts[currentSlide].name}
                        </h3>
                        <div className="text-3xl font-black text-cyan-400">
                          {heroProducts[currentSlide].price}
                        </div>
                        <Badge className="bg-green-500/20 text-green-400 border-green-400/30">
                          ✨ Best Seller
                        </Badge>
                      </div>

                      <Button className="w-full bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-600 hover:to-blue-600 text-white font-semibold">
                        Add to Cart
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Slide Indicators */}
              <div className="flex justify-center mt-6 gap-2">
                {heroProducts.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentSlide(index)}
                    className={`w-3 h-3 rounded-full transition-all duration-300 ${
                      index === currentSlide 
                        ? 'bg-cyan-400 scale-125' 
                        : 'bg-white/30 hover:bg-white/50'
                    }`}
                  />
                ))}
              </div>

              {/* Floating Elements */}
              <div className="absolute -top-10 -left-10 w-20 h-20 bg-yellow-400/20 rounded-full blur-xl animate-pulse"></div>
              <div className="absolute -bottom-10 -right-10 w-32 h-32 bg-pink-400/20 rounded-full blur-xl animate-pulse" style={{animationDelay: '1.5s'}}></div>
            </div>
          </div>
        </div>

        {/* Bottom Wave */}
        <div className="absolute bottom-0 left-0 w-full overflow-hidden">
          <svg className="relative block w-full h-20" viewBox="0 0 1200 120" preserveAspectRatio="none">
            <path d="M0,60 C150,120 350,0 600,60 C850,120 1050,0 1200,60 L1200,120 L0,120 Z" className="fill-background"></path>
          </svg>
        </div>
      </section>

      {/* Quick Features Strip */}
      <section className="py-6 bg-gradient-to-r from-blue-50 to-purple-50 border-b">
        <div className="container mx-auto px-4">
          <div className="flex justify-center items-center">
            <div className="flex items-center gap-8 text-sm">
              <div className="flex items-center gap-2 text-blue-700">
                <Zap className="h-4 w-4" />
                <span className="font-medium">Easy Setup</span>
              </div>
              <div className="h-4 w-px bg-gray-300"></div>
              <div className="flex items-center gap-2 text-purple-700">
                <ShieldCheck className="h-4 w-4" />
                <span className="font-medium">2 Year Warranty</span>
              </div>
              <div className="h-4 w-px bg-gray-300"></div>
              <div className="flex items-center gap-2 text-green-700">
                <Truck className="h-4 w-4" />
                <span className="font-medium">Free Shipping ₹999+</span>
              </div>
            </div>
          </div>
        </div>
      </section>
      
      <main className="container mx-auto px-4 py-8">
        {/* Breadcrumb */}
        <div className="flex items-center gap-2 text-sm text-muted-foreground mb-8">
          <span>Home</span>
          <ChevronRight className="h-4 w-4" />
          <span className="text-foreground font-medium">Shop</span>
        </div>

        {/* Category Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {categories.map((category, index) => {
            const gradientColors = [
              'from-primary/20 via-primary/10 to-transparent',
              'from-secondary/20 via-secondary/10 to-transparent', 
              'from-accent/20 via-accent/10 to-transparent',
              'from-orange-500/20 via-orange-500/10 to-transparent'
            ];
            const iconColors = ['text-primary', 'text-secondary', 'text-accent', 'text-orange-500'];
            const borderColors = ['hover:border-primary', 'hover:border-secondary', 'hover:border-accent', 'hover:border-orange-500'];
            
            return (
              <Card 
                key={category.id} 
                className={`cursor-pointer group hover:shadow-2xl hover:shadow-primary/20 transition-all duration-500 border-2 ${borderColors[index]} hover:scale-105 relative overflow-hidden`}
                onClick={() => setSelectedCategory(category.id)}
              >
                <div className={`absolute inset-0 bg-gradient-to-br ${gradientColors[index]} opacity-0 group-hover:opacity-100 transition-opacity duration-500`}></div>
                <CardContent className="p-8 text-center space-y-4 relative z-10">
                  <div className={`bg-gradient-to-br ${gradientColors[index]} w-20 h-20 rounded-2xl mx-auto flex items-center justify-center group-hover:scale-110 transition-all duration-300 shadow-lg`}>
                    <category.icon className={`h-10 w-10 ${iconColors[index]} group-hover:drop-shadow-lg`} />
                  </div>
                  <div className="space-y-3">
                    <h3 className={`font-bold text-lg text-foreground group-hover:${iconColors[index]} transition-colors duration-300`}>
                      {category.name}
                    </h3>
                    <p className="text-muted-foreground group-hover:text-foreground transition-colors">
                      {category.description}
                    </p>
                    <Badge variant="secondary" className="text-xs font-semibold px-3 py-1 rounded-full">
                      {category.count} Products
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Filters and Search */}
        <div className="bg-gradient-to-r from-primary/5 via-secondary/5 to-accent/5 rounded-2xl p-6 border border-primary/10 mb-8">
          <div className="flex flex-col md:flex-row gap-4 justify-between items-center">
            <div className="flex items-center gap-4 w-full md:w-auto">
              <div className="relative flex-1 md:w-80">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-primary" />
                <Input 
                  placeholder="Search products..." 
                  className="pl-10 border-primary/20 focus:border-primary bg-background/80 backdrop-blur-sm"
                />
              </div>
              <Button variant="outline" size="sm" className="border-primary/30 hover:bg-primary/10">
                <Filter className="mr-2 h-4 w-4 text-primary" />
                Filters
              </Button>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-sm text-muted-foreground">View:</span>
              <div className="flex border rounded-lg border-primary/20">
                <Button
                  variant={viewMode === 'grid' ? 'default' : 'ghost'}
                  size="sm"
                  onClick={() => setViewMode('grid')}
                  className="rounded-r-none"
                >
                  <Grid3X3 className="h-4 w-4" />
                </Button>
                <Button
                  variant={viewMode === 'list' ? 'default' : 'ghost'}
                  size="sm"
                  onClick={() => setViewMode('list')}
                  className="rounded-l-none"
                >
                  <List className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Product placeholder */}
        <div className="text-center py-20">
          <div className="text-6xl mb-4">🏠</div>
          <h3 className="text-2xl font-bold mb-4">Smart Products Coming Soon</h3>
          <p className="text-muted-foreground">Browse our collection of premium smart home devices</p>
        </div>
      </main>
    </div>
  );
};

export default Shop;