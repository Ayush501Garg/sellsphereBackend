import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Search,
  Zap,
  Home,
  Star,
  Mail,
  ArrowRight,
  Heart,
  MessageSquare,
  CheckCircle,
  TrendingUp,
  Globe,
  Users,
} from "lucide-react";
import { Link } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { motion } from "framer-motion";

const blogPosts = [
  {
    id: 1,
    title: "The Future of Smart Homes: Trends to Watch in 2025",
    excerpt:
      "Explore the latest advancements in smart home technology and how Halox is leading the way.",
    category: "Smart Home",
    date: "August 10, 2025",
    thumbnail: "smart-plug.jpg",
  },
  {
    id: 2,
    title: "How IoT is Transforming Home Security",
    excerpt:
      "Learn how IoT devices enhance home security with real-time monitoring and control.",
    category: "IoT",
    date: "July 28, 2025",
    thumbnail: "led-strip.jpg",
  },
  {
    id: 3,
    title: "Energy Efficiency with Smart Switches",
    excerpt: "Discover how Halox’s smart switches can reduce energy consumption in your home.",
    category: "Energy",
    date: "July 15, 2025",
    thumbnail: "smart-switch.jpg",
  },
  {
    id: 4,
    title: "Why Choose Halox for Your Smart Home Needs",
    excerpt: "Understand the benefits of choosing Halox’s Made-in-India IoT solutions.",
    category: "Brand",
    date: "June 30, 2025",
    thumbnail: "smart-plug.jpg",
  },
  {
    id: 5,
    title: "The Rise of Voice-Controlled Homes",
    excerpt:
      "How Alexa & Google Assistant integration with Halox devices is redefining convenience.",
    category: "Smart Home",
    date: "June 20, 2025",
    thumbnail: "led-strip.jpg",
  },
  {
    id: 6,
    title: "5 Ways to Save Energy with Smart Devices",
    excerpt: "Practical tips to reduce electricity costs using Halox IoT devices.",
    category: "Energy",
    date: "May 18, 2025",
    thumbnail: "smart-plug.jpg",
  },
  {
    id: 7,
    title: "IoT in Indian Homes: A New Era",
    excerpt: "How India is adopting smart home technology faster than ever.",
    category: "IoT",
    date: "May 2, 2025",
    thumbnail: "smart-switch.jpg",
  },
  {
    id: 8,
    title: "Halox Security Cameras: Beyond Monitoring",
    excerpt: "AI-powered features that keep your home safe round the clock.",
    category: "IoT",
    date: "April 14, 2025",
    thumbnail: "smart-plug.jpg",
  },
  {
    id: 9,
    title: "The Eco-Friendly Smart Home",
    excerpt: "Building a sustainable future with green technology from Halox.",
    category: "Energy",
    date: "March 29, 2025",
    thumbnail: "led-strip.jpg",
  },
  {
    id: 10,
    title: "Behind the Brand: Halox’s Vision",
    excerpt: "Meet the innovators bringing smart living to every Indian home.",
    category: "Brand",
    date: "March 10, 2025",
    thumbnail: "smart-switch.jpg",
  },
  {
    id: 11,
    title: "How to Use Halox Smart Plug",
    excerpt:
      "Learn how to set up and operate the Halox Smart Plug in four easy steps for seamless home automation.",
    category: "Smart Home",
    date: "January 28, 2025",
    thumbnail: "smart-plug.jpg",
  },
  {
    id: 12,
    title: "Forgot to Turn Off the Lights? Let Smart Plugs Handle It",
    excerpt:
      "Discover how Halox smart plugs help you control lights and appliances remotely, saving energy and money.",
    category: "Energy",
    date: "August 23, 2024",
    thumbnail: "smart-plug.jpg",
  },
  {
    id: 13,
    title: "Are You Tired of Skyrocketing Electricity Bills?",
    excerpt:
      "Find out how Halox smart plugs can help you manage energy consumption and reduce your electricity costs.",
    category: "Energy",
    date: "August 10, 2024",
    thumbnail: "smart-plug.jpg",
  },
  {
    id: 14,
    title: "Unleashing the Power of Smart Plug 10A: A Gateway to Modern Convenience",
    excerpt:
      "Explore the versatile features of the Halox Smart Plug 10A, from remote control to energy management.",
    category: "Smart Home",
    date: "April 22, 2024",
    thumbnail: "smart-plug.jpg",
  },
  {
    id: 15,
    title: "Smart Home in Kurukshetra",
    excerpt:
      "Discover how Halox is blending tradition and technology to bring smart home solutions to Kurukshetra.",
    category: "Smart Home",
    date: "March 13, 2024",
    thumbnail: "smart-switch.jpg",
  },
];

const testimonials = [
  {
    name: "Priya Sharma",
    location: "Mumbai",
    rating: 5,
    text: "Halox’s blog has been a game-changer for understanding smart home tech. The insights are practical and inspiring!",
    avatar: "PS",
  },
  {
    name: "Rajesh Kumar",
    location: "Delhi",
    rating: 5,
    text: "The blog posts are so well-written and easy to follow. I’ve learned so much about IoT and energy savings!",
    avatar: "RK",
  },
  {
    name: "Meena Patel",
    location: "Ahmedabad",
    rating: 5,
    text: "Halox’s blog keeps me updated on the latest smart home trends. It’s a must-read for tech enthusiasts!",
    avatar: "MP",
  },
];

const categories = ["All", "Smart Home", "IoT", "Energy", "Brand"];

const blogLd = {
  "@context": "https://schema.org",
  "@type": "Blog",
  name: "Halox Smart Blog",
  description:
    "Insights on smart home technology, IoT, and innovation from Halox, powered by LivSmart Automation and Security LLP.",
  blogPost: blogPosts.map((post) => ({
    "@type": "BlogPosting",
    headline: post.title,
    description: post.excerpt,
    datePublished: post.date,
    image: post.thumbnail,
  })),
};

const Blog = () => {
  const [isVisible, setIsVisible] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All");

  useEffect(() => {
    setIsVisible(true);
  }, []);

  const filteredPosts = blogPosts.filter((post) => {
    const matchesSearch =
      post.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      post.excerpt.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === "All" || post.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const canonical = typeof window !== "undefined" ? `${window.location.origin}/blog` : "/blog";

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Halox Smart Blog | Smart Home Insights</title>
        <meta
          name="description"
          content="Explore the latest insights on smart home technology, IoT, and innovation from Halox, powered by LivSmart Automation and Security LLP."
        />
        <link rel="canonical" href={canonical} />
        <script type="application/ld+json">{JSON.stringify(blogLd)}</script>
      </Helmet>

      <style>{`
        @keyframes glow {
          0%, 100% { opacity: 0.3; transform: scale(1); }
          50% { opacity: 0.5; transform: scale(1.1); }
        }
        .glow-animation { animation: glow 3s ease-in-out infinite; }
      `}</style>

      <Header />

      {/* Enhanced Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-700 via-purple-700 to-black overflow-hidden">
        {/* Subtle Background Orbs */}
        <div className="absolute inset-0 opacity-20">
          <div className="absolute top-20 left-24 w-64 h-64 bg-blue-400/30 rounded-full blur-3xl animate-pulse" />
          <div className="absolute bottom-32 right-20 w-80 h-80 bg-purple-400/20 rounded-full blur-3xl animate-pulse" />
          <div className="absolute top-1/2 left-1/3 w-40 h-40 bg-orange-400/20 rounded-full blur-2xl animate-bounce" />
        </div>

        <div className="container relative z-10 mx-auto px-6 text-center lg:text-left grid lg:grid-cols-2 gap-12">
          {/* Left Hero Text */}
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1 }}
            className="space-y-6"
          >
            <span className="inline-flex items-center bg-white/20 text-white px-4 py-2 rounded-full text-sm tracking-wide">
              <Home className="h-4 w-4 mr-2" /> Made in India 🇮🇳
            </span>

            <h1 className="text-5xl md:text-7xl font-extrabold leading-tight text-white">
              Halox Smart <br />
              <span className="bg-gradient-to-r from-orange-400 via-pink-500 to-yellow-400 bg-clip-text text-transparent">
                Blog & Insights
              </span>
            </h1>

            <p className="text-lg md:text-xl text-gray-200 max-w-2xl">
              Unlock the future of living with smarter, sustainable, and safer homes powered by Halox,
              India’s most trusted IoT brand.
            </p>

            {/* Hero Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 mt-6 justify-center lg:justify-start">
              <Link to="/blog/latest">
                <Button className="bg-orange-500 hover:bg-orange-600 text-white px-8 py-4 rounded-xl text-lg shadow-xl flex items-center">
                  Read Latest <ArrowRight className="ml-2 h-6 w-6" />
                </Button>
              </Link>
              <Link to="/subscribe">
                <Button className="border border-white text-white hover:bg-white hover:text-blue-700 px-8 py-4 rounded-xl text-lg transition">
                  <Mail className="mr-2 h-5 w-5" /> Subscribe
                </Button>
              </Link>
            </div>

            {/* Inline Search in Hero */}
            <div className="relative max-w-md mt-8">
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search smart home insights..."
                className="w-full px-5 py-3 rounded-xl border border-white/30 bg-white/10 text-white placeholder-gray-300 focus:ring-2 focus:ring-orange-400"
                aria-label="Search blog posts"
              />
              <Search className="absolute right-4 top-1/2 -translate-y-1/2 text-white/70 h-5 w-5" />
            </div>
          </motion.div>

          {/* Right Hero Mockup (floating icons) */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1, delay: 0.3 }}
            className="relative flex justify-center lg:justify-end"
          >
            <div className="relative bg-white/10 backdrop-blur-md rounded-3xl p-8 shadow-2xl max-w-sm text-center">
              <h2 className="text-xl font-semibold text-white mb-4">Latest Topics</h2>
              <ul className="space-y-4 text-left">
                {blogPosts.slice(0, 4).map((post) => (
                  <li key={post.id} className="flex items-start gap-3 text-white/80">
                    <Star className="h-4 w-4 text-orange-400 mt-1" />
                    <span>{post.title}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Floating icons */}
            <motion.div
              animate={{ y: [0, -15, 0] }}
              transition={{ repeat: Infinity, duration: 3 }}
              className="absolute -top-10 right-0 bg-orange-500/20 p-4 rounded-full backdrop-blur-sm"
            >
              <Zap className="h-8 w-8 text-orange-400" />
            </motion.div>
            <motion.div
              animate={{ y: [0, 15, 0] }}
              transition={{ repeat: Infinity, duration: 4 }}
              className="absolute bottom-10 -left-6 bg-blue-500/20 p-4 rounded-full backdrop-blur-sm"
            >
              <Globe className="h-8 w-8 text-blue-400" />
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Search and Filter Section */}
      <section className="py-24 bg-gray-50">
        <div className="container mx-auto px-4 max-w-5xl">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="text-center mb-12"
          >
            <div className="inline-flex items-center gap-2 mb-6 bg-gradient-to-r from-blue-100 to-purple-100 text-blue-600 px-6 py-3 rounded-full text-sm font-semibold shadow-sm">
              <Search className="h-4 w-4" />
              Find Your Next Read
            </div>
            <h2 className="text-5xl md:text-6xl font-black text-gray-900 mb-6 leading-tight">
              Explore
              <span className="bg-gradient-to-r from-blue-600 via-purple-600 to-blue-800 bg-clip-text text-transparent">
                {" "}
                Smart Insights
              </span>
            </h2>
            <p className="text-xl md:text-2xl text-gray-600 max-w-4xl mx-auto font-light leading-relaxed">
              Search or filter by category to discover the latest in smart home technology.
            </p>
          </motion.div>
          <div className="flex flex-col sm:flex-row gap-4 items-center justify-center">
            <div className="relative w-full max-w-md">
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search blog posts..."
                className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all pl-10"
                aria-label="Search blog posts"
              />
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
            </div>
            <div className="flex flex-wrap gap-2">
              {categories.map((category) => (
                <Button
                  key={category}
                  variant={selectedCategory === category ? "default" : "outline"}
                  className={`${
                    selectedCategory === category
                      ? "bg-blue-600 text-white hover:bg-blue-700"
                      : "border-gray-300 text-gray-700 hover:bg-gray-100"
                  } rounded-full px-4 py-2 text-sm font-semibold`}
                  onClick={() => setSelectedCategory(category)}
                  aria-pressed={selectedCategory === category}
                  aria-label={`Filter by ${category}`}
                >
                  {category}
                </Button>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Blog Posts Section (15 posts with smaller excerpt and date text) */}
      <section className="py-24 bg-white">
        <div className="container mx-auto px-4 max-w-6xl">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="text-center mb-20"
          >
            <div className="inline-flex items-center gap-2 mb-6 bg-gradient-to-r from-orange-100 to-yellow-100 text-orange-600 px-6 py-3 rounded-full text-sm font-semibold shadow-sm">
              <MessageSquare className="h-4 w-4" />
              Latest Posts
            </div>
            <h2 className="text-5xl md:text-6xl font-black text-gray-900 mb-6 leading-tight">
              Dive into
              <span className="bg-gradient-to-r from-orange-600 via-red-600 to-pink-600 bg-clip-text text-transparent">
                {" "}
                Smart Home Insights
              </span>
            </h2>
            <p className="text-xl md:text-2xl text-gray-600 max-w-4xl mx-auto font-light leading-relaxed">
              Stay updated with the latest trends and tips for your smart home journey.
            </p>
          </motion.div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-10">
            {filteredPosts.length === 0 ? (
              <p className="text-center text-gray-600 col-span-full text-lg">
                No posts found. Try adjusting your search or category.
              </p>
            ) : (
              filteredPosts.map((post) => (
                <motion.article
                  key={post.id}
                  initial={{ opacity: 0, scale: 0.95 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6 }}
                  className="group bg-white rounded-3xl p-6 shadow-md hover:shadow-xl transition-shadow duration-500 border border-gray-100 hover:border-transparent overflow-hidden flex flex-col"
                >
                  <img
                    src={post.thumbnail}
                    alt={`${post.title} thumbnail`}
                    loading="lazy"
                    className="w-full h-48 rounded-2xl object-cover mb-5 border border-gray-200"
                    onError={(e) => (e.currentTarget.src = "/blog/placeholder.jpg")}
                  />
                  <Badge className="bg-blue-100 text-blue-600 mb-3 self-start">{post.category}</Badge>
                  <h3 className="text-2xl font-semibold text-gray-900 mb-3 group-hover:text-blue-700 transition-colors">
                    {post.title}
                  </h3>
                  <p className="text-sm text-gray-700 flex-grow mb-5 leading-relaxed">{post.excerpt}</p>
                  <p className="text-xs text-gray-500 mb-6">{post.date}</p>
                  <Link to={`/blog/${post.id}`}>
                    <Button
                      className="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2 rounded-lg font-semibold w-full flex items-center justify-center"
                      aria-label={`Read more about ${post.title}`}
                    >
                      Read More <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </Link>
                </motion.article>
              ))
            )} 
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-24 bg-gray-50">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="text-center mb-20"
          >
            <div className="inline-flex items-center gap-2 mb-6 bg-gradient-to-r from-orange-100 to-yellow-100 text-orange-600 px-6 py-3 rounded-full text-sm font-semibold shadow-sm">
              <Heart className="h-4 w-4" />
              Reader Love
            </div>
            <h2 className="text-5xl md:text-6xl font-black text-gray-900 mb-6 leading-tight">
              Loved by
              <span className="bg-gradient-to-r from-orange-600 via-red-600 to-pink-600 bg-clip-text text-transparent">
                {" "}
                Smart Home Enthusiasts
              </span>
            </h2>
            <p className="text-xl md:text-2xl text-gray-600 max-w-4xl mx-auto font-light leading-relaxed">
              See what our readers have to say about Halox’s blog insights.
            </p>
          </motion.div>
          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.95 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.2 }}
                className="group bg-white rounded-3xl p-8 shadow-sm hover:shadow-2xl transition-all duration-500 hover:transform hover:-translate-y-2 border border-gray-100 hover:border-transparent relative overflow-hidden"
              >
                <div className="absolute inset-0 bg-gradient-to-br from-orange-50/50 via-yellow-50/30 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                <div className="absolute top-6 right-6 w-12 h-12 bg-gradient-to-br from-orange-100 to-yellow-100 rounded-full flex items-center justify-center opacity-20 group-hover:opacity-40 transition-opacity duration-300">
                  <MessageSquare className="h-6 w-6 text-orange-500" />
                </div>
                <div className="relative z-10">
                  <div className="flex items-center mb-6 gap-1">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <div key={i} className="relative">
                        <Star className="h-6 w-6 text-yellow-400 fill-current transition-transform duration-300 hover:scale-125" />
                        <div className="absolute inset-0 animate-pulse">
                          <Star className="h-6 w-6 text-yellow-300 fill-current opacity-50" />
                        </div>
                      </div>
                    ))}
                  </div>
                  <p className="text-gray-700 mb-8 italic leading-relaxed text-lg group-hover:text-gray-800 transition-colors duration-300 relative">
                    <span className="text-4xl text-orange-300 absolute -top-2 -left-2 font-serif">"</span>
                    {testimonial.text}
                    <span className="text-4xl text-orange-300 absolute -bottom-4 -right-2 font-serif">"</span>
                  </p>
                  <div className="flex items-center">
                    <div className="w-14 h-14 bg-gradient-to-br from-blue-400 to-purple-500 rounded-full flex items-center justify-center text-white font-bold text-lg mr-4 shadow-lg group-hover:shadow-xl transition-shadow duration-300">
                      {testimonial.avatar}
                    </div>
                    <div>
                      <h4 className="font-bold text-gray-900 text-lg group-hover:text-blue-700 transition-colors duration-300">
                        {testimonial.name}
                      </h4>
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                        <p className="text-gray-500 text-sm font-medium">{testimonial.location}</p>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="absolute bottom-0 left-0 w-16 h-16 bg-gradient-to-tr from-orange-400/10 to-yellow-400/10 rounded-full transform -translate-x-8 translate-y-8 group-hover:scale-150 transition-transform duration-500"></div>
              </motion.div>
            ))}
          </div>
          <div className="text-center mt-12">
            <div className="flex items-center justify-center gap-8 text-gray-600">
              <div className="flex items-center">
                <TrendingUp className="h-5 w-5 mr-2" />
                <span>4.9/5 Average Rating</span>
              </div>
              <div className="flex items-center">
                <MessageSquare className="h-5 w-5 mr-2" />
                <span>10K+ Reader Reviews</span>
              </div>
              <div className="flex items-center">
                <Heart className="h-5 w-5 mr-2" />
                <span>95% Engagement</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 bg-gradient-to-br from-blue-600 via-purple-600 to-blue-800 text-white">
        <div className="container mx-auto px-4 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="max-w-3xl mx-auto space-y-8"
          >
            <h2 className="text-4xl md:text-5xl font-bold">Stay Ahead with Halox Insights</h2>
            <p className="text-xl text-white/80">
              Subscribe to our blog for the latest updates on smart home technology, IoT trends, and tips for a smarter life.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to="/subscribe">
                <Button
                  className="bg-white text-blue-600 hover:bg-gray-100 px-8 py-4 rounded-lg font-semibold shadow-lg transition-all inline-flex items-center justify-center"
                  aria-label="Subscribe to blog updates"
                >
                  <Mail className="mr-2 h-5 w-5" />
                  Subscribe Now
                </Button>
              </Link>
              <Link to="/shop">
                <Button
                  variant="outline"
                  className="border-white text-white hover:bg-white hover:text-blue-600 px-8 py-4 rounded-lg font-semibold transition-all inline-flex items-center justify-center"
                  aria-label="Explore Halox products"
                >
                  <Home className="mr-2 h-5 w-5" />
                  Explore Products
                </Button>
              </Link>
            </div>
            <div className="flex flex-wrap justify-center items-center gap-8 pt-8 opacity-80">
              <div className="flex items-center gap-2">
                <CheckCircle className="h-5 w-5" />
                <span>Free Subscription</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="h-5 w-5" />
                <span>Weekly Updates</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="h-5 w-5" />
                <span>Expert Insights</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="h-5 w-5" />
                <span>Community Access</span>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Blog;