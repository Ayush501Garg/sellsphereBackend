import { useState } from "react";
import {
  Mail,
  Package,
  RefreshCw,
  ShieldCheck,
  AlertTriangle,
  CheckCircle,
  FileText,
} from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import {
  Accordion,
  AccordionItem,
  AccordionTrigger,
  AccordionContent,
} from "@/components/ui/accordion";
import { Helmet } from "react-helmet-async";
import { motion } from "framer-motion";

const ReturnPolicy = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: "",
  });

  const faqs = [
    {
      question: "How long do I have to return a product?",
      answer:
        "Products are eligible for return within 30 days of the purchase date, provided they are unused, undamaged, and in original packaging.",
    },
    {
      question: "Who pays for return shipping?",
      answer:
        "Customers are responsible for return shipping costs unless the return is due to our error or the item is defective.",
    },
    {
      question: "Is there a restocking or processing fee?",
      answer:
        "Yes, a 10% processing fee of the product’s purchase price will be deducted from the refund amount for all approved returns.",
    },
    {
      question: "When will I receive my refund?",
      answer:
        "Refunds are issued to the original payment method within 30 business days after the returned item is received, inspected, and approved.",
    },
    {
      question: "What items are non-returnable?",
      answer:
        "Items marked as 'final sale' are not eligible for return or refund. Please check the product details before purchase.",
    },
    {
      question: "What if my product arrives defective or damaged?",
      answer:
        "If you receive a defective or damaged product, notify us within 7 days. Once approved, you will receive a full refund within 10 business days after returning the product.",
    },
  ];

  const faqLd = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: faqs.map((f) => ({
      "@type": "Question",
      name: f.question,
      acceptedAnswer: { "@type": "Answer", text: f.answer },
    })),
  };

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.MouseEvent<HTMLButtonElement>) => {
    e.preventDefault();
    console.log("Form submitted:", formData);
    setFormData({ name: "", email: "", message: "" });
  };

  const canonical =
    typeof window !== "undefined"
      ? `${window.location.origin}/return-policy`
      : "/return-policy";

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Halox Returns & Refunds Policy | LivSmart Automation</title>
        <meta
          name="description"
          content="Read Halox's Refund & Return Policy. Learn about return eligibility, refund timelines, exclusions, and how to initiate a return."
        />
        <link rel="canonical" href={canonical} />
        <script type="application/ld+json">{JSON.stringify(faqLd)}</script>
      </Helmet>

      <Header />

      <main>
        {/* Hero Section */}
        <section className="relative min-h-[80vh] flex items-center justify-center overflow-hidden bg-gradient-to-br from-purple-700 via-indigo-600 to-blue-700">
          <div className="absolute inset-0 opacity-20">
            <div className="absolute inset-0 bg-white/10 bg-[radial-gradient(circle_at_1px_1px,rgba(255,255,255,0.25)_1px,transparent_0)] bg-[length:20px_20px] animate-pulse"></div>
          </div>
          <div className="container mx-auto px-4 relative z-10">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="text-center space-y-8"
            >
              <div className="inline-flex items-center bg-white/20 text-white border border-white/40 backdrop-blur-md rounded-full px-5 py-2">
                <RefreshCw className="h-5 w-5 mr-2" />
                Return & Refund Policy
              </div>
              <h1 className="text-4xl md:text-6xl lg:text-7xl font-extrabold text-white leading-tight">
                Shop Confidently with Halox
                <span className="block text-orange-300 mt-2">
                  Hassle-Free Returns
                </span>
              </h1>
              <p className="text-lg md:text-xl text-white/80 max-w-3xl mx-auto">
                Our return and refund policies ensure peace of mind while you
                shop premium smart home solutions.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="bg-orange-500 hover:bg-orange-600 text-white px-8 py-4 rounded-xl font-semibold shadow-lg transition-all flex items-center justify-center"
                >
                  <Mail className="mr-2 h-5 w-5" />
                  Contact Support
                </motion.button>
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="border border-white text-white hover:bg-white hover:text-teal-700 px-8 py-4 rounded-xl font-semibold transition-all flex items-center justify-center"
                >
                  <FileText className="mr-2 h-5 w-5" />
                  View Policy
                </motion.button>
              </div>
            </motion.div>
          </div>
        </section>

        {/* Policy Overview */}
        <section className="py-24 bg-gradient-to-b from-white to-gray-50">
          <div className="container mx-auto px-4 grid md:grid-cols-3 gap-10">
            {[
              {
                icon: RefreshCw,
                title: "Return Window",
                description:
                  "Products can be returned within 30 days if unused, undamaged, and in original packaging.",
              },
              {
                icon: Package,
                title: "Processing Fee",
                description:
                  "A 10% processing fee is deducted from all refunds to cover processing & restocking.",
              },
              {
                icon: ShieldCheck,
                title: "Refund Timeline",
                description:
                  "Refunds are processed within 30 business days after inspection and approval.",
              },
              {
                icon: AlertTriangle,
                title: "Exclusions",
                description:
                  "Final sale items and modified products are not eligible for return or refund.",
              },
              {
                icon: CheckCircle,
                title: "Defective Products",
                description:
                  "If items arrive defective or incorrect, notify us within 7 days for a full refund.",
              },
            ].map((item, idx) => (
              <motion.div
                key={item.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: idx * 0.1 }}
                className="bg-white p-8 rounded-3xl shadow-md border hover:shadow-xl transition"
              >
                <item.icon className="h-10 w-10 text-indigo-600 mb-4" />
                <h3 className="text-xl font-semibold mb-2">{item.title}</h3>
                <p className="text-gray-600 leading-relaxed">
                  {item.description}
                </p>
              </motion.div>
            ))}
          </div>
        </section>

        {/* Contact Form */}
        <section className="py-24 bg-gray-50">
          <div className="container mx-auto px-4 max-w-3xl">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
              className="text-center mb-16"
            >
              <div className="inline-block mb-4 bg-purple-100 text-purple-600 px-4 py-2 rounded-full text-sm font-medium">
                Get in Touch
              </div>
              <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
                Questions About Returns?
              </h2>
              <p className="text-xl text-gray-600">
                Reach out to our support team at{" "}
                <span className="font-semibold">info@thelivsmart.com</span> for
                quick assistance.
              </p>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="bg-white rounded-3xl p-8 shadow-lg border border-gray-100"
            >
              <div className="space-y-6">
                <div>
                  <label
                    htmlFor="name"
                    className="block text-sm font-medium text-gray-700 mb-2"
                  >
                    Name
                  </label>
                  <input
                    type="text"
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                    placeholder="Your Name"
                  />
                </div>
                <div>
                  <label
                    htmlFor="email"
                    className="block text-sm font-medium text-gray-700 mb-2"
                  >
                    Email
                  </label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                    placeholder="Your Email"
                  />
                </div>
                <div>
                  <label
                    htmlFor="message"
                    className="block text-sm font-medium text-gray-700 mb-2"
                  >
                    Message
                  </label>
                  <textarea
                    id="message"
                    name="message"
                    value={formData.message}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-indigo-500 h-32"
                    placeholder="How can we assist you with returns?"
                  ></textarea>
                </div>
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={handleSubmit}
                  className="w-full bg-indigo-600 hover:bg-indigo-700 text-white px-8 py-3 rounded-lg font-semibold transition-all flex items-center justify-center"
                >
                  <Mail className="mr-2 h-5 w-5" />
                  Send Message
                </motion.button>
              </div>
            </motion.div>
          </div>
        </section>

        {/* FAQ Section */}
        <section className="py-24 bg-white">
          <div className="container mx-auto px-4 max-w-4xl">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
              className="text-center mb-16"
            >
              <div className="inline-block mb-4 bg-indigo-100 text-indigo-600 px-4 py-2 rounded-full text-sm font-medium">
                FAQ
              </div>
              <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
                Returns & Refunds FAQs
              </h2>
              <p className="text-xl text-gray-600">
                Find answers to commonly asked questions about returns and
                refunds.
              </p>
            </motion.div>
            <Accordion type="single" collapsible className="w-full">
              {faqs.map((faq, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                >
                  <AccordionItem value={`item-${index}`}>
                    <AccordionTrigger className="text-left text-lg font-semibold">
                      {faq.question}
                    </AccordionTrigger>
                    <AccordionContent className="text-gray-600">
                      {faq.answer}
                    </AccordionContent>
                  </AccordionItem>
                </motion.div>
              ))}
            </Accordion>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
};

export default ReturnPolicy;
