import { useState } from "react";
import {
  FileText,
  Scale,
  ShoppingCart,
  CreditCard,
  Truck,
  RefreshCw,
  Copyright,
  Shield,
  CheckCircle,
  Mail,
  Globe,
  AlertTriangle,
  Book,
  Gavel,
  ChevronDown,
  MapPin,
} from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

const TermsAndConditions = () => {
  const [activeSection, setActiveSection] = useState("");
  const [openAccordionItem, setOpenAccordionItem] = useState(null);

  const toggleAccordion = (index) => {
    setOpenAccordionItem(openAccordionItem === index ? null : index);
  };

  const termsSections = [
    {
      id: "general",
      title: "General",
      icon: Book,
      content: {
        ownership: "The Website is owned and operated by LivSmart Automation and Security LLP, with registered address at Ward No 6, Muana, Teh Safidon, Distt Jind 126112.",
        compliance: "By using the Website, you agree to comply with all applicable laws and regulations, as well as these Terms."
      }
    },
    {
      id: "website-use",
      title: "Use of the Website",
      icon: Globe,
      content: {
        lawful: "You may only use the Website for lawful purposes and in accordance with these Terms.",
        restrictions: "You may not use the Website in any way that could damage, disable, overburden, or impair the Website or interfere with any other party's use of the Website."
      }
    },
    {
      id: "products-pricing",
      title: "Products and Pricing",
      icon: ShoppingCart,
      content: {
        availability: "The products displayed on the Website are subject to availability and may be withdrawn or modified at any time without prior notice.",
        pricing: "LivSmart reserves the right to change product prices at any time without prior notice. Prices displayed on the Website are in the currency specified.",
        incorrect: "LivSmart reserves the right to refuse or cancel any orders placed for products listed at an incorrect price, whether or not the order has been confirmed."
      }
    },
    {
      id: "orders-payment",
      title: "Orders and Payment",
      icon: CreditCard,
      content: {
        capability: "By placing an order through the Website, you represent and warrant that you are legally capable of entering into binding contracts.",
        payment: "LivSmart accepts payment through the methods indicated on the Website. Payment must be received in full before orders are processed and shipped."
      }
    },
    {
      id: "shipping-delivery",
      title: "Shipping and Delivery",
      icon: Truck,
      content: {
        efforts: "LivSmart will make reasonable efforts to ensure that orders are dispatched promptly and delivered within the estimated timeframe. However, LivSmart shall not be liable for any delays in delivery.",
        thirdParty: "LivSmart reserves the right to use third-party delivery services to fulfill orders."
      }
    },
    {
      id: "returns-refunds",
      title: "Returns and Refunds",
      icon: RefreshCw,
      content: {
        policy: "Please refer to our Returns and Refunds Policy, available on the Website, for information on returning products and requesting refunds."
      }
    },
    {
      id: "intellectual-property",
      title: "Intellectual Property",
      icon: Copyright,
      content: {
        ownership: "All content on the Website, including but not limited to text, graphics, logos, images, and software, is the property of LivSmart or its licensors and is protected by copyright and other intellectual property laws.",
        usage: "You may not use, reproduce, modify, distribute, or display any of the content on the Website without prior written permission from LivSmart."
      }
    },
    {
      id: "liability",
      title: "Limitation of Liability",
      icon: Shield,
      content: {
        limitation: "To the fullest extent permitted by law, LivSmart shall not be liable for any indirect, incidental, special, consequential, or punitive damages arising out of or in connection with the use of the Website or the products sold on the Website."
      }
    },
    {
      id: "governing-law",
      title: "Governing Law",
      icon: Gavel,
      content: {
        law: "These Terms shall be governed by and construed in accordance with the laws of India."
      }
    }
  ];

  const faqs = [
    {
      question: "What happens if I violate these terms and conditions?",
      answer: "Violation of these terms may result in immediate termination of your access to the Website and may also result in legal action. We reserve the right to refuse service to anyone who violates these terms."
    },
    {
      question: "Can you change these terms without notice?",
      answer: "Yes, LivSmart reserves the right to modify or update these Terms at any time without prior notice. Any changes will be effective immediately upon posting on the Website. We recommend reviewing these terms periodically."
    },
    {
      question: "What if a product price is displayed incorrectly?",
      answer: "LivSmart reserves the right to refuse or cancel any orders placed for products listed at an incorrect price, whether or not the order has been confirmed. We will notify you if this occurs and offer alternatives."
    },
    {
      question: "Are there any age restrictions for using this website?",
      answer: "By placing an order, you represent that you are legally capable of entering into binding contracts. If you are under 18, you must have parental or guardian consent to use this website and make purchases."
    },
    {
      question: "What payment methods do you accept?",
      answer: "We accept various payment methods as indicated on our website during checkout. Payment must be received in full before orders are processed and shipped. All transactions are secured and encrypted."
    },
    {
      question: "What if my order is delayed in delivery?",
      answer: "While we make reasonable efforts to deliver orders within the estimated timeframe, LivSmart shall not be liable for any delays in delivery. We work with reliable third-party delivery services and will keep you informed of any significant delays."
    }
  ];

  return (
    <div className="min-h-screen bg-background">
    <Header />
      
      <main>
        {/* Hero Section */}
        <section className="relative min-h-[80vh] flex items-center justify-center overflow-hidden bg-gradient-to-br from-indigo-600 via-purple-600 to-pink-600">
          <div className="absolute inset-0 opacity-10">
            <div className="absolute inset-0 bg-white/5 bg-[radial-gradient(circle_at_1px_1px,rgba(255,255,255,0.15)_1px,transparent_0)] bg-[length:20px_20px] animate-pulse"></div>
          </div>
          <div className="container mx-auto px-4 relative z-10">
            <div className="text-center space-y-8">
              <div className="inline-flex items-center bg-white/20 text-white border border-white/30 backdrop-blur-sm rounded-full px-4 py-2">
                <Scale className="h-4 w-4 mr-2" />
                Legal Terms
              </div>
              <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold text-white leading-tight">
                Terms &
                <span className="block text-pink-300">Conditions</span>
              </h1>
              <p className="text-lg md:text-xl text-white/80 max-w-3xl mx-auto">
                Please read these terms and conditions carefully before using our website. By accessing Halox Smart, you agree to be bound by these terms.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <button 
                  onClick={() => document.getElementById('terms-sections')?.scrollIntoView({ behavior: 'smooth' })}
                  className="bg-pink-500 hover:bg-pink-600 text-white px-8 py-4 rounded-lg font-semibold shadow-lg transition-all flex items-center justify-center"
                >
                  <FileText className="mr-2 h-5 w-5" />
                  Read Full Terms
                </button>
                <button className="border border-white text-white hover:bg-white hover:text-purple-600 px-8 py-4 rounded-lg font-semibold transition-all flex items-center justify-center">
                  <Mail className="mr-2 h-5 w-5" />
                  Contact Legal
                </button>
              </div>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mt-16 pt-8 border-t border-white/20">
              {[
                {
                  label: "Legal Framework",
                  value: "India",
                  icon: Gavel,
                },
                { label: "Terms Sections", value: "9+", icon: FileText },
                { label: "User Protection", value: "Secured", icon: Shield },
                { label: "Compliance", value: "Full", icon: CheckCircle },
              ].map((stat) => (
                <div key={stat.label} className="text-center text-white">
                  <stat.icon className="h-6 w-6 mx-auto mb-2 text-pink-300" />
                  <div className="text-2xl font-bold">{stat.value}</div>
                  <div className="text-sm text-white/60">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Key Points Section */}
        <section className="py-24 bg-white">
          <div className="container mx-auto px-4">
            <div className="text-center mb-16">
              <div className="inline-block mb-4 bg-indigo-100 text-indigo-600 px-4 py-2 rounded-full text-sm font-medium">
                Key Highlights
              </div>
              <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
                What You Need to Know
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Essential points about using our website and services.
              </p>
            </div>
            <div className="grid md:grid-cols-3 gap-8">
              {[
                {
                  icon: Scale,
                  title: "Legal Agreement",
                  description: "These terms constitute a binding legal agreement between you and LivSmart when you use our website.",
                  color: "from-indigo-400 to-indigo-600",
                  bgColor: "from-indigo-50 to-indigo-100",
                },
                {
                  icon: ShoppingCart,
                  title: "Purchase Terms",
                  description: "All orders are subject to acceptance, product availability, and our right to modify prices without notice.",
                  color: "from-purple-400 to-purple-600",
                  bgColor: "from-purple-50 to-purple-100",
                },
                {
                  icon: Shield,
                  title: "Limited Liability",
                  description: "Our liability is limited as per applicable law. We're not responsible for indirect or consequential damages.",
                  color: "from-pink-400 to-pink-600",
                  bgColor: "from-pink-50 to-pink-100",
                },
              ].map((point) => (
                <div
                  key={point.title}
                  className="group bg-gradient-to-br from-white to-gray-50 rounded-3xl p-8 border border-gray-100 hover:border-transparent hover:shadow-2xl transition-all duration-500 hover:transform hover:-translate-y-2 cursor-pointer relative overflow-hidden"
                >
                  <div
                    className={`absolute inset-0 bg-gradient-to-br ${point.bgColor} opacity-0 group-hover:opacity-100 transition-opacity duration-500`}
                  ></div>
                  <div
                    className={`w-16 h-16 rounded-2xl flex items-center justify-center mb-6 shadow-lg group-hover:shadow-xl transition-all duration-300 group-hover:scale-110 relative z-10 bg-gradient-to-br ${point.color}`}
                  >
                    <point.icon className="h-8 w-8 text-white transition-transform duration-300 group-hover:scale-110" />
                    <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-white/20 to-transparent"></div>
                  </div>
                  <div className="relative z-10">
                    <h3 className="text-2xl font-bold text-gray-900 mb-4 group-hover:text-indigo-700 transition-colors duration-300">
                      {point.title}
                    </h3>
                    <p className="text-gray-600 leading-relaxed group-hover:text-gray-700 transition-colors duration-300">
                      {point.description}
                    </p>
                  </div>
                  <div
                    className={`absolute top-0 right-0 w-24 h-24 bg-gradient-to-br ${point.color} opacity-10 rounded-full transform translate-x-8 -translate-y-8 group-hover:scale-150 transition-transform duration-500`}
                  ></div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Terms Sections */}
        <section id="terms-sections" className="py-24 bg-gray-50">
          <div className="container mx-auto px-4 max-w-4xl">
            <div className="text-center mb-16">
              <div className="inline-block mb-4 bg-purple-100 text-purple-600 px-4 py-2 rounded-full text-sm font-medium">
                Detailed Terms
              </div>
              <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
                Terms and Conditions
              </h2>
              <p className="text-xl text-gray-600">
                Complete terms governing your use of the Halox Smart website.
              </p>
            </div>
            
            <div className="space-y-8">
              {termsSections.map((section, index) => (
                <div
                  key={section.id}
                  className="bg-white rounded-2xl p-8 shadow-lg border border-gray-100 hover:shadow-xl transition-all duration-300"
                >
                  <div className="flex items-start gap-4 mb-6">
                    <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-purple-500 to-pink-600 flex items-center justify-center shadow-lg">
                      <section.icon className="h-6 w-6 text-white" />
                    </div>
                    <div>
                      <h3 className="text-2xl font-bold text-gray-900 mb-2">
                        {index + 1}. {section.title}
                      </h3>
                    </div>
                  </div>
                  
                  <div className="space-y-4 ml-16">
                    {Object.entries(section.content).map(([key, value], subIndex) => (
                      <div key={key} className="border-l-4 border-purple-200 pl-6">
                        <p className="text-gray-700 leading-relaxed">
                          <span className="font-medium text-gray-900">
                            {index + 1}.{subIndex + 1}.
                          </span>{" "}
                          {value}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>

            {/* Contact Section */}
            <div className="mt-12 bg-white rounded-2xl p-8 shadow-lg border border-gray-100">
              <div className="flex items-start gap-4 mb-6">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center shadow-lg">
                  <Mail className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-gray-900 mb-2">
                    10. Contact Information
                  </h3>
                </div>
              </div>
              
              <div className="ml-16">
                <div className="border-l-4 border-blue-200 pl-6">
                  <p className="text-gray-700 leading-relaxed mb-4">
                    <span className="font-medium text-gray-900">10.1.</span> If you have any questions or concerns about these Terms or the Website, please contact us at info@thelivsmart.com.
                  </p>
                  <div className="bg-blue-50 rounded-lg p-4 mt-4">
                    <p className="text-sm text-blue-800">
                      <strong>Important:</strong> By using the Website, you acknowledge that you have read, understood, and agree to be bound by these Terms. LivSmart reserves the right to modify or update these Terms at any time without prior notice.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Company Information */}
        <section className="py-24 bg-white">
          <div className="container mx-auto px-4 max-w-3xl">
            <div className="text-center mb-16">
              <div className="inline-block mb-4 bg-pink-100 text-pink-600 px-4 py-2 rounded-full text-sm font-medium">
                Company Details
              </div>
              <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
                About LivSmart
              </h2>
              <p className="text-xl text-gray-600">
                Legal entity information and contact details.
              </p>
            </div>
            
            <div className="bg-gradient-to-br from-gray-50 to-white rounded-3xl p-8 shadow-lg border border-gray-100">
              <div className="grid md:grid-cols-2 gap-8">
                <div className="space-y-6">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center shadow-lg">
                      <Globe className="h-6 w-6 text-white" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900">Company Name</h4>
                      <p className="text-gray-600">LivSmart Automation and Security LLP</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-purple-500 to-pink-600 flex items-center justify-center shadow-lg">
                      <MapPin className="h-6 w-6 text-white" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900">Registered Address</h4>
                      <p className="text-gray-600">Ward No 6, Muana, Teh Safidon, Distt Jind 126112</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-pink-500 to-red-600 flex items-center justify-center shadow-lg">
                      <Mail className="h-6 w-6 text-white" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900">Email Contact</h4>
                      <p className="text-gray-600">info@thelivsmart.com</p>
                    </div>
                  </div>
                </div>
                
                <div className="bg-white rounded-2xl p-6 shadow-md">
                  <h4 className="font-semibold text-gray-900 mb-4">Legal Compliance</h4>
                  <ul className="space-y-2 text-sm text-gray-600">
                    <li className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-indigo-500" />
                      Governed by Indian Law
                    </li>
                    <li className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-indigo-500" />
                      Registered LLP Entity
                    </li>
                    <li className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-indigo-500" />
                      Terms Subject to Change
                    </li>
                    <li className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-indigo-500" />
                      User Agreement Required
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* FAQ Section */}
        <section className="py-24 bg-gray-50">
          <div className="container mx-auto px-4 max-w-4xl">
            <div className="text-center mb-16">
              <div className="inline-block mb-4 bg-indigo-100 text-indigo-600 px-4 py-2 rounded-full text-sm font-medium">
                FAQ
              </div>
              <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
                Terms & Conditions FAQ
              </h2>
              <p className="text-xl text-gray-600">
                Common questions about our terms and conditions.
              </p>
            </div>
            <div className="w-full">
              {faqs.map((faq, index) => (
                <div key={index} className="border border-gray-200 rounded-lg mb-4">
                  <button
                    onClick={() => toggleAccordion(index)}
                    className="w-full px-6 py-4 text-left flex justify-between items-center hover:bg-gray-50 transition-colors"
                  >
                    <span className="font-semibold text-gray-900">{faq.question}</span>
                    <ChevronDown className={`h-5 w-5 text-gray-500 transition-transform ${openAccordionItem === index ? 'rotate-180' : ''}`} />
                  </button>
                  {openAccordionItem === index && (
                    <div className="px-6 pb-4 text-gray-600 leading-relaxed">
                      {faq.answer}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-24 bg-gradient-to-br from-indigo-600 via-purple-600 to-pink-800 text-white">
          <div className="container mx-auto px-4 text-center">
            <div className="max-w-3xl mx-auto space-y-8">
              <h2 className="text-4xl md:text-5xl font-bold">Questions About Terms?</h2>
              <p className="text-xl text-white/80">
                If you have any questions about these terms and conditions or need clarification on any point, don't hesitate to contact our legal team.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <button className="bg-white text-indigo-600 hover:bg-gray-100 px-8 py-4 rounded-lg font-semibold shadow-lg transition-all inline-flex items-center justify-center">
                  <Scale className="mr-2 h-5 w-5" />
                  Legal Support
                </button>
                <button className="border border-white text-white hover:bg-white hover:text-indigo-600 px-8 py-4 rounded-lg font-semibold transition-all inline-flex items-center justify-center">
                  <Mail className="mr-2 h-5 w-5" />
                  Contact Team
                </button>
              </div>
              <div className="flex flex-wrap justify-center items-center gap-8 pt-8 opacity-80">
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-5 w-5" />
                  <span>Indian Law Governed</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-5 w-5" />
                  <span>Fair Terms</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-5 w-5" />
                  <span>User Protection</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-5 w-5" />
                  <span>Clear Guidelines</span>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

    <Footer />
    </div>
  );
};

export default TermsAndConditions;