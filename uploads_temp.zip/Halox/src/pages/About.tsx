import { useState } from "react";
import {
  Mail,
  Users,
  Building,
  ShieldCheck,
  Zap,
  Globe,
  HeartHandshake,
  Lightbulb,
  Award,
} from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import {
  Accordion,
  AccordionItem,
  AccordionTrigger,
  AccordionContent,
} from "@/components/ui/accordion";
import { Helmet } from "react-helmet-async";
import { motion } from "framer-motion";

const About = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: "",
  });

  const values = [
    {
      question: "What does LivSmart Automation & Security do?",
      answer:
        "We specialize in smart home automation and security solutions under the Halox brand, offering cutting-edge products designed to make living spaces safer, smarter, and more convenient.",
    },
    {
      question: "What makes Halox unique?",
      answer:
        "Our strength lies in combining innovation, reliability, and user-friendly technology. We aim to simplify everyday living by integrating automation with trustworthy security solutions.",
    },
    {
      question: "Where does LivSmart operate?",
      answer:
        "We currently serve customers across India, ensuring the latest global smart home solutions are available locally.",
    },
    {
      question: "Do you provide after-sales support?",
      answer:
        "Absolutely. Customer satisfaction is our top priority. We provide dedicated after-sales support, product guidance, and technical help whenever required.",
    },
    {
      question: "What is the long-term vision?",
      answer:
        "Our vision is to create connected, intelligent, and highly secure living spaces that improve daily life while remaining accessible to everyone.",
    },
  ];

  const faqLd = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: values.map((f) => ({
      "@type": "Question",
      name: f.question,
      acceptedAnswer: { "@type": "Answer", text: f.answer },
    })),
  };

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.MouseEvent<HTMLButtonElement>) => {
    e.preventDefault();
    console.log("Form submitted:", formData);
    setFormData({ name: "", email: "", message: "" });
  };

  const canonical =
    typeof window !== "undefined"
      ? `${window.location.origin}/about`
      : "/about";

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>About Halox | LivSmart Automation & Security</title>
        <meta
          name="description"
          content="Learn more about Halox by LivSmart Automation – our mission, vision, and commitment to building smarter, safer homes with cutting-edge automation & security."
        />
        <link rel="canonical" href={canonical} />
        <script type="application/ld+json">{JSON.stringify(faqLd)}</script>
      </Helmet>

      <Header />

      <main>
        {/* Hero Section */}
        <section className="relative min-h-[80vh] flex items-center justify-center overflow-hidden bg-gradient-to-br from-indigo-700 via-sky-600 to-cyan-700">
          <div className="absolute inset-0 opacity-20">
            <div className="absolute inset-0 bg-white/10 bg-[radial-gradient(circle_at_1px_1px,rgba(255,255,255,0.25)_1px,transparent_0)] bg-[length:20px_20px] animate-pulse"></div>
          </div>
          <div className="container mx-auto px-4 relative z-10">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="text-center space-y-8"
            >
              <div className="inline-flex items-center bg-white/20 text-white border border-white/40 backdrop-blur-md rounded-full px-5 py-2">
                <Users className="h-5 w-5 mr-2" />
                About Us
              </div>
              <h1 className="text-4xl md:text-6xl lg:text-7xl font-extrabold text-white leading-tight">
                Building Smarter, Safer Homes
                <span className="block text-orange-300 mt-2">
                  with Halox by LivSmart
                </span>
              </h1>
              <p className="text-lg md:text-xl text-white/80 max-w-3xl mx-auto">
                We combine innovation and reliability to deliver cutting-edge
                smart home automation & security solutions across India.
              </p>
            </motion.div>
          </div>
        </section>

        {/* Company Highlights */}
        <section className="py-24 bg-gradient-to-b from-white to-gray-50">
          <div className="container mx-auto px-4 grid md:grid-cols-3 gap-10">
            {[
              {
                icon: Building,
                title: "Who We Are",
                description:
                  "LivSmart Automation & Security LLP operates Halox, delivering innovative solutions in smart living and secure automation.",
              },
              {
                icon: Lightbulb,
                title: "Our Mission",
                description:
                  "To empower every home with intelligent automation that enhances everyday convenience and ensures safety.",
              },
              {
                icon: Globe,
                title: "Serving India",
                description:
                  "Proudly enabling future-ready living solutions across India through trusted products and local expertise.",
              },
              {
                icon: Zap,
                title: "Cutting-Edge Tech",
                description:
                  "We harness the potential of IoT, AI, and automation to create seamless living experiences.",
              },
              {
                icon: HeartHandshake,
                title: "Customer First",
                description:
                  "Our customers drive our success — we are committed to guided onboarding, responsive support, and reliable services.",
              },
              {
                icon: Award,
                title: "Commitment to Quality",
                description:
                  "Every Halox product is crafted with precision and backed by strong warranties and compliance measures.",
              },
            ].map((item, idx) => (
              <motion.div
                key={item.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: idx * 0.1 }}
                className="bg-white p-8 rounded-3xl shadow-md border hover:shadow-xl transition"
              >
                <item.icon className="h-10 w-10 text-indigo-600 mb-4" />
                <h3 className="text-xl font-semibold mb-2">{item.title}</h3>
                <p className="text-gray-600 leading-relaxed">
                  {item.description}
                </p>
              </motion.div>
            ))}
          </div>
        </section>

        {/* Contact Form */}
        <section className="py-24 bg-gray-50">
          <div className="container mx-auto px-4 max-w-3xl">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
              className="text-center mb-16"
            >
              <div className="inline-block mb-4 bg-indigo-100 text-indigo-600 px-4 py-2 rounded-full text-sm font-medium">
                Get in Touch
              </div>
              <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
                Let’s Connect
              </h2>
              <p className="text-xl text-gray-600">
                Have questions about Halox? Reach us at{" "}
                <span className="font-semibold">info@thelivsmart.com</span> and
                our team will be glad to help.
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="bg-white rounded-3xl p-8 shadow-lg border border-gray-100"
            >
              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Name
                  </label>
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-indigo-500"
                    placeholder="Your Name"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Email
                  </label>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-indigo-500"
                    placeholder="Your Email"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Message
                  </label>
                  <textarea
                    name="message"
                    value={formData.message}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-indigo-500 h-32"
                    placeholder="Tell us how we can help"
                  ></textarea>
                </div>
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={handleSubmit}
                  className="w-full bg-indigo-600 hover:bg-indigo-700 text-white px-8 py-3 rounded-lg font-semibold flex items-center justify-center"
                >
                  <Mail className="mr-2 h-5 w-5" />
                  Send Message
                </motion.button>
              </div>
            </motion.div>
          </div>
        </section>

        {/* Values / FAQish Section */}
        <section className="py-24 bg-white">
          <div className="container mx-auto px-4 max-w-4xl">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
              className="text-center mb-16"
            >
              <div className="inline-block mb-4 bg-indigo-100 text-indigo-600 px-4 py-2 rounded-full text-sm font-medium">
                Our Values
              </div>
              <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
                What Drives Us
              </h2>
              <p className="text-xl text-gray-600">
                Explore our mission and long-term vision, and discover how Halox
                aims to transform living spaces.
              </p>
            </motion.div>
            <Accordion type="single" collapsible className="w-full">
              {values.map((faq, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                >
                  <AccordionItem value={`item-${index}`}>
                    <AccordionTrigger className="text-left text-lg font-semibold">
                      {faq.question}
                    </AccordionTrigger>
                    <AccordionContent className="text-gray-600">
                      {faq.answer}
                    </AccordionContent>
                  </AccordionItem>
                </motion.div>
              ))}
            </Accordion>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
};

export default About;
