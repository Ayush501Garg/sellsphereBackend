import { useState } from "react";
import {
  Mail,
  Package,
  RotateCcw,
  Shield,
  Clock,
  CheckCircle,
  ArrowRight,
} from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import {
  Accordion,
  AccordionItem,
  AccordionTrigger,
  AccordionContent,
} from "@/components/ui/accordion";
import { Helmet } from "react-helmet-async";
import { motion } from "framer-motion";

const Returns = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: "",
  });

  const faqs = [
    {
      question: "What is the return period for Halox products?",
      answer:
        "Products are eligible for return within 30 days of the purchase date, provided they are unused, undamaged, and in their original packaging with all accessories.",
    },
    {
      question: "How do I initiate a return?",
      answer:
        "Contact our customer service team at info@thelivsmart.com to obtain prior authorization for the return. Returns must be shipped back within 7 days of receiving authorization.",
    },
    {
      question: "Are there any fees for returning a product?",
      answer:
        "A 10% processing fee of the product’s purchase price will be deducted from the refund for approved returns. Customers are responsible for return shipping costs unless the return is due to our error or a defective item.",
    },
    {
      question: "How long does it take to process a refund?",
      answer:
        "Refunds are processed within 30 business days after the returned item is received, inspected, and approved. The refund will be issued to the original payment method.",
    },
    {
      question: "Can I return final sale items?",
      answer:
        "No, items marked as 'final sale' on our website are not eligible for return or refund. These items are clearly indicated at the time of purchase.",
    },
  ];

  const faqLd = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: faqs.map((f) => ({
      "@type": "Question",
      name: f.question,
      acceptedAnswer: { "@type": "Answer", text: f.answer },
    })),
  };

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.MouseEvent<HTMLButtonElement>) => {
    e.preventDefault();
    console.log("Form submitted:", formData);
    setFormData({ name: "", email: "", message: "" });
  };

  const canonical =
    typeof window !== "undefined"
      ? `${window.location.origin}/returns`
      : "/returns";

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Halox Refund and Returns Policy | LivSmart Automation</title>
        <meta
          name="description"
          content="Learn about Halox's refund and returns policy, including eligibility, procedures, and fees. Contact us for assistance with your return."
        />
        <link rel="canonical" href={canonical} />
        <script type="application/ld+json">{JSON.stringify(faqLd)}</script>
      </Helmet>

      <Header />

      <main>
        {/* Hero Section */}
        <section className="relative min-h-[80vh] flex items-center justify-center overflow-hidden bg-gradient-to-br from-blue-700 via-teal-600 to-indigo-700">
          <div className="absolute inset-0 opacity-20">
            <div className="absolute inset-0 bg-white/10 bg-[radial-gradient(circle_at_1px_1px,rgba(255,255,255,0.25)_1px,transparent_0)] bg-[length:20px_20px] animate-pulse"></div>
          </div>
          <div className="container mx-auto px-4 relative z-10">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="text-center space-y-8"
            >
              <div className="inline-flex items-center bg-white/20 text-white border border-white/40 backdrop-blur-md rounded-full px-5 py-2">
                <RotateCcw className="h-5 w-5 mr-2" />
                Refund & Returns Policy
              </div>
              <h1 className="text-4xl md:text-6xl lg:text-7xl font-extrabold text-white leading-tight">
                Hassle-Free Returns
                <span className="block text-orange-300 mt-2">Shop with Confidence</span>
              </h1>
              <p className="text-lg md:text-xl text-white/80 max-w-3xl mx-auto">
                Our refund and returns policy ensures a smooth process for returning eligible products. Learn how we prioritize your satisfaction.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="bg-orange-500 hover:bg-orange-600 text-white px-8 py-4 rounded-xl font-semibold shadow-lg transition-all flex items-center justify-center"
                >
                  <Mail className="mr-2 h-5 w-5" />
                  Contact Support
                </motion.button>
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="border border-white text-white hover:bg-white hover:text-teal-700 px-8 py-4 rounded-xl font-semibold transition-all flex items-center justify-center"
                >
                  <Package className="mr-2 h-5 w-5" />
                  View Policy
                </motion.button>
              </div>
            </motion.div>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.5, duration: 0.8 }}
              className="grid grid-cols-2 md:grid-cols-4 gap-6 mt-16 pt-8 border-t border-white/20"
            >
              {[
                {
                  label: "Return Period",
                  value: "30 Days",
                  icon: Clock,
                },
                { label: "Processing Time", value: "10-30 Days", icon: Clock },
                { label: "Customer Support", value: "24/7", icon: Shield },
                { label: "Transparency", value: "100%", icon: CheckCircle },
              ].map((stat) => (
                <div key={stat.label} className="text-center text-white">
                  <stat.icon className="h-6 w-6 mx-auto mb-2 text-orange-300" />
                  <div className="text-2xl font-bold">{stat.value}</div>
                  <div className="text-sm text-white/60">{stat.label}</div>
                </div>
              ))}
            </motion.div>
          </div>
        </section>

        {/* Returns Information Section */}
        <section className="py-24 bg-gradient-to-b from-white to-gray-50">
          <div className="container mx-auto px-4">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
              className="text-center mb-16"
            >
              <div className="inline-block mb-4 bg-teal-100 text-teal-600 px-4 py-2 rounded-full text-sm font-medium">
                Returns Overview
              </div>
              <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
                How Returns & Refunds Work
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Understand our policies for returning eligible products and processing refunds to ensure a seamless experience.
              </p>
            </motion.div>
            <div className="grid md:grid-cols-3 gap-8">
              {[
                {
                  icon: RotateCcw,
                  title: "Return Eligibility",
                  description:
                    "Return unused, undamaged products in original packaging within 30 days of purchase for a refund.",
                  color: "from-teal-400 to-teal-600",
                  bgColor: "from-teal-50 to-teal-100",
                  action: "Learn More",
                },
                {
                  icon: Package,
                  title: "Return Process",
                  description:
                    "Contact us for authorization and ship returns within 7 days. Customers cover return shipping unless due to our error.",
                  color: "from-green-400 to-green-600",
                  bgColor: "from-green-50 to-green-100",
                  action: "See Details",
                },
                {
                  icon: Shield,
                  title: "Refund Processing",
                  description:
                    "Approved refunds are issued within 30 business days to the original payment method, minus a 10% fee.",
                  color: "from-blue-400 to-blue-600",
                  bgColor: "from-blue-50 to-blue-100",
                  action: "Explore Refunds",
                },
              ].map((option) => (
                <motion.div
                  key={option.title}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6 }}
                  className="group bg-gradient-to-br from-white to-gray-50 rounded-3xl p-8 border border-gray-100 hover:border-transparent hover:shadow-2xl transition-all duration-500 hover:transform hover:-translate-y-2 cursor-pointer relative overflow-hidden"
                >
                  <div
                    className={`absolute inset-0 bg-gradient-to-br ${option.bgColor} opacity-0 group-hover:opacity-100 transition-opacity duration-500`}
                  ></div>
                  <div
                    className={`w-16 h-16 rounded-2xl flex items-center justify-center mb-6 shadow-lg group-hover:shadow-xl transition-all duration-300 group-hover:scale-110 relative z-10 bg-gradient-to-br ${option.color}`}
                  >
                    <option.icon className="h-8 w-8 text-white transition-transform duration-300 group-hover:scale-110" />
                    <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-white/20 to-transparent"></div>
                  </div>
                  <div className="relative z-10">
                    <h3 className="text-2xl font-bold text-gray-900 mb-4 group-hover:text-teal-700 transition-colors duration-300">
                      {option.title}
                    </h3>
                    <p className="text-gray-600 mb-4 leading-relaxed group-hover:text-gray-700 transition-colors duration-300">
                      {option.description}
                    </p>
                    <button className="inline-flex items-center gap-2 text-sm font-semibold px-4 py-2 bg-teal-50 text-teal-600 rounded-full group-hover:bg-teal-100 transition-all duration-300">
                      <div className="w-2 h-2 bg-teal-400 rounded-full animate-pulse"></div>
                      {option.action}
                    </button>
                  </div>
                  <div
                    className={`absolute top-0 right-0 w-24 h-24 bg-gradient-to-br ${option.color} opacity-10 rounded-full transform translate-x-8 -translate-y-8 group-hover:scale-150 transition-transform duration-500`}
                  ></div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Contact Form Section */}
        <section className="py-24 bg-gray-50">
          <div className="container mx-auto px-4 max-w-3xl">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
              className="text-center mb-16"
            >
              <div className="inline-block mb-4 bg-orange-100 text-orange-600 px-4 py-2 rounded-full text-sm font-medium">
                Get in Touch
              </div>
              <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
                Need Help with Returns?
              </h2>
              <p className="text-xl text-gray-600">
                Contact our team for assistance with returns or refunds, and we’ll guide you through the process.
              </p>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="bg-white rounded-3xl p-8 shadow-lg border border-gray-100"
            >
              <div className="space-y-6">
                <div>
                  <label
                    htmlFor="name"
                    className="block text-sm font-medium text-gray-700 mb-2"
                  >
                    Name
                  </label>
                  <input
                    type="text"
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-teal-500 focus:border-transparent transition-all"
                    placeholder="Your Name"
                    aria-required="true"
                  />
                </div>
                <div>
                  <label
                    htmlFor="email"
                    className="block text-sm font-medium text-gray-700 mb-2"
                  >
                    Email
                  </label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-teal-500 focus:border-transparent transition-all"
                    placeholder="Your Email"
                    aria-required="true"
                  />
                </div>
                <div>
                  <label
                    htmlFor="message"
                    className="block text-sm font-medium text-gray-700 mb-2"
                  >
                    Message
                  </label>
                  <textarea
                    id="message"
                    name="message"
                    value={formData.message}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-teal-500 focus:border-transparent transition-all h-32"
                    placeholder="How can we assist you with returns or refunds?"
                    aria-required="true"
                  ></textarea>
                </div>
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={handleSubmit}
                  className="w-full bg-teal-600 hover:bg-teal-700 text-white px-8 py-3 rounded-lg font-semibold transition-all flex items-center justify-center"
                >
                  <Mail className="mr-2 h-5 w-5" />
                  Send Message
                </motion.button>
              </div>
            </motion.div>
          </div>
        </section>

        {/* FAQ Section */}
        <section className="py-24 bg-white">
          <div className="container mx-auto px-4 max-w-4xl">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
              className="text-center mb-16"
            >
              <div className="inline-block mb-4 bg-indigo-100 text-indigo-600 px-4 py-2 rounded-full text-sm font-medium">
                FAQ
              </div>
              <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
                Returns & Refunds FAQs
              </h2>
              <p className="text-xl text-gray-600">
                Find answers to common questions about our returns and refunds policies.
              </p>
            </motion.div>
            <Accordion type="single" collapsible className="w-full">
              {faqs.map((faq, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                >
                  <AccordionItem value={`item-${index}`}>
                    <AccordionTrigger className="text-left text-lg font-semibold">
                      {faq.question}
                    </AccordionTrigger>
                    <AccordionContent className="text-gray-600">
                      {faq.answer}
                    </AccordionContent>
                  </AccordionItem>
                </motion.div>
              ))}
            </Accordion>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-24 bg-gradient-to-br from-teal-600 via-blue-600 to-indigo-800 text-white">
          <div className="container mx-auto px-4 text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
              className="max-w-3xl mx-auto space-y-8"
            >
              <h2 className="text-4xl md:text-5xl font-bold">Shop Worry-Free</h2>
              <p className="text-xl text-white/80">
                Have questions about returns or refunds? Contact us or review our full policy for clarity.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="bg-white text-teal-600 hover:bg-gray-100 px-8 py-4 rounded-xl font-semibold shadow-lg transition-all inline-flex items-center justify-center"
                >
                  <Package className="mr-2 h-5 w-5" />
                  View Full Policy
                </motion.button>
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="border border-white text-white hover:bg-white hover:text-teal-600 px-8 py-4 rounded-xl font-semibold transition-all inline-flex items-center justify-center"
                >
                  <Mail className="mr-2 h-5 w-5" />
                  Contact Support
                </motion.button>
              </div>
              <div className="flex flex-wrap justify-center items-center gap-8 pt-8 opacity-80">
                {[
                  { label: "30-Day Returns", icon: CheckCircle },
                  { label: "Dedicated Support", icon: CheckCircle },
                  { label: "Transparent Process", icon: CheckCircle },
                  { label: "Fast Refunds", icon: CheckCircle },
                ].map((item, index) => (
                  <motion.div
                    key={item.label}
                    initial={{ opacity: 0, scale: 0.8 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                    className="flex items-center gap-2"
                  >
                    <item.icon className="h-5 w-5" />
                    <span>{item.label}</span>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
};

export default Returns;