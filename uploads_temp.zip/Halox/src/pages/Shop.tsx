import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { 
  Search, 
  Filter, 
  Grid3X3, 
  List, 
  ChevronRight,
  Zap,
  Plug,
  Lightbulb,
  Settings,
  ShoppingBag,
  Star,
  TrendingUp
} from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import ProductCard from "@/components/ProductCard";

const Shop = () => {
  const [viewMode, setViewMode] = useState('grid');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortOption, setSortOption] = useState('default');
  const [visibleCount, setVisibleCount] = useState(12);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [quantity, setQuantity] = useState(1);
  const [cartCount, setCartCount] = useState(0);

  const categories = [
    { 
      id: 'smart-plugs', 
      name: 'Smart Plugs', 
      icon: Plug,
      count: 24,
      description: 'Remote control power outlets'
    },
    { 
      id: 'touch-switches', 
      name: 'Touch Switches', 
      icon: Zap,
      count: 18,
      description: 'Modern touch control switches'
    },
    { 
      id: 'led-strips', 
      name: 'LED Strips', 
      icon: Lightbulb,
      count: 12,
      description: 'Colorful ambient lighting'
    },
    { 
      id: 'controllers', 
      name: 'Controllers', 
      icon: Settings,
      count: 8,
      description: 'Advanced device controllers'
    }
  ];

  // Mock products data - replace with real data
  const products = [
    {
      id: "1",
      name: "Halox Smart Touch Switch 4-Way Premium",
      price: 1299,
      originalPrice: 1699,
      rating: 4.8,
      image: "smart-switch.jpg",
      category: "touch-switches",
      isBestSeller: true,
      isOnSale: true,
      features: ["WiFi", "Smart Control"]
    },
    {
      id: "2", 
      name: "Halox Smart Plug 16A",
      price: 899,
      originalPrice: 1199,
      rating: 4.7,
      image: "smart-plug.jpg",
      category: "smart-plugs",
      isBestSeller: true,
      features: ["WiFi", "Power Monitoring"]
    },
    {
      id: "3",
      name: "Halox RGB LED Strip 5m with Controller",
      price: 2499,
      originalPrice: 3499,
      rating: 4.9,
      image: "led-strip.jpg", 
      category: "led-strips",
      isOnSale: true,
      features: ["WiFi", "16M Colors"]
    },
    {
      id: "4",
      name: "Halox Smart Fan Controller with Timer",
      price: 1899,
      rating: 4.6,
      image: "smart-controller.jpg",
      category: "controllers",
      features: ["WiFi", "Speed Control"]
    },
    {
      id: "5",
      name: "Halox Smart Door Lock Biometric",
      price: 8999,
      originalPrice: 11999,
      rating: 4.8,
      image: "smart-lock.jpg",
      category: "security",
      isBestSeller: true,
      isOnSale: true,
      features: ["Biometric", "Smart Control"]
    },
    {
      id: "6",
      name: "Halox Motion Sensor Smart Light",
      price: 1599,
      rating: 4.5,
      image: "/api/placeholder/300/300",
      category: "sensors",
      features: ["Motion Detection", "Auto On/Off"]
    },
    {
      id: "7",
      name: "Halox Smart Switch 2-Way Touch Glass",
      price: 799,
      originalPrice: 999,
      rating: 4.6,
      image: "/api/placeholder/300/300",
      category: "touch-switches",
      isOnSale: true,
      features: ["WiFi", "Touch Control"]
    },
    {
      id: "8",
      name: "Halox Smart Plug Mini 10A",
      price: 649,
      rating: 4.4,
      image: "/api/placeholder/300/300",
      category: "smart-plugs",
      features: ["WiFi", "Compact Design"]
    },
    {
      id: "9",
      name: "Halox Smart Switch 3-Way Premium",
      price: 1099,
      originalPrice: 1399,
      rating: 4.7,
      image: "/api/placeholder/300/300",
      category: "touch-switches",
      isBestSeller: true,
      isOnSale: true,
      features: ["WiFi", "Smart Control"]
    },
    {
      id: "10",
      name: "Halox LED Strip 3m Warm White",
      price: 1299,
      rating: 4.5,
      image: "/api/placeholder/300/300",
      category: "led-strips",
      features: ["WiFi", "Warm Light"]
    },
    {
      id: "11",
      name: "Halox Smart Dimmer Switch",
      price: 1499,
      originalPrice: 1899,
      rating: 4.8,
      image: "/api/placeholder/300/300",
      category: "touch-switches",
      isOnSale: true,
      features: ["WiFi", "Dimmer Control"]
    },
    {
      id: "12",
      name: "Halox Smart Plug 20A Industrial",
      price: 1199,
      rating: 4.6,
      image: "/api/placeholder/300/300",
      category: "smart-plugs",
      features: ["WiFi", "Heavy Duty"]
    },
    {
      id: "13",
      name: "Halox RGB LED Strip 10m Pro",
      price: 3999,
      originalPrice: 4999,
      rating: 4.9,
      image: "/api/placeholder/300/300",
      category: "led-strips",
      isBestSeller: true,
      isOnSale: true,
      features: ["WiFi", "16M Colors"]
    },
    {
      id: "14",
      name: "Halox Smart Curtain Controller",
      price: 2899,
      rating: 4.5,
      image: "/api/placeholder/300/300",
      category: "controllers",
      features: ["WiFi", "Auto Control"]
    },
    {
      id: "15",
      name: "Halox Smart Doorbell Camera",
      price: 5999,
      originalPrice: 7999,
      rating: 4.7,
      image: "/api/placeholder/300/300",
      category: "security",
      isOnSale: true,
      features: ["WiFi", "HD Camera"]
    },
    {
      id: "16",
      name: "Halox Temperature Sensor Pro",
      price: 899,
      rating: 4.4,
      image: "/api/placeholder/300/300",
      category: "sensors",
      features: ["WiFi", "Temperature Monitoring"]
    },
    {
      id: "17",
      name: "Halox Smart Switch 1-Way Basic",
      price: 599,
      originalPrice: 799,
      rating: 4.3,
      image: "/api/placeholder/300/300",
      category: "touch-switches",
      isOnSale: true,
      features: ["WiFi", "Basic Control"]
    },
    {
      id: "18",
      name: "Halox Smart Plug with USB",
      price: 999,
      rating: 4.5,
      image: "/api/placeholder/300/300",
      category: "smart-plugs",
      features: ["WiFi", "USB Charging"]
    },
    {
      id: "19",
      name: "Halox LED Strip Corner Kit",
      price: 1899,
      rating: 4.6,
      image: "/api/placeholder/300/300",
      category: "led-strips",
      features: ["WiFi", "Corner Design"]
    },
    {
      id: "20",
      name: "Halox Smart Water Level Controller",
      price: 3499,
      originalPrice: 4199,
      rating: 4.8,
      image: "/api/placeholder/300/300",
      category: "controllers",
      isBestSeller: true,
      isOnSale: true,
      features: ["WiFi", "Auto Fill"]
    },
    {
      id: "21",
      name: "Halox Smart Security Camera 360°",
      price: 4999,
      rating: 4.7,
      image: "/api/placeholder/300/300",
      category: "security",
      features: ["WiFi", "360° View"]
    },
    {
      id: "22",
      name: "Halox Door Window Sensor",
      price: 699,
      originalPrice: 899,
      rating: 4.4,
      image: "/api/placeholder/300/300",
      category: "sensors",
      isOnSale: true,
      features: ["WiFi", "Door Alert"]
    },
    {
      id: "23",
      name: "Halox Smart Switch 6-Way Master",
      price: 1999,
      rating: 4.9,
      image: "/api/placeholder/300/300",
      category: "touch-switches",
      isBestSeller: true,
      features: ["WiFi", "Multi Control"]
    },
    {
      id: "24",
      name: "Halox Outdoor Smart Plug IP65",
      price: 1399,
      originalPrice: 1699,
      rating: 4.6,
      image: "/api/placeholder/300/300",
      category: "smart-plugs",
      isOnSale: true,
      features: ["WiFi", "Weatherproof"]
    },
    {
      id: "25",
      name: "Halox LED Strip Kitchen Under Cabinet",
      price: 1699,
      rating: 4.5,
      image: "/api/placeholder/300/300",
      category: "led-strips",
      features: ["WiFi", "Under Cabinet"]
    },
    {
      id: "26",
      name: "Halox Smart AC Controller Universal",
      price: 2199,
      originalPrice: 2699,
      rating: 4.7,
      image: "/api/placeholder/300/300",
      category: "controllers",
      isOnSale: true,
      features: ["WiFi", "Universal Control"]
    },
    {
      id: "27",
      name: "Halox Smart Lock Keypad Pro",
      price: 12999,
      rating: 4.8,
      image: "/api/placeholder/300/300",
      category: "security",
      isBestSeller: true,
      features: ["WiFi", "Keypad Access"]
    },
    {
      id: "28",
      name: "Halox Smoke Detector Smart",
      price: 1999,
      originalPrice: 2499,
      rating: 4.6,
      image: "/api/placeholder/300/300",
      category: "sensors",
      isOnSale: true,
      features: ["WiFi", "Smoke Detection"]
    },
    {
      id: "29",
      name: "Halox Smart Switch Scene Controller",
      price: 1799,
      rating: 4.7,
      image: "/api/placeholder/300/300",
      category: "touch-switches",
      features: ["WiFi", "Scene Control"]
    },
    {
      id: "30",
      name: "Halox Smart Plug Energy Monitor Pro",
      price: 1299,
      originalPrice: 1599,
      rating: 4.8,
      image: "/api/placeholder/300/300",
      category: "smart-plugs",
      isBestSeller: true,
      isOnSale: true,
      features: ["WiFi", "Energy Monitor"]
    },
    {
      id: "31",
      name: "Halox LED Strip TV Backlight",
      price: 999,
      rating: 4.4,
      image: "/api/placeholder/300/300",
      category: "led-strips",
      features: ["WiFi", "TV Backlight"]
    },
    {
      id: "32",
      name: "Halox Smart Geyser Controller Timer",
      price: 1799,
      originalPrice: 2199,
      rating: 4.6,
      image: "/api/placeholder/300/300",
      category: "controllers",
      isOnSale: true,
      features: ["WiFi", "Timer Control"]
    },
    {
      id: "33",
      name: "Halox Smart Floodlight Camera",
      price: 7999,
      rating: 4.7,
      image: "/api/placeholder/300/300",
      category: "security",
      features: ["WiFi", "Floodlight"]
    },
    {
      id: "34",
      name: "Halox Air Quality Sensor PM2.5",
      price: 2499,
      originalPrice: 2999,
      rating: 4.5,
      image: "/api/placeholder/300/300",
      category: "sensors",
      isOnSale: true,
      features: ["WiFi", "Air Quality"]
    },
    {
      id: "35",
      name: "Halox Smart Switch Touch Panel 8-Way",
      price: 2799,
      rating: 4.8,
      image: "/api/placeholder/300/300",
      category: "touch-switches",
      isBestSeller: true,
      features: ["WiFi", "Touch Panel"]
    },
    {
      id: "36",
      name: "Halox Smart Plug Wireless Remote",
      price: 799,
      originalPrice: 999,
      rating: 4.3,
      image: "/api/placeholder/300/300",
      category: "smart-plugs",
      isOnSale: true,
      features: ["WiFi", "Remote Control"]
    },
    {
      id: "37",
      name: "Halox LED Strip Flexible 15m",
      price: 4999,
      rating: 4.6,
      image: "/api/placeholder/300/300",
      category: "led-strips",
      features: ["WiFi", "Ultra Long"]
    },
    {
      id: "38",
      name: "Halox Smart Motor Controller Garage",
      price: 3999,
      originalPrice: 4799,
      rating: 4.7,
      image: "/api/placeholder/300/300",
      category: "controllers",
      isOnSale: true,
      features: ["WiFi", "Garage Door"]
    },
    {
      id: "39",
      name: "Halox Smart Intercom Video Door Phone",
      price: 15999,
      rating: 4.9,
      image: "/api/placeholder/300/300",
      category: "security",
      isBestSeller: true,
      features: ["WiFi", "Video Call"]
    },
    {
      id: "40",
      name: "Halox Vibration Sensor Security",
      price: 1199,
      originalPrice: 1499,
      rating: 4.4,
      image: "/api/placeholder/300/300",
      category: "sensors",
      isOnSale: true,
      features: ["WiFi", "Vibration Alert"]
    }
  ];

  // Initialize cart count from localStorage
  useEffect(() => {
    const cart = JSON.parse(localStorage.getItem('cart') || '[]');
    const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
    setCartCount(totalItems);
  }, []);

  // Filter and sort products based on selected category, search query, and sort option
  const filteredProducts = products
    .filter(product => {
      const matchesCategory = selectedCategory === 'all' || product.category === selectedCategory;
      const query = searchQuery.toLowerCase().trim();
      if (!query) return matchesCategory;
      return matchesCategory && (
        product.name.toLowerCase().includes(query) ||
        product.features.some(feature => feature.toLowerCase().includes(query))
      );
    })
    .sort((a, b) => {
      switch (sortOption) {
        case 'price-low-to-high':
          return a.price - b.price;
        case 'price-high-to-low':
          return b.price - a.price;
        case 'avg-customer-review':
          return b.rating - a.rating;
        case 'newest-arrivals':
          return parseInt(b.id) - parseInt(a.id);
        case 'best-sellers':
          return (b.isBestSeller ? 1 : 0) - (a.isBestSeller ? 1 : 0);
        default:
          return 0;
      }
    });

  const handleAddToCart = (product) => {
    setSelectedProduct(product);
    setQuantity(1);
    setIsModalOpen(true);
  };

  const handleFinalAddToCart = () => {
    // Get existing cart from localStorage
    const cart = JSON.parse(localStorage.getItem('cart') || '[]');
    
    // Check if product already exists in cart
    const existingItemIndex = cart.findIndex(item => item.id === selectedProduct.id);
    
    if (existingItemIndex !== -1) {
      // Update quantity if product exists
      cart[existingItemIndex].quantity += quantity;
    } else {
      // Add new product to cart
      cart.push({
        id: selectedProduct.id,
        name: selectedProduct.name,
        price: selectedProduct.price,
        quantity: quantity,
        image: selectedProduct.image
      });
    }
    
    // Save updated cart to localStorage
    localStorage.setItem('cart', JSON.stringify(cart));
    
    // Update cart count
    const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
    setCartCount(totalItems);
    
    console.log(`Added ${quantity} of ${selectedProduct.name} to cart`);
    setIsModalOpen(false);
  };

  return (
    <div className="min-h-screen bg-background">
      <Header cartCount={cartCount} />
      
      {/* Hero Section */}
      <section className="relative bg-[#eb6a0e] py-20 overflow-hidden">
        {/* Animated Background Elements */}
        <div className="absolute inset-0">
          <div className="absolute inset-0 bg-white/10 bg-[radial-gradient(circle_300px_at_20%_20%,rgba(255,255,255,0.2)_10%,transparent_70%)] animate-pulse-slow opacity-50"></div>
          <div className="absolute top-10 left-10 w-48 h-48 bg-white/5 rounded-full blur-2xl animate-float" style={{ animationDuration: "12s" }}></div>
          <div className="absolute bottom-10 right-10 w-64 h-64 bg-white/5 rounded-full blur-2xl animate-float" style={{ animationDuration: "15s", animationDelay: "3s" }}></div>
        </div>
        
        <div className="container mx-auto px-6 relative z-10">
          <div className="text-center space-y-12">
            <div className="space-y-6">
              <Badge className="bg-white/20 text-white border-white/30 backdrop-blur-md animate-fade-in">
                <ShoppingBag className="h-4 w-4 mr-2" />
                Premium Smart Collection
              </Badge>
              
              <h1 className="text-5xl md:text-7xl lg:text-8xl font-display font-extrabold bg-gradient-to-r from-white via-gray-100 to-white bg-clip-text text-transparent leading-tight animate-slide-up">
                Discover Smart Living
                <span className="block mt-4">Shop the Future</span>
              </h1>
              
              <p className="text-2xl md:text-3xl text-white/90 max-w-4xl mx-auto leading-relaxed animate-fade-in">
                Explore our premium range of smart home devices, crafted for innovation and convenience. 
                Transform your space with cutting-edge technology.
              </p>
            </div>

            {/* Enhanced Quick Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8 pt-12">
              {[
                { label: "Products", value: "40+", icon: ShoppingBag },
                { label: "Categories", value: "6", icon: Grid3X3 },
                { label: "Average Rating", value: "4.7⭐", icon: Star },
                { label: "Best Sellers", value: "12", icon: TrendingUp }
              ].map((stat, index) => (
                <div key={stat.label} className="text-center animate-fade-in" style={{ animationDelay: `${index * 0.15}s` }}>
                  <stat.icon className="h-10 w-10 mx-auto mb-3 text-white/80 group-hover:text-white transition-colors" />
                  <div className="text-3xl font-bold text-white">{stat.value}</div>
                  <div className="text-lg text-white/70">{stat.label}</div>
                </div>
              ))}
            </div>

            {/* Call to Action */}
            <div className="flex justify-center gap-6">
              <Button size="lg" className="bg-white text-[#eb6a0e] hover:bg-gray-100 font-bold px-8 py-4 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300">
                Shop Now
              </Button>
              <Button size="lg" variant="outline" className="bg-transparent border-white text-white hover:bg-white/10 font-bold px-8 py-4 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300">
                Learn More
              </Button>
            </div>
          </div>
        </div>
      </section>
      
      <main className="container mx-auto px-4 py-8">
        {/* Breadcrumb */}
        <div className="flex items-center gap-2 text-sm text-muted-foreground mb-8">
          <span>Home</span>
          <ChevronRight className="h-4 w-4" />
          <span className="text-foreground font-medium">Shop</span>
        </div>

        {/* Page Header */}
        <div className="text-center space-y-6 mb-16 relative">
          <div className="absolute inset-0 bg-gradient-to-r from-primary/5 via-secondary/5 to-accent/5 rounded-3xl blur-3xl"></div>
          <div className="relative z-10 space-y-4">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-display font-bold bg-gradient-to-r from-primary via-secondary to-accent bg-clip-text text-transparent">
              Smart Home Products
            </h1>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
              Discover our complete range of smart home devices designed for Indian homes.
            </p>
            <div className="flex items-center justify-center gap-6 pt-4">
              <div className="flex items-center gap-2 text-primary">
                <div className="w-2 h-2 bg-primary rounded-full animate-pulse"></div>
                <span className="text-sm font-medium">Made in India</span>
              </div>
              <div className="flex items-center gap-2 text-secondary">
                <div className="w-2 h-2 bg-secondary rounded-full animate-pulse"></div>
                <span className="text-sm font-medium">Premium Quality</span>
              </div>
              <div className="flex items-center gap-2 text-accent">
                <div className="w-2 h-2 bg-accent rounded-full animate-pulse"></div>
                <span className="text-sm font-medium">Smart Technology</span>
              </div>
            </div>
          </div>
        </div>

        {/* Category Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {categories.map((category, index) => {
            const gradientColors = [
              'from-primary/20 via-primary/10 to-transparent',
              'from-secondary/20 via-secondary/10 to-transparent', 
              'from-accent/20 via-accent/10 to-transparent',
              'from-orange-500/20 via-orange-500/10 to-transparent'
            ];
            const iconColors = ['text-primary', 'text-secondary', 'text-accent', 'text-orange-500'];
            const borderColors = ['hover:border-primary', 'hover:border-secondary', 'hover:border-accent', 'hover:border-orange-500'];
            
            return (
              <Card 
                key={category.id} 
                className={`cursor-pointer group hover:shadow-2xl hover:shadow-primary/20 transition-all duration-500 border-2 ${borderColors[index]} hover:scale-105 relative overflow-hidden ${selectedCategory === category.id ? 'border-primary shadow-primary/20' : ''}`}
                onClick={() => setSelectedCategory(category.id)}
              >
                <div className={`absolute inset-0 bg-gradient-to-br ${gradientColors[index]} opacity-0 group-hover:opacity-100 transition-opacity duration-500`}></div>
                <CardContent className="p-8 text-center space-y-4 relative z-10">
                  <div className={`bg-gradient-to-br ${gradientColors[index]} w-20 h-20 rounded-2xl mx-auto flex items-center justify-center group-hover:scale-110 transition-all duration-300 shadow-lg`}>
                    <category.icon className={`h-10 w-10 ${iconColors[index]} group-hover:drop-shadow-lg`} />
                  </div>
                  <div className="space-y-3">
                    <h3 className={`font-bold text-lg text-foreground group-hover:${iconColors[index]} transition-colors duration-300`}>
                      {category.name}
                    </h3>
                    <p className="text-muted-foreground group-hover:text-foreground transition-colors">
                      {category.description}
                    </p>
                    <Badge variant="secondary" className="text-xs font-semibold px-3 py-1 rounded-full">
                      {category.count} Products
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Filters and Search */}
        <div className="bg-gradient-to-r from-primary/5 via-secondary/5 to-accent/5 rounded-2xl p-6 border border-primary/10 mb-8">
          <div className="flex flex-col md:flex-row gap-4 justify-between items-center">
            <div className="flex items-center gap-4 w-full md:w-auto">
              <div className="relative flex-1 md:w-80">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-primary" />
                <Input 
                  placeholder="Search products..." 
                  className="pl-10 border-primary/20 focus:border-primary bg-background/80 backdrop-blur-sm"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <div className="relative">
                <Filter className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-primary" />
                <select
                  className="pl-10 pr-8 py-2 border border-primary/20 rounded-lg bg-background/80 backdrop-blur-sm text-foreground focus:outline-none focus:border-primary appearance-none cursor-pointer"
                  value={sortOption}
                  onChange={(e) => setSortOption(e.target.value)}
                >
                  <option value="default">Sort by: Default</option>
                  <option value="best-sellers">Best Sellers</option>
                  <option value="price-low-to-high">Price: Low to High</option>
                  <option value="price-high-to-low">Price: High to Low</option>
                  <option value="avg-customer-review">Avg. Customer Review</option>
                  <option value="newest-arrivals">Newest Arrivals</option>
                </select>
                <ChevronRight className="absolute right-2 top-1/2 transform -translate-y-1/2 h-4 w-4 text-primary pointer-events-none" style={{ transform: 'rotate(90deg)' }} />
              </div>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-sm text-muted-foreground">View:</span>
              <div className="flex border rounded-lg border-primary/20">
                <Button
                  variant={viewMode === 'grid' ? 'default' : 'ghost'}
                  size="sm"
                  onClick={() => setViewMode('grid')}
                  className="rounded-r-none"
                >
                  <Grid3X3 className="h-4 w-4" />
                </Button>
                <Button
                  variant={viewMode === 'list' ? 'default' : 'ghost'}
                  size="sm"
                  onClick={() => setViewMode('list')}
                  className="rounded-l-none"
                >
                  <List className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Products Grid */}
        <div className={`grid gap-6 ${
          viewMode === 'grid' 
            ? 'grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4' 
            : 'grid-cols-1'
        }`}>
          {filteredProducts.slice(0, visibleCount).length > 0 ? (
            filteredProducts.slice(0, visibleCount).map((product) => (
              <div key={product.id} className="slide-up">
                <ProductCard {...product} onAddToCart={() => handleAddToCart(product)} />
              </div>
            ))
          ) : (
            <div className="col-span-full text-center py-12">
              <p className="text-lg text-muted-foreground">No products found.</p>
            </div>
          )}
        </div>

        {/* Load More */}
        <div className="text-center mt-16 space-y-6">
          <div className="relative">
            <div className="absolute inset-0 bg-gradient-to-r from-primary/20 via-secondary/20 to-accent/20 rounded-2xl blur-2xl"></div>
            <Button 
              size="lg" 
              className="relative z-10 bg-orange-500 hover:from-primary/90 hover:to-secondary/90 text-white font-semibold px-12 py-4 text-lg shadow-lg hover:shadow-xl transition-all duration-300"
              onClick={() => setVisibleCount(filteredProducts.length)}
            >
              Load More Products
            </Button>
          </div>
          <div className="flex items-center justify-center gap-4">
            <div className="h-px bg-gradient-to-r from-transparent via-primary/30 to-transparent w-24"></div>
            <p className="text-sm text-muted-foreground font-medium">
              Showing {Math.min(visibleCount, filteredProducts.length)} of {filteredProducts.length} products
            </p>
            <div className="h-px bg-gradient-to-r from-transparent via-primary/30 to-transparent w-24"></div>
          </div>
        </div>

        {/* Features Banner */}
        <div className="mt-20 relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-secondary/10 to-accent/10 rounded-3xl"></div>
          <div className="relative z-10 bg-gradient-card rounded-3xl p-10 border border-primary/20 shadow-2xl">
            <div className="grid md:grid-cols-3 gap-8 text-center">
              <div className="space-y-4 group hover:scale-105 transition-transform duration-300">
                <div className="bg-gradient-to-br from-primary/20 to-primary/10 w-16 h-16 rounded-3xl mx-auto flex items-center justify-center shadow-lg group-hover:shadow-primary/20 group-hover:shadow-xl transition-all duration-300">
                  <Zap className="h-8 w-8 text-primary group-hover:scale-110 transition-transform duration-300" />
                </div>
                <h3 className="font-bold text-xl text-foreground group-hover:text-primary transition-colors">Easy Installation</h3>
                <p className="text-muted-foreground leading-relaxed">
                  DIY-friendly setup with step-by-step guidance
                </p>
              </div>
              <div className="space-y-4 group hover:scale-105 transition-transform duration-300">
                <div className="bg-gradient-to-br from-secondary/20 to-secondary/10 w-16 h-16 rounded-3xl mx-auto flex items-center justify-center shadow-lg group-hover:shadow-secondary/20 group-hover:shadow-xl transition-all duration-300">
                  <Settings className="h-8 w-8 text-secondary group-hover:scale-110 transition-transform duration-300" />
                </div>
                <h3 className="font-bold text-xl text-foreground group-hover:text-secondary transition-colors">2 Year Warranty</h3>
                <p className="text-muted-foreground leading-relaxed">
                  Comprehensive warranty with free replacement
                </p>
              </div>
              <div className="space-y-4 group hover:scale-105 transition-transform duration-300">
                <div className="bg-gradient-to-br from-accent/20 to-accent/10 w-16 h-16 rounded-3xl mx-auto flexBrasflex items-center justify-center shadow-lg group-hover:shadow-accent/20 group-hover:shadow-xl transition-all duration-300">
                  <Plug className="h-8 w-8 text-accent group-hover:scale-110 transition-transform duration-300" />
                </div>
                <h3 className="font-bold text-xl text-foreground group-hover:text-accent transition-colors">Free Shipping</h3>
                <p className="text-muted-foreground leading-relaxed">
                  Free delivery on orders above ₹999
                </p>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Product Details Modal */}
      <Dialog open={isModalOpen} onOpenChange={setIsModalOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{selectedProduct?.name}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <img 
              src={selectedProduct?.image} 
              alt={selectedProduct?.name} 
              className="w-full h-64 object-cover rounded-lg"
            />
            <p className="text-lg font-bold">Price: ₹{selectedProduct?.price}</p>
            {selectedProduct?.originalPrice && (
              <p className="text-muted-foreground line-through">Original Price: ₹{selectedProduct?.originalPrice}</p>
            )}
            <p>Rating: {selectedProduct?.rating} ⭐</p>
            <p>Features: {selectedProduct?.features.join(", ")}</p>
            <div className="flex items-center gap-4">
              <Button onClick={() => setQuantity(Math.max(1, quantity - 1))}>-</Button>
              <span className="text-xl">{quantity}</span>
              <Button onClick={() => setQuantity(quantity + 1)}>+</Button>
            </div>
            <Button onClick={handleFinalAddToCart} className="w-full">Add to Cart</Button>
          </div>
        </DialogContent>
      </Dialog>

      <Footer />
    </div>
  );
};

// CSS Animations
const styles = `
  @keyframes pulse-slow {
    0%, 100% { opacity: 0.5; }
    50% { opacity: 0.7; }
  }
  @keyframes float {
    0%, 100% { transform: translateY(0); }
    50% { transform: translateY(-20px); }
  }
  @keyframes slide-up {
    0% { transform: translateY(20px); opacity: 0; }
    100% { transform: translateY(0); opacity: 1; }
  }
  @keyframes fade-in {
    0% { opacity: 0; }
    100% { opacity: 1; }
  }
  .animate-pulse-slow { animation: pulse-slow 10s ease-in-out infinite; }
  .animate-float { animation: float 8s ease-in-out infinite; }
  .animate-slide-up { animation: slide-up 1s ease-out; }
  .animate-fade-in { animation: fade-in 1.5s ease-out; }
`;

export default Shop;