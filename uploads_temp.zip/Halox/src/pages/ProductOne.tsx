import { useState } from "react";
import { CheckCircle, Plug, ChevronLeft, ChevronRight, ChevronDown } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

// Example product data (Halox Wi-Fi Smart Plug 16A)
const product = {
  id: "sp16a",
  name: "Halox Wi-Fi Smart Plug 16A",
  type: "Smart Plug",
  image: "smart-plug.jpg",
  price: "₹1,549",
  tagline: "Heavy Appliance Control",
  highlights: [
    "Alexa & Google Home",
    "Scheduler & Timer",
    "App & Voice Control",
  ],
  specs: {
    Current: "16A",
    Voltage: "220V AC",
    Warranty: "1 Year",
    Connectivity: "Wi-Fi 2.4GHz",
    MaxLoad: "3680W",
    Material: "Fire-resistant Polycarbonate",
  },
};

// Related products (subset from productList in ProductPage.tsx)
const relatedProducts = [
  {
    id: "sp10a",
    name: "Halox Wi-Fi Smart Plug 10A",
    type: "Smart Plug",
    image: "led-strip.jpg",
    price: "₹849",
    tagline: "Daily Device Smartness",
  },
  {
    id: "touch4g",
    name: "Halox Smart 4-Gang Touch Switch",
    type: "Smart Switch",
    image: "smart-controller.jpg",
    price: "₹2,699",
    tagline: "Multi-Light Voice Control",
  },
  {
    id: "dlb9w",
    name: "Halox Smart LED Bulb 9W",
    type: "Smart Bulb",
    image: "smart-controller.jpg",
    price: "₹649",
    tagline: "Dimmable, Colorful, Smart",
  },
];

// Product-specific FAQs
const productFaqs = [
  {
    question: "Can the Halox Wi-Fi Smart Plug 16A handle heavy appliances?",
    answer:
      "Yes, it supports up to 16A (3680W), making it ideal for heavy appliances like air conditioners, geysers, and washing machines.",
  },
  {
    question: "Does it require a hub to work?",
    answer:
      "No, the smart plug connects directly to your 2.4GHz Wi-Fi network, no hub needed.",
  },
  {
    question: "Is it safe for continuous use?",
    answer:
      "Absolutely, it’s made with fire-resistant polycarbonate and includes overload protection for safety.",
  },
];

// ProductOne Component
const ProductOne = () => {
  const [openFaq, setOpenFaq] = useState(null);

  // Function to navigate back to products page
  const goBackToProducts = () => {
    window.location.href = "/products";
  };

  // Toggle FAQ accordion
  const toggleFaq = (idx) => {
    setOpenFaq(openFaq === idx ? null : idx);
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main>
        {/* Hero Section */}
        <section className="relative min-h-[50vh] flex flex-col items-center justify-center px-4 pt-16 overflow-hidden">
          <div className="absolute inset-0 w-full h-full">
            <img
              src="https://picsum.photos/id/1015/1200/600"
              alt="Smart Plug Hero"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-black/50" /> {/* Overlay for text readability */}
          </div>
          <div className="relative z-10 text-center">
            <h1 className="text-5xl font-bold text-white mb-4">{product.name}</h1>
            <p className="text-xl text-white/80 mb-6 max-w-2xl">
              {product.tagline} – Control your heavy appliances with ease using
              voice commands or the Halox app, anytime, anywhere.
            </p>
            <button
              onClick={() => window.scrollTo({ top: window.innerHeight, behavior: "smooth" })}
              className="bg-cyan-500 hover:bg-cyan-700 text-white px-8 py-4 rounded-lg font-bold shadow-lg inline-flex items-center"
            >
              <Plug className="mr-2 h-5 w-5" />
              Explore Features
            </button>
          </div>
        </section>

        {/* Product Detail Section */}
        <section className="py-24 bg-gray-50">
          <div className="container mx-auto px-4 max-w-4xl">
            <div className="flex gap-10 flex-col md:flex-row items-start">
              <img
                src={product.image}
                alt={product.name}
                className="rounded-2xl shadow-lg w-[320px] h-[320px] object-cover"
              />
              <div>
                <h2 className="text-4xl font-bold text-gray-900 mb-2">
                  {product.name}
                </h2>
                <p className="text-xl text-teal-600 mb-4">{product.tagline}</p>
                <p className="mb-6 text-gray-600 font-semibold">{product.price}</p>
                <ul className="mb-6">
                  {product.highlights.map((hl, i) => (
                    <li key={i} className="flex items-center gap-2 text-gray-700 mb-2">
                      <CheckCircle className="h-5 w-5 text-emerald-500" />
                      {hl}
                    </li>
                  ))}
                </ul>
                <div className="mb-6">
                  <h3 className="text-2xl font-semibold text-gray-900 mb-2">
                    Technical Specifications
                  </h3>
                  <table className="bg-white rounded-xl w-full text-gray-700 shadow">
                    <tbody>
                      {Object.entries(product.specs).map(([k, v], i) => (
                        <tr key={i}>
                          <td className="py-2 px-4 font-semibold">{k}</td>
                          <td className="py-2 px-4">{v}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                <div className="flex gap-4">
                  <button className="bg-cyan-500 hover:bg-cyan-700 text-white px-8 py-4 rounded-lg font-bold shadow-lg inline-flex items-center">
                    <Plug className="mr-2 h-5 w-5" />
                    Buy Now
                  </button>
                  <button
                    onClick={goBackToProducts}
                    className="border border-teal-600 text-teal-600 px-8 py-4 rounded-lg font-semibold transition-all hover:bg-teal-50"
                  >
                    Back to Products
                  </button>
                </div>
              </div>
            </div>
            <div className="mt-12">
              <h3 className="text-3xl font-bold text-gray-900 mb-4">
                Product Description
              </h3>
              <p className="text-gray-600 mb-4">
                The Halox Wi-Fi Smart Plug 16A is your gateway to smart home
                automation for heavy appliances. Designed for high-power devices
                like air conditioners, water heaters, and washing machines, this
                smart plug lets you control your appliances remotely via the Halox
                app or voice commands with Alexa and Google Home.
              </p>
              <p className="text-gray-600 mb-4">
                Set schedules, timers, or monitor energy usage effortlessly. Its
                fire-resistant polycarbonate build ensures safety, while the
                compact design fits seamlessly into any Indian household socket.
                Whether you're at home or away, take control of your appliances
                with ease and efficiency.
              </p>
              <h4 className="text-xl font-semibold text-gray-900 mb-2">
                Key Benefits
              </h4>
              <ul className="text-gray-600 list-disc pl-5">
                <li>Seamless integration with Alexa and Google Home for hands-free control.</li>
                <li>Schedule appliances to save energy and automate daily routines.</li>
                <li>Remote access via the Halox app for control from anywhere.</li>
                <li>Robust safety features with overload protection and durable materials.</li>
              </ul>
            </div>
          </div>
        </section>

        {/* Product-Specific FAQ Section */}
        <section className="py-24 bg-white">
          <div className="container mx-auto px-4 max-w-4xl">
            <h2 className="text-4xl font-bold text-gray-900 mb-8 text-center">
              Frequently Asked Questions
            </h2>
            <div>
              {productFaqs.map((faq, idx) => (
                <div key={idx} className="border border-gray-200 rounded-lg mb-4">
                  <button
                    onClick={() => toggleFaq(idx)}
                    className="w-full px-6 py-4 text-left flex justify-between items-center hover:bg-gray-50 transition-colors"
                  >
                    <span className="font-semibold text-gray-900">{faq.question}</span>
                    <ChevronDown
                      className={`h-5 w-5 text-gray-500 transition-transform ${
                        openFaq === idx && "rotate-180"
                      }`}
                    />
                  </button>
                  {openFaq === idx && (
                    <div className="px-6 pb-4 text-gray-600">{faq.answer}</div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Related Products Section */}
        <section className="py-24 bg-gray-50">
          <div className="container mx-auto px-4">
            <h2 className="text-4xl font-bold mb-12 text-center text-purple-600 underline">
              Explore More Smart Products
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-10">
              {relatedProducts.map((prod) => (
                <div
                  key={prod.id}
                  className="bg-gradient-to-br from-white to-gray-50 rounded-xl p-6 shadow-lg border border-gray-100 hover:shadow-2xl transition cursor-pointer group flex flex-col items-center"
                  onClick={() => window.location.href = `/product/${prod.id}`}
                >
                  <img
                    src={prod.image}
                    alt={prod.name}
                    className="rounded-xl h-40 w-40 object-cover mb-4 group-hover:scale-105 transition"
                  />
                  <h3 className="text-xl font-bold text-gray-900 mb-1 text-center">
                    {prod.name}
                  </h3>
                  <div className="text-teal-700 text-sm font-semibold mb-2">
                    {prod.tagline}
                  </div>
                  <div className="text-lg text-gray-800 font-bold my-1">
                    {prod.price}
                  </div>
                  <button className="bg-cyan-500 hover:bg-cyan-600 text-white px-4 py-2 rounded font-semibold mt-auto">
                    View Details
                  </button>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-24 bg-gradient-to-br from-teal-600 via-emerald-600 to-cyan-800 text-white">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">
              Make Your Home Smarter Today
            </h2>
            <p className="text-xl text-white/80 mb-8 max-w-2xl mx-auto">
              Get the Halox Wi-Fi Smart Plug 16A and experience seamless control
              over your heavy appliances. Start your smart home journey now!
            </p>
            <button className="bg-white text-teal-600 px-8 py-4 rounded-lg font-semibold shadow-lg transition-all inline-flex items-center">
              <Plug className="mr-2 h-5 w-5" />
              Buy Now
            </button>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default ProductOne;