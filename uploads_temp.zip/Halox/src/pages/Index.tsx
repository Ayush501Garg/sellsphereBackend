import Header from "@/components/Header";
import Hero from "@/components/Hero";
import BestSelling from "@/components/BestSelling";
import RealTimeStats from "@/components/RealTimeStats";
import IndianPrivacy from "@/components/IndianPrivacy";
import MonitoringInsights from "@/components/MonitoringInsights";
import AutomationSchedule from "@/components/AutomationSchedule";
import VoiceAssistant from "@/components/VoiceAssistant";
import Footer from "@/components/Footer";

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <Hero />
      <BestSelling />
      {/* <RealTimeStats /> */}
      <IndianPrivacy />
      <MonitoringInsights />
      <AutomationSchedule />
      <VoiceAssistant />
      <Footer />
    </div>
  );
};

export default Index;