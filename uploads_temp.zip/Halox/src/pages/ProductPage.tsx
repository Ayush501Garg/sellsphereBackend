import { useState, useEffect, useRef } from "react";
import { Link } from "react-router-dom";
import {
  Plug,
  Wifi,
  Smartphone,
  Home,
  Mic,
  Timer,
  Shield,
  CheckCircle,
  Box,
  Info,
  Lightbulb,
  Sun,
  Moon,
  ChevronDown,
  Grid,
  Switch,
  Zap,
  Sliders,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

import banner1 from "/Banner/banner_1.jpg";
import banner2 from "/Banner/banner_2.jpg";

const carouselImage = [banner1, banner2, ];


// Example data for 20 products (mix of smart plugs, switches, bulbs, strip lights, controllers, etc.)
const productList = [
  {
    id: "sp16a",
    name: "Halox Wi-Fi Smart Plug 16A",
    type: "Smart Plug",
    image: "smart-plug.jpg",
    price: "₹1,549",
    tagline: "Heavy Appliance Control",
    highlights: [
      "Alexa & Google Home",
      "Scheduler & Timer",
      "App & Voice Control",
    ],
    specs: { Current: "16A", Voltage: "220V AC", Warranty: "1 Year" },
  },
  {
    id: "sp10a",
    name: "Halox Wi-Fi Smart Plug 10A",
    type: "Smart Plug",
    image: "led-strip.jpg",
    price: "₹849",
    tagline: "Daily Device Smartness",
    highlights: ["Energy Monitor", "Remote Access", "Alexa Compatible"],
    specs: { Current: "10A", Voltage: "220V AC", Warranty: "Replacement" },
  },
  {
    id: "touch4g",
    name: "Halox Smart 4-Gang Touch Switch",
    type: "Smart Switch",
    image: "smart-controller.jpg",
    price: "₹2,699",
    tagline: "Multi-Light Voice Control",
    highlights: ["Touch & Remote", "Voice Assistant", "No Hub Needed"],
    specs: { Gangs: "4", WiFi: "2.4GHz", Warranty: "1 Year" },
  },
  {
    id: "touch2g",
    name: "Halox Smart 2-Gang Touch Switch",
    type: "Smart Switch",
    image: "smart-plug.jpg",
    price: "₹1,749",
    tagline: "Elegant Automation",
    highlights: ["Fits Modular Plates", "Schedule & Timer", "Voice Control"],
    specs: { Gangs: "2", Fits: "Universal", Warranty: "1 Year" },
  },
  {
    id: "dlb9w",
    name: "Halox Smart LED Bulb 9W",
    type: "Smart Bulb",
    image: "smart-controller.jpg",
    price: "₹649",
    tagline: "Dimmable, Colorful, Smart",
    highlights: ["RGB & White", "App/Voice", "Energy Saver"],
    specs: { Power: "9W", Colors: "16 Million", Warranty: "6 Months" },
  },
  {
    id: "dlb15w",
    name: "Halox Smart LED Bulb 15W",
    type: "Smart Bulb",
    image: "led-strip.jpg",
    price: "₹899",
    tagline: "Brighter, Smarter Lighting",
    highlights: ["Dimmable", "Voice Control", "Color Changing"],
    specs: { Power: "15W", Colors: "16 Million", Warranty: "6 Months" },
  },
  {
    id: "rgbstrip5m",
    name: "Halox RGB LED Strip 5M",
    type: "Smart LED Strip",
    image: "smart-plug.jpg",
    price: "₹1,299",
    tagline: "Ambient Smart Lighting",
    highlights: ["Waterproof", "Alexa Compatible", "Color Sync"],
    specs: { Length: "5M", Colors: "RGB Multicolor", Warranty: "1 Year" },
  },
  {
    id: "rgbstrip10m",
    name: "Halox RGB LED Strip 10M",
    type: "Smart LED Strip",
    image: "led-strip.jpg",
    price: "₹2,399",
    tagline: "Double the Fun, Double the Color",
    highlights: ["Energy Efficient", "Voice/App Control", "DIY Ambience"],
    specs: { Length: "10M", Colors: "RGB Multicolor", Warranty: "1 Year" },
  },
  {
    id: "fanmodule",
    name: "Halox Smart Fan Module",
    type: "Fan Controller",
    image: "smart-switch.jpg",
    price: "₹1,199",
    tagline: "Speed & On/Off By Voice",
    highlights: ["App & Voice", "Remote Speed", "Scheduler"],
    specs: { Phases: "Single", Control: "5 Speed", Warranty: "1 Year" },
  },
  {
    id: "curtain1",
    name: "Halox Curtain Controller",
    type: "Smart Curtain",
    image: "smart-plug.jpg",
    price: "₹3,499",
    tagline: "Automate Your Curtains",
    highlights: ["App/Remote/Voice", "Schedule Open/Close", "Easy Setup"],
    specs: { MaxLoad: "25kg", WiFi: "2.4GHz", Warranty: "1 Year" },
  },
  {
    id: "doorlock",
    name: "Halox Smart Door Lock",
    type: "Door Lock",
    image: "led-strip.jpg",
    price: "₹5,499",
    tagline: "Secure Entry, Smart Control",
    highlights: ["PIN & Fingerprint", "Remote Unlock", "Logs & Alerts"],
    specs: { Type: "Deadbolt", Access: "4 Modes", Warranty: "1 Year" },
  },
  {
    id: "glasspanel",
    name: "Halox Glass Touch Panel Switch",
    type: "Switch Panel",
    image: "smart-plug.jpg",
    price: "₹3,299",
    tagline: "Stylish Modular Control",
    highlights: ["Capacitive Touch", "Customizable", "Voice/App"],
    specs: { Material: "Tempered Glass", Gangs: "6", Warranty: "1 Year" },
  },
  {
    id: "remoteir",
    name: "Halox Smart IR Blaster",
    type: "IR Controller",
    image: "smart-switch.jpg",
    price: "₹1,099",
    tagline: "Control AC/TV Remotely",
    highlights: ["App/Voice", "Universal Device", "Schedule Scenes"],
    specs: { Range: "Up to 10m", Devices: "200+", Warranty: "1 Year" },
  },
  {
    id: "powersocket",
    name: "Halox Smart Power Socket",
    type: "Smart Socket",
    image: "led-strip.jpg",
    price: "₹1,399",
    tagline: "Any Device, Smarter",
    highlights: ["Timer", "Voice/App", "Easy DIY"],
    specs: { Current: "6A", Safety: "Child Lock", Warranty: "1 Year" },
  },
  {
    id: "switch1gang",
    name: "Halox 1-Gang Touch Switch",
    type: "Smart Switch",
    image: "smart-plug.jpg",
    price: "₹899",
    tagline: "Simple, Single Control",
    highlights: ["Fits Any Socket", "Timer/Scenes", "App/Voice"],
    specs: { Gangs: "1", Fits: "Modular", Warranty: "1 Year" },
  },
  {
    id: "switch3gang",
    name: "Halox 3-Gang Touch Switch",
    type: "Smart Switch",
    image: "led-strip.jpg",
    price: "₹2,299",
    tagline: "More Lights, More Control",
    highlights: ["Voice Assistant", "Scheduling", "Glass Touch"],
    specs: { Gangs: "3", Remote: "Yes", Warranty: "1 Year" },
  },
  {
    id: "rgbcontroller",
    name: "Halox Smart RGB Controller",
    type: "Lighting Controller",
    image: "smart-controller.jpg",
    price: "₹1,499",
    tagline: "Make Lights Dance",
    highlights: ["App/Voice Scenes", "DIY Modes", "Multiple Effects"],
    specs: { MaxWatt: "192W", Types: "RGB/RGBW", Warranty: "1 Year" },
  },
  {
    id: "watervalve",
    name: "Halox Smart Water Valve",
    type: "Valve Controller",
    image: "smart-plug.jpg",
    price: "₹3,799",
    tagline: "Automate Water Supply",
    highlights: ["Schedule", "App/Voice", "Leak Safety"],
    specs: { Load: "20kg", Control: "Remote", Warranty: "1 Year" },
  },
  {
    id: "motionsensor",
    name: "Halox Smart Motion Sensor",
    type: "Sensor",
    image: "smart-switch.jpg",
    price: "₹1,099",
    tagline: "Automate With Presence",
    highlights: ["Lights On Entry", "App Alerts", "Energy Saver"],
    specs: { Range: "8m", Delay: "2-120s", Warranty: "1 Year" },
  },
  {
    id: "doorcontact",
    name: "Halox Door/Window Contact Sensor",
    type: "Sensor",
    image: "smart-controller.jpg",
    price: "₹849",
    tagline: "Security With Awareness",
    highlights: ["App Notifications", "Automate Actions", "Low Power"],
    specs: { Type: "Magnetic", Battery: "12 months", Warranty: "6 Months" },
  },
];

// FAQ section general for Halox products
const faqs = [
  {
    question: "Are Halox products compatible with Alexa and Google Home?",
    answer:
      "Yes, all Halox smart products can be controlled by both Alexa and Google Home voice assistants for convenient, hands-free automation.",
  },
  {
    question: "Do these products require a hub?",
    answer:
      "No extra hub required—connect directly to Wi-Fi and control everything via mobile app.",
  },
  {
    question: "What warranty do Halox products have?",
    answer:
      "Most Halox products come with a 1-year warranty. Check individual product description for details.",
  },
  {
    question: "Are Halox products made in India?",
    answer:
      "Yes, Halox products are proudly designed, manufactured, and supported in India.",
  },
  {
    question: "How do I install these smart home devices?",
    answer:
      "Installation is DIY-friendly: plug in, pair to the Halox app, and follow onscreen instructions.",
  },
  {
    question: "Is my data secure with Halox?",
    answer:
      "Halox uses ISO 27001 standards, strong encryption, and never shares data with third parties.",
  },
];

const carouselImages = [
  "/Banner/banner_1.jpg",
  "/Banneer/banner_2.jpg",
];


// Product Page Component
const ProductPage = () => {
  const [selectedProduct, setSelectedProduct] = useState(productList[0]);
  const [openAccordionItem, setOpenAccordionItem] = useState(null);
  const [currentSlide, setCurrentSlide] = useState(0);
  const productGridRef = useRef(null);

  const toggleAccordion = (idx) =>
    setOpenAccordionItem(openAccordionItem === idx ? null : idx);

  // Carousel navigation
  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % carouselImages.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) =>
      prev === 0 ? carouselImages.length - 1 : prev - 1
    );
  };

  // Auto-slide every 5 seconds
  useEffect(() => {
    const interval = setInterval(nextSlide, 5000);
    return () => clearInterval(interval);
  }, []);

  // Scroll to product grid
  const scrollToProducts = () => {
    productGridRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  // Redirect to contact page
  const redirectToContact = () => {
    window.location.href = "/contact";
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main>
        {/* Hero with Carousel */}
        <section className="relative min-h-[60vh] flex flex-col items-center justify-center px-4 pt-16 overflow-hidden">
          <div className="absolute inset-0 w-full h-full">
            {carouselImages.map((img, index) => (
              <img
                key={index}
                src={img}
                alt={`Smart Home ${index + 1}`}
                className={`absolute inset-0 w-full h-full object-cover transition-opacity duration-1000 ${
                  currentSlide === index ? "opacity-100" : "opacity-0"
                }`}
              />
            ))}
            <div className="absolute inset-0 bg-black/50" /> {/* Overlay for text readability */}
          </div>
          {/* Navigation Arrows */}
          <button
            onClick={prevSlide}
            className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-white/80 text-teal-600 p-2 rounded-full hover:bg-white transition"
          >
            <ChevronLeft className="h-6 w-6" />
          </button>
          <button
            onClick={nextSlide}
            className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-white/80 text-teal-600 p-2 rounded-full hover:bg-white transition"
          >
            <ChevronRight className="h-6 w-6" />
          </button>
          <div className="relative z-10 text-center">
            <h1 className="text-6xl font-bold text-white mb-4">
              Halox Smart Products
            </h1>
            <p className="text-xl text-white/80 mb-8 max-w-2xl">
              Transform your home into a smart home with India's best automation
              solutions. Choose from 20 products and automate lights, appliances,
              curtains, security and more—centralized, secure, and effortless.
            </p>
            <div className="flex gap-4 mt-2 justify-center">
              <button
                onClick={scrollToProducts}
                className="bg-white text-teal-600 px-8 py-4 rounded-lg font-semibold shadow-lg transition-all"
              >
                Shop Now
              </button>
              <button
                onClick={redirectToContact}
                className="border border-white text-white px-8 py-4 rounded-lg font-semibold transition-all"
              >
                Contact Team
              </button>
            </div>
          </div>
        </section>

        {/* Product Grid */}
        <section className="py-24 bg-white" ref={productGridRef}>
          <div className="container mx-auto px-4">
            <h2 className="text-4xl font-bold mb-12 text-center text-purple-600 underline">
              Our Smart Home Products
            </h2>
            <hr /> <br />
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-10">
              {productList.map((prod, i) => (
                <div
                  key={prod.id}
                  className={`bg-gradient-to-br from-white to-gray-50 rounded-xl p-6 shadow-lg border border-gray-100 hover:shadow-2xl transition cursor-pointer group flex flex-col items-center ${
                    selectedProduct.id === prod.id &&
                    "border-teal-500 shadow-xl"
                  }`}
                  onClick={() => setSelectedProduct(prod)}
                >
                  <img
                    src={prod.image}
                    alt={prod.name}
                    className="rounded-xl h-40 w-40 object-cover mb-4 group-hover:scale-105 transition"
                  />
                  <h3 className="text-xl font-bold text-gray-900 mb-1 text-center">
                    {prod.name}
                  </h3>
                  <div className="text-teal-700 text-sm font-semibold mb-2">
                    {prod.tagline}
                  </div>
                  <div className="text-lg text-gray-800 font-bold my-1">
                    {prod.price}
                  </div>
                  <ul className="text-gray-600 text-xs mb-3 flex flex-col items-center gap-1">
                    {prod.highlights.map((hl, k) => (
                      <li key={k} className="flex items-center gap-1">
                        <CheckCircle className="h-4 w-4 text-teal-500" />
                        {hl}
                      </li>
                    ))}
                  </ul>
                  <Link to="/productOne">
                  <button className="bg-cyan-500 hover:bg-cyan-600 text-white px-4 py-2 rounded font-semibold mt-auto">
                    View Details
                  </button>
                  </Link>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Detailed Section for selected product */}
        <section className="py-24 bg-gray-50" key={selectedProduct.id}>
          <div className="container mx-auto px-4 max-w-3xl">
            <div className="flex gap-10 flex-col md:flex-row items-start">
              <img
                src={selectedProduct.image}
                alt={selectedProduct.name}
                className="rounded-2xl shadow-lg w-[320px] h-[320px] object-cover"
              />
              <div>
                <h2 className="text-4xl font-bold text-gray-900 mb-2">
                  {selectedProduct.name}
                </h2>
                <p className="text-xl text-teal-600 mb-4">
                  {selectedProduct.tagline}
                </p>
                <p className="mb-6 text-gray-600 font-semibold">
                  ₹{selectedProduct.price}
                </p>
                <ul className="mb-6">
                  {selectedProduct.highlights.map((hl, i) => (
                    <li
                      key={i}
                      className="flex items-center gap-2 text-gray-700"
                    >
                      <CheckCircle className="h-5 w-5 text-emerald-500" />
                      {hl}
                    </li>
                  ))}
                </ul>
                <table className="bg-white rounded-xl mb-6 w-full text-gray-700 shadow">
                  <tbody>
                    {Object.entries(selectedProduct.specs).map(([k, v], i) => (
                      <tr key={i}>
                        <td className="py-2 px-4 font-semibold">{k}</td>
                        <td className="py-2 px-4">{v}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                <button className="bg-cyan-500 hover:bg-cyan-700 text-white px-8 py-4 rounded-lg font-bold shadow-lg">
                  Buy Now
                </button>
              </div>
            </div>
          </div>
        </section>

        {/* FAQ */}
        <section className="py-24 bg-white">
          <div className="container mx-auto px-4 max-w-4xl">
            <h2 className="text-4xl font-bold text-gray-900 mb-8 text-center">
              FAQ: Halox Smart Products
            </h2>
            <div>
              {faqs.map((faq, idx) => (
                <div
                  key={idx}
                  className="border border-gray-200 rounded-lg mb-4"
                >
                  <button
                    onClick={() => toggleAccordion(idx)}
                    className="w-full px-6 py-4 text-left flex justify-between items-center hover:bg-gray-50 transition-colors"
                  >
                    <span className="font-semibold text-gray-900">
                      {faq.question}
                    </span>
                    <ChevronDown
                      className={`h-5 w-5 text-gray-500 transition-transform ${
                        openAccordionItem === idx && "rotate-180"
                      }`}
                    />
                  </button>
                  {openAccordionItem === idx && (
                    <div className="px-6 pb-4 text-gray-600">{faq.answer}</div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="py-24 bg-gradient-to-br from-teal-600 via-emerald-600 to-cyan-800 text-white">
          <div className="container mx-auto px-4 text-center">
            <div className="max-w-3xl mx-auto space-y-8">
              <h2 className="text-4xl md:text-5xl font-bold">
                Upgrade Your Home, Upgrade Your Life
              </h2>
              <p className="text-xl text-white/80">
                Halox brings India's widest smart home range—secure, stylish,
                and simple to control. Start today and experience true smart
                living.
              </p>
              <button className="bg-white text-teal-600 px-8 py-4 rounded-lg font-semibold shadow-lg transition-all inline-flex items-center justify-center">
                <Plug className="mr-2 h-5 w-5" />
                Shop Halox Smart
              </button>
              <div className="flex flex-wrap justify-center items-center gap-8 pt-8 opacity-80">
                <div className="flex items-center gap-2">
                  <Shield className="h-5 w-5" />
                  <span>ISO 27001 Certified</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-5 w-5" />
                  <span>Data Encrypted</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-5 w-5" />
                  <span>1 Year Warranty</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-5 w-5" />
                  <span>Made in India</span>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main> 
      <Footer />
    </div>
  );
};

export default ProductPage;