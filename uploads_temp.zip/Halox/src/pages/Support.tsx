import { useState } from "react";
import {
  Mail,
  Phone,
  MessageSquare,
  HelpCircle,
  Clock,
  CheckCircle,
  Send,
  Users,
  Award,
  Globe,
  Download,
} from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import {
  Accordion,
  AccordionItem,
  AccordionTrigger,
  AccordionContent,
} from "@/components/ui/accordion";
import { Helmet } from "react-helmet-async";

const Support = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: "",
  });

  const faqs = [
    {
      question: "How do I contact Halox Smart support?",
      answer:
        "You can reach us via email at support@haloxsmart.com, call our 24/7 helpline at +91-1800-123-4567, or use the live chat feature in the Halox Smart app.",
    },
    {
      question: "What are the support hours?",
      answer:
        "Our support team is available 24/7. You can contact us anytime via phone, email, or live chat for immediate assistance.",
    },
    {
      question: "How do I troubleshoot a device connection issue?",
      answer:
        "Ensure your device is powered on and within Wi-Fi range. Use the 'Add Device' feature in the app to reconnect. If issues persist, check our troubleshooting guide in the app or contact support.",
    },
    {
      question: "Can I get help setting up my smart devices?",
      answer:
        "Yes! Our app includes step-by-step setup guides, and our support team can assist via live chat or phone for personalized help.",
    },
    {
      question: "Is there a community forum for Halox Smart users?",
      answer:
        "Yes, join our community forum at community.haloxsmart.com to share tips, ask questions, and connect with other Halox Smart users.",
    },
  ];

  const faqLd = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: faqs.map((f) => ({
      "@type": "Question",
      name: f.question,
      acceptedAnswer: { "@type": "Answer", text: f.answer },
    })),
  };

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.MouseEvent<HTMLButtonElement>) => {
    e.preventDefault();
    // Handle form submission logic here (e.g., send to API)
    console.log("Form submitted:", formData);
    setFormData({ name: "", email: "", message: "" });
  };

  const canonical =
    typeof window !== "undefined"
      ? `${window.location.origin}/support`
      : "/support";

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Halox Smart Support | 24/7 Assistance for Your Smart Home</title>
        <meta
          name="description"
          content="Get 24/7 support for Halox Smart app and devices. Contact us via phone, email, or live chat for quick and reliable assistance."
        />
        <link rel="canonical" href={canonical} />
        <script type="application/ld+json">{JSON.stringify(faqLd)}</script>
      </Helmet>

      <Header />
      
      <main>
        {/* Hero Section */}
        <section className="relative min-h-[80vh] flex items-center justify-center overflow-hidden bg-gradient-to-br from-blue-600 via-indigo-600 to-purple-600">
          <div className="absolute inset-0 opacity-10">
            <div className="absolute inset-0 bg-white/5 bg-[radial-gradient(circle_at_1px_1px,rgba(255,255,255,0.15)_1px,transparent_0)] bg-[length:20px_20px] animate-pulse"></div>
          </div>
          <div className="container mx-auto px-4 relative z-10">
            <div className="text-center space-y-8">
              <div className="inline-flex items-center bg-white/20 text-white border border-white/30 backdrop-blur-sm rounded-full px-4 py-2">
                <HelpCircle className="h-4 w-4 mr-2" />
                24/7 Support
              </div>
              <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold text-white leading-tight">
                We're Here to Help
                <span className="block text-orange-300">Anytime, Anywhere</span>
              </h1>
              <p className="text-lg md:text-xl text-white/80 max-w-3xl mx-auto">
                Our dedicated support team is available 24/7 to assist with your
                Halox Smart app and devices. Reach out via phone, email, or live
                chat.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <button className="bg-orange-500 hover:bg-orange-600 text-white px-8 py-4 rounded-lg font-semibold shadow-lg transition-all flex items-center justify-center">
                  <Phone className="mr-2 h-5 w-5" />
                  Call Support
                </button>
                <button className="border border-white text-white hover:bg-white hover:text-blue-600 px-8 py-4 rounded-lg font-semibold transition-all flex items-center justify-center">
                  <MessageSquare className="mr-2 h-5 w-5" />
                  Live Chat
                </button>
              </div>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mt-16 pt-8 border-t border-white/20">
              {[
                {
                  label: "Support Tickets",
                  value: "10K+",
                  icon: MessageSquare,
                },
                { label: "Resolution Time", value: "< 5 min", icon: Clock },
                { label: "Customer Satisfaction", value: "98%", icon: Award },
                { label: "Support Channels", value: "4+", icon: Globe },
              ].map((stat) => (
                <div key={stat.label} className="text-center text-white">
                  <stat.icon className="h-6 w-6 mx-auto mb-2 text-orange-300" />
                  <div className="text-2xl font-bold">{stat.value}</div>
                  <div className="text-sm text-white/60">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Contact Options Section */}
        <section className="py-24 bg-white">
          <div className="container mx-auto px-4">
            <div className="text-center mb-16">
              <div className="inline-block mb-4 bg-blue-100 text-blue-600 px-4 py-2 rounded-full text-sm font-medium">
                Contact Us
              </div>
              <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
                Multiple Ways to Reach Us
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Choose the method that works best for you. Our team is ready to
                assist with any questions or issues.
              </p>
            </div>
            <div className="grid md:grid-cols-3 gap-8">
              {[
                {
                  icon: Phone,
                  title: "Phone Support",
                  description:
                    "Speak directly with our support team 24/7 at +91-1800-123-4567.",
                  color: "from-blue-400 to-blue-600",
                  bgColor: "from-blue-50 to-blue-100",
                  action: "Call Now",
                },
                {
                  icon: Mail,
                  title: "Email Support",
                  description:
                    "Send us an email at support@haloxsmart.com and get a response within hours.",
                  color: "from-green-400 to-green-600",
                  bgColor: "from-green-50 to-green-100",
                  action: "Email Us",
                },
                {
                  icon: MessageSquare,
                  title: "Live Chat",
                  description:
                    "Chat with our team directly through the Halox Smart app for instant help.",
                  color: "from-purple-400 to-purple-600",
                  bgColor: "from-purple-50 to-purple-100",
                  action: "Start Chat",
                },
              ].map((option) => (
                <div
                  key={option.title}
                  className="group bg-gradient-to-br from-white to-gray-50 rounded-3xl p-8 border border-gray-100 hover:border-transparent hover:shadow-2xl transition-all duration-500 hover:transform hover:-translate-y-2 cursor-pointer relative overflow-hidden"
                >
                  <div
                    className={`absolute inset-0 bg-gradient-to-br ${option.bgColor} opacity-0 group-hover:opacity-100 transition-opacity duration-500`}
                  ></div>
                  <div
                    className={`w-16 h-16 rounded-2xl flex items-center justify-center mb-6 shadow-lg group-hover:shadow-xl transition-all duration-300 group-hover:scale-110 relative z-10 bg-gradient-to-br ${option.color}`}
                  >
                    <option.icon className="h-8 w-8 text-white transition-transform duration-300 group-hover:scale-110" />
                    <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-white/20 to-transparent"></div>
                  </div>
                  <div className="relative z-10">
                    <h3 className="text-2xl font-bold text-gray-900 mb-4 group-hover:text-blue-700 transition-colors duration-300">
                      {option.title}
                    </h3>
                    <p className="text-gray-600 mb-4 leading-relaxed group-hover:text-gray-700 transition-colors duration-300">
                      {option.description}
                    </p>
                    <button className="inline-flex items-center gap-2 text-sm font-semibold px-4 py-2 bg-blue-50 text-blue-600 rounded-full group-hover:bg-blue-100 transition-all duration-300">
                      <div className="w-2 h-2 bg-blue-400 rounded-full animate-pulse"></div>
                      {option.action}
                    </button>
                  </div>
                  <div
                    className={`absolute top-0 right-0 w-24 h-24 bg-gradient-to-br ${option.color} opacity-10 rounded-full transform translate-x-8 -translate-y-8 group-hover:scale-150 transition-transform duration-500`}
                  ></div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Contact Form Section */}
        <section className="py-24 bg-gray-50">
          <div className="container mx-auto px-4 max-w-3xl">
            <div className="text-center mb-16">
              <div className="inline-block mb-4 bg-orange-100 text-orange-600 px-4 py-2 rounded-full text-sm font-medium">
                Get in Touch
              </div>
              <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
                Send Us a Message
              </h2>
              <p className="text-xl text-gray-600">
                Have a question or need help? Drop us a message, and we'll get
                back to you quickly.
              </p>
            </div>
            <div className="bg-white rounded-3xl p-8 shadow-lg border border-gray-100">
              <div className="space-y-6">
                <div>
                  <label
                    htmlFor="name"
                    className="block text-sm font-medium text-gray-700 mb-2"
                  >
                    Name
                  </label>
                  <input
                    type="text"
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                    placeholder="Your Name"
                  />
                </div>
                <div>
                  <label
                    htmlFor="email"
                    className="block text-sm font-medium text-gray-700 mb-2"
                  >
                    Email
                  </label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                    placeholder="Your Email"
                  />
                </div>
                <div>
                  <label
                    htmlFor="message"
                    className="block text-sm font-medium text-gray-700 mb-2"
                  >
                    Message
                  </label>
                  <textarea
                    id="message"
                    name="message"
                    value={formData.message}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all h-32"
                    placeholder="How can we help you?"
                  ></textarea>
                </div>
                <button
                  onClick={handleSubmit}
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 rounded-lg font-semibold transition-all flex items-center justify-center"
                >
                  <Send className="mr-2 h-5 w-5" />
                  Send Message
                </button>
              </div>
            </div>
          </div>
        </section>

        {/* FAQ Section */}
        <section className="py-24 bg-white">
          <div className="container mx-auto px-4 max-w-4xl">
            <div className="text-center mb-16">
              <div className="inline-block mb-4 bg-indigo-100 text-indigo-600 px-4 py-2 rounded-full text-sm font-medium">
                FAQ
              </div>
              <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
                Frequently Asked Questions
              </h2>
              <p className="text-xl text-gray-600">
                Find answers to common questions about Halox Smart support.
              </p>
            </div>
            <Accordion type="single" collapsible className="w-full">
              {faqs.map((faq, index) => (
                <AccordionItem key={index} value={`item-${index}`}>
                  <AccordionTrigger>{faq.question}</AccordionTrigger>
                  <AccordionContent>{faq.answer}</AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-24 bg-gradient-to-br from-blue-600 via-purple-600 to-blue-800 text-white">
          <div className="container mx-auto px-4 text-center">
            <div className="max-w-3xl mx-auto space-y-8">
              <h2 className="text-4xl md:text-5xl font-bold">Need Help Now?</h2>
              <p className="text-xl text-white/80">
                Our team is standing by to assist you with any Halox Smart app
                or device issues. Contact us today for fast, reliable support.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <button className="bg-white text-blue-600 hover:bg-gray-100 px-8 py-4 rounded-lg font-semibold shadow-lg transition-all inline-flex items-center justify-center">
                  <Download className="mr-2 h-5 w-5" />
                  Download App
                </button>
                <button className="border border-white text-white hover:bg-white hover:text-blue-600 px-8 py-4 rounded-lg font-semibold transition-all inline-flex items-center justify-center">
                  <MessageSquare className="mr-2 h-5 w-5" />
                  Start Live Chat
                </button>
              </div>
              <div className="flex flex-wrap justify-center items-center gap-8 pt-8 opacity-80">
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-5 w-5" />
                  <span>24/7 Support</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-5 w-5" />
                  <span>Free Assistance</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-5 w-5" />
                  <span>Multiple Channels</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-5 w-5" />
                  <span>Fast Response</span>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default Support;
