import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Trash2, ShoppingBag, ChevronRight, X, Plus, Minus, Bookmark, ShoppingCart, 
  Heart, Gift, Truck, Shield, Star, ArrowRight, Package, CreditCard,
  Percent, Clock, MapPin, Phone, Mail, Headphones
} from "lucide-react";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { Header } from "@radix-ui/react-accordion";

const Cart = () => {
  const [cartItems, setCartItems] = useState([
    {
      id: 1,
      name: "Smart WiFi Plug Pro",
      price: 1299,
      quantity: 2,
      category: "smart plugs",
      image: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=400&h=300&fit=crop",
      features: ["Voice Control", "Remote Access", "Energy Monitoring"],
      rating: 4.8,
      reviews: 342,
      inStock: true,
      originalPrice: 1599
    },
    {
      id: 2,
      name: "Premium Touch Switch",
      price: 2499,
      quantity: 1,
      category: "switches",
      image: "https://images.unsplash.com/photo-1621905251189-08b45d6a269e?w=400&h=300&fit=crop",
      features: ["Capacitive Touch", "LED Indicator", "Modern Design"],
      rating: 4.9,
      reviews: 156,
      inStock: true,
      originalPrice: 2999
    }
  ]);
  
  const [savedItems, setSavedItems] = useState([
    {
      id: 3,
      name: "RGB LED Strip Light",
      price: 899,
      quantity: 1,
      category: "lighting",
      image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=300&fit=crop",
      features: ["16 Million Colors", "Music Sync", "App Control"],
      rating: 4.6,
      reviews: 89,
      inStock: true,
      originalPrice: 1199
    }
  ]);

  const [promoCode, setPromoCode] = useState("");
  const [appliedPromo, setAppliedPromo] = useState(null);
  const [showPromoInput, setShowPromoInput] = useState(false);

  // Calculate prices
  const cartCount = cartItems.reduce((sum, item) => sum + item.quantity, 0);
  const subtotal = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const originalSubtotal = cartItems.reduce((sum, item) => sum + (item.originalPrice || item.price) * item.quantity, 0);
  const savings = originalSubtotal - subtotal;
  const tax = subtotal * 0.18;
  const shipping = subtotal > 2000 ? 0 : 99;
  const promoDiscount = appliedPromo ? subtotal * (appliedPromo.discount / 100) : 0;
  const totalPrice = subtotal + tax + shipping - promoDiscount;

  const updateQuantity = (id, newQuantity) => {
    if (newQuantity < 1) return;
    const updatedCart = cartItems.map(item =>
      item.id === id ? { ...item, quantity: newQuantity } : item
    );
    setCartItems(updatedCart);
  };

  const removeItem = (id) => {
    const updatedCart = cartItems.filter(item => item.id !== id);
    setCartItems(updatedCart);
  };

  const removeSavedItem = (id) => {
    const updatedSaved = savedItems.filter(item => item.id !== id);
    setSavedItems(updatedSaved);
  };

  const clearCart = () => {
    setCartItems([]);
  };

  const saveForLater = (id) => {
    const itemToSave = cartItems.find(item => item.id === id);
    if (itemToSave && !savedItems.find(saved => saved.id === id)) {
      const updatedCart = cartItems.filter(item => item.id !== id);
      const updatedSaved = [...savedItems, { ...itemToSave, quantity: 1 }];
      setCartItems(updatedCart);
      setSavedItems(updatedSaved);
    }
  };

  const moveToCart = (id) => {
    const itemToMove = savedItems.find(item => item.id === id);
    if (itemToMove && !cartItems.find(cart => cart.id === id)) {
      const updatedSaved = savedItems.filter(item => item.id !== id);
      const updatedCart = [...cartItems, { ...itemToMove, quantity: 1 }];
      setSavedItems(updatedSaved);
      setCartItems(updatedCart);
    }
  };

  const applyPromoCode = () => {
    const validCodes = {
      "SMART20": { discount: 20, description: "20% off smart devices" },
      "NEW10": { discount: 10, description: "10% off for new customers" },
      "SAVE15": { discount: 15, description: "15% instant savings" }
    };

    if (validCodes[promoCode]) {
      setAppliedPromo(validCodes[promoCode]);
      setShowPromoInput(false);
      setPromoCode("");
    }
  };

  const removePromoCode = () => {
    setAppliedPromo(null);
    setPromoCode("");
  };

  const renderEmptyCart = () => (
    <div className="text-center py-20 space-y-10">
      <div className="relative">
        <div className="w-32 h-32 mx-auto bg-gradient-to-br from-green-100 to-green-200 rounded-full flex items-center justify-center mb-8 animate-float">
          <ShoppingBag className="h-16 w-16 text-green-600" />
        </div>
        <div className="absolute -top-2 -right-2 w-8 h-8 bg-red-500 rounded-full flex items-center justify-center animate-bounce">
          <span className="text-white text-sm font-bold">0</span>
        </div>
      </div>
      
      <div className="space-y-4">
        <h2 className="text-4xl font-bold text-gray-900 animate-fade-in-up">Your Cart is Empty</h2>
        <p className="text-xl text-gray-600 max-w-lg mx-auto leading-relaxed">
          Discover amazing smart home devices that will transform your living space into a connected paradise!
        </p>
      </div>

      <div className="flex flex-col sm:flex-row justify-center gap-4 animate-fade-in-up-delay">
        <Button
          size="lg"
          className="bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 text-white font-semibold px-8 py-4 rounded-xl shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-300"
        >
          <ShoppingBag className="h-5 w-5 mr-2" />
          Start Shopping
        </Button>
        <Button
          variant="outline"
          size="lg"
          className="border-2 border-green-200 text-green-600 hover:bg-green-50 px-8 py-4 rounded-xl hover:border-green-300 transition-all duration-300"
        >
          Browse Categories
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-16 animate-fade-in-up-delay-2">
        {[
          { icon: Truck, title: "Free Shipping", desc: "On orders above ₹2000" },
          { icon: Shield, title: "Secure Payment", desc: "100% protected checkout" },
          { icon: Headphones, title: "24/7 Support", desc: "Always here to help" }
        ].map((feature, index) => (
          <Card key={index} className="text-center p-6 border-0 bg-white/80 backdrop-blur-sm hover:bg-white transition-all duration-300">
            <feature.icon className="h-12 w-12 text-green-600 mx-auto mb-4" />
            <h3 className="font-semibold text-gray-900 mb-2">{feature.title}</h3>
            <p className="text-sm text-gray-600">{feature.desc}</p>
          </Card>
        ))}
      </div>
    </div>
  );

  const renderCartItems = () => (
    <div className="space-y-8 lg:flex lg:gap-10">
      {/* Cart Items List */}
      <div className="flex-1 space-y-6">
        <div className="flex justify-between items-center">
          <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
            <ShoppingCart className="h-8 w-8 text-green-600" />
            Shopping Cart ({cartCount} items)
          </h1>
          <Button
            variant="outline"
            className="text-red-500 border-red-200 hover:bg-red-50 hover:border-red-300 transition-all duration-300"
            onClick={clearCart}
          >
            <Trash2 className="h-4 w-4 mr-2" />
            Clear All
          </Button>
        </div>

        <div className="space-y-4">
          {cartItems.map((item, index) => (
            <Card
              key={item.id}
              className="overflow-hidden border border-gray-200/60 hover:border-green-300/60 hover:shadow-xl transition-all duration-500 bg-white/90 backdrop-blur-sm animate-slide-in-right"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <CardContent className="p-6">
                <div className="flex flex-col sm:flex-row gap-6">
                  {/* Product Image */}
                  <div className="relative group">
                    <img
                      src={item.image}
                      alt={item.name}
                      className="w-full sm:w-32 h-32 object-cover rounded-xl group-hover:scale-105 transition-transform duration-300"
                    />
                    {item.originalPrice > item.price && (
                      <Badge className="absolute -top-2 -right-2 bg-red-500 text-white animate-pulse">
                        SALE
                      </Badge>
                    )}
                  </div>

                  {/* Product Info */}
                  <div className="flex-1 space-y-4">
                    <div className="flex justify-between items-start">
                      <div className="space-y-2">
                        <h3 className="text-xl font-bold text-gray-900 hover:text-green-600 transition-colors">
                          {item.name}
                        </h3>
                        <div className="flex items-center gap-2">
                          <div className="flex items-center gap-1">
                            {[...Array(5)].map((_, i) => (
                              <Star
                                key={i}
                                className={`h-4 w-4 ${i < Math.floor(item.rating) ? 'text-yellow-400 fill-current' : 'text-gray-300'}`}
                              />
                            ))}
                            <span className="text-sm font-medium text-gray-700 ml-1">{item.rating}</span>
                            <span className="text-sm text-gray-500">({item.reviews} reviews)</span>
                          </div>
                        </div>
                        <div className="flex flex-wrap gap-2">
                          {item.features.map((feature, idx) => (
                            <Badge key={idx} variant="secondary" className="bg-green-100 text-green-700 hover:bg-green-200 transition-colors">
                              {feature}
                            </Badge>
                          ))}
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge className={`${item.inStock ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                            {item.inStock ? '✓ In Stock' : '⚠ Out of Stock'}
                          </Badge>
                        </div>
                      </div>

                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => removeItem(item.id)}
                        className="text-red-500 hover:text-red-600 hover:bg-red-50 rounded-full transition-all duration-300 hover:scale-110"
                      >
                        <Trash2 className="h-5 w-5" />
                      </Button>
                    </div>

                    {/* Price and Quantity Controls */}
                    <div className="flex flex-col sm:flex-row justify-between items-start sm:items-end gap-4">
                      <div className="space-y-2">
                        <div className="flex items-center gap-3">
                          <span className="text-2xl font-bold text-green-600">₹{item.price.toLocaleString()}</span>
                          {item.originalPrice > item.price && (
                            <span className="text-lg text-gray-400 line-through">₹{item.originalPrice.toLocaleString()}</span>
                          )}
                          {item.originalPrice > item.price && (
                            <Badge className="bg-green-500 text-white">
                              Save ₹{(item.originalPrice - item.price).toLocaleString()}
                            </Badge>
                          )}
                        </div>
                        <p className="text-lg font-semibold text-gray-900">
                          Subtotal: ₹{(item.price * item.quantity).toLocaleString()}
                        </p>
                      </div>

                      <div className="flex items-center gap-4">
                        {/* Quantity Controls */}
                        <div className="flex items-center gap-2 bg-gray-50 rounded-xl p-1">
                          <Button
                            size="icon"
                            variant="ghost"
                            onClick={() => updateQuantity(item.id, item.quantity - 1)}
                            disabled={item.quantity <= 1}
                            className="h-10 w-10 hover:bg-green-100 text-green-600 rounded-lg transition-all duration-300"
                          >
                            <Minus className="h-4 w-4" />
                          </Button>
                          <span className="text-lg font-bold text-gray-900 min-w-[3rem] text-center">
                            {item.quantity}
                          </span>
                          <Button
                            size="icon"
                            variant="ghost"
                            onClick={() => updateQuantity(item.id, item.quantity + 1)}
                            className="h-10 w-10 hover:bg-green-100 text-green-600 rounded-lg transition-all duration-300"
                          >
                            <Plus className="h-4 w-4" />
                          </Button>
                        </div>

                        {/* Action Buttons */}
                        <div className="flex gap-2">
                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <Button
                                  variant="outline"
                                  size="icon"
                                  onClick={() => saveForLater(item.id)}
                                  className="text-blue-500 hover:text-blue-600 hover:bg-blue-50 border-blue-200 rounded-lg transition-all duration-300 hover:scale-110"
                                >
                                  <Bookmark className="h-5 w-5" />
                                </Button>
                              </TooltipTrigger>
                              <TooltipContent>Save for later</TooltipContent>
                            </Tooltip>
                          </TooltipProvider>

                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <Button
                                  variant="outline"
                                  size="icon"
                                  className="text-pink-500 hover:text-pink-600 hover:bg-pink-50 border-pink-200 rounded-lg transition-all duration-300 hover:scale-110"
                                >
                                  <Heart className="h-5 w-5" />
                                </Button>
                              </TooltipTrigger>
                              <TooltipContent>Add to wishlist</TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Recommended Products */}
        <Card className="border border-green-200/50 bg-gradient-to-r from-green-50/30 to-blue-50/30 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="text-xl text-gray-900 flex items-center gap-2">
              <Gift className="h-6 w-6 text-green-600" />
              People also bought
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {[
                { name: "Smart Door Lock", price: 4999, image: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=200&h=150&fit=crop" },
                { name: "Motion Sensor", price: 799, image: "https://images.unsplash.com/photo-1621905251189-08b45d6a269e?w=200&h=150&fit=crop" },
                { name: "Smart Thermostat", price: 3299, image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&h=150&fit=crop" }
              ].map((product, idx) => (
                <Card key={idx} className="group hover:shadow-lg transition-all duration-300 cursor-pointer bg-white/80">
                  <CardContent className="p-4 space-y-3">
                    <img src={product.image} alt={product.name} className="w-full h-24 object-cover rounded-lg group-hover:scale-105 transition-transform duration-300" />
                    <h4 className="font-semibold text-sm text-gray-900">{product.name}</h4>
                    <div className="flex justify-between items-center">
                      <span className="text-green-600 font-bold">₹{product.price.toLocaleString()}</span>
                      <Button size="sm" className="bg-green-600 hover:bg-green-700 text-white rounded-lg">
                        <Plus className="h-3 w-3" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {renderOrderSummary()}
    </div>
  );

  const renderOrderSummary = () => (
    <Card className="border border-green-200/50 shadow-2xl bg-white/95 backdrop-blur-sm lg:sticky lg:top-8 lg:self-start lg:w-96 animate-slide-in-left">
      <CardHeader className="bg-gradient-to-r from-green-600 to-green-700 text-white rounded-t-lg">
        <CardTitle className="text-2xl flex items-center gap-2">
          <Package className="h-6 w-6" />
          Order Summary
        </CardTitle>
      </CardHeader>
      
      <CardContent className="p-6 space-y-6">
        {/* Price Breakdown */}
        <div className="space-y-4">
          <div className="flex justify-between text-gray-600">
            <span>Subtotal ({cartCount} items)</span>
            <span>₹{subtotal.toLocaleString()}</span>
          </div>
          
          {savings > 0 && (
            <div className="flex justify-between text-green-600 font-medium">
              <span>You Save</span>
              <span>-₹{savings.toLocaleString()}</span>
            </div>
          )}

          <div className="flex justify-between text-gray-600">
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <span className="cursor-help border-b border-dashed border-gray-400">GST (18%)</span>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Goods and Services Tax at 18%</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
            <span>₹{tax.toLocaleString()}</span>
          </div>

          <div className="flex justify-between text-gray-600">
            <div className="flex items-center gap-1">
              <Truck className="h-4 w-4" />
              <span>Shipping</span>
            </div>
            <span className={shipping === 0 ? "text-green-600 font-medium" : ""}>
              {shipping === 0 ? "FREE" : `₹${shipping}`}
            </span>
          </div>

          {/* Promo Code Section */}
          <div className="border-t border-gray-200 pt-4">
            {appliedPromo ? (
              <div className="flex justify-between items-center text-green-600 font-medium bg-green-50 p-3 rounded-lg">
                <div className="flex items-center gap-2">
                  <Percent className="h-4 w-4" />
                  <span>{appliedPromo.description}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span>-₹{promoDiscount.toLocaleString()}</span>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={removePromoCode}
                    className="h-6 w-6 text-red-500 hover:bg-red-100"
                  >
                    <X className="h-3 w-3" />
                  </Button>
                </div>
              </div>
            ) : (
              <div className="space-y-3">
                {showPromoInput ? (
                  <div className="flex gap-2">
                    <input
                      type="text"
                      placeholder="Enter promo code"
                      value={promoCode}
                      onChange={(e) => setPromoCode(e.target.value.toUpperCase())}
                      className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 outline-none transition-all duration-300"
                    />
                    <Button
                      onClick={applyPromoCode}
                      disabled={!promoCode}
                      className="bg-green-600 hover:bg-green-700 text-white px-4 rounded-lg"
                    >
                      Apply
                    </Button>
                  </div>
                ) : (
                  <Button
                    variant="outline"
                    onClick={() => setShowPromoInput(true)}
                    className="w-full border-green-200 text-green-600 hover:bg-green-50 rounded-lg"
                  >
                    <Percent className="h-4 w-4 mr-2" />
                    Have a promo code?
                  </Button>
                )}
                <p className="text-xs text-gray-500">Try: SMART20, NEW10, SAVE15</p>
              </div>
            )}
          </div>

          {/* Total */}
          <div className="border-t border-gray-200 pt-4">
            <div className="flex justify-between text-gray-900 font-bold text-2xl">
              <span>Total</span>
              <span className="text-green-600">₹{totalPrice.toLocaleString()}</span>
            </div>
          </div>
        </div>

        {/* Delivery Info */}
        <div className="bg-blue-50 p-4 rounded-lg space-y-2">
          <div className="flex items-center gap-2 text-blue-700">
            <Clock className="h-4 w-4" />
            <span className="font-medium">Estimated Delivery</span>
          </div>
          <p className="text-blue-600 font-semibold">Aug 22 - Aug 25, 2025</p>
          <div className="flex items-center gap-2 text-blue-600 text-sm">
            <MapPin className="h-3 w-3" />
            <span>Delivering to Dadri, Uttar Pradesh</span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="space-y-3">
          <Button
            size="lg"
            className="w-full bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 text-white font-bold py-4 rounded-xl shadow-lg hover:shadow-xl transform hover:scale-[1.02] transition-all duration-300"
          >
            <CreditCard className="h-5 w-5 mr-2" />
            Proceed to Checkout
            <ArrowRight className="h-5 w-5 ml-2" />
          </Button>
          
          <div className="grid grid-cols-2 gap-3">
            <Button
              variant="outline"
              size="lg"
              className="border-2 border-green-200 text-green-600 hover:bg-green-50 font-semibold rounded-xl transition-all duration-300"
            >
              Continue Shopping
            </Button>
            <Button
              variant="outline"
              size="lg"
              className="border-2 border-blue-200 text-blue-600 hover:bg-blue-50 font-semibold rounded-xl transition-all duration-300"
            >
              <Gift className="h-4 w-4 mr-2" />
              Gift This
            </Button>
          </div>
        </div>

        {/* Trust Badges */}
        <div className="grid grid-cols-2 gap-3 pt-4 border-t border-gray-200">
          <div className="flex items-center gap-2 text-sm text-gray-600">
            <Shield className="h-4 w-4 text-green-600" />
            <span>Secure Checkout</span>
          </div>
          <div className="flex items-center gap-2 text-sm text-gray-600">
            <Truck className="h-4 w-4 text-green-600" />
            <span>Fast Delivery</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );

  const renderSavedItems = () => (
    savedItems.length > 0 && (
      <div className="mt-16 animate-fade-in-up">
        <div className="flex justify-between items-center mb-8">
          <h2 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
            <Bookmark className="h-8 w-8 text-blue-600" />
            Saved for Later
            <Badge className="bg-blue-100 text-blue-700">{savedItems.length}</Badge>
          </h2>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {savedItems.map((item, index) => (
            <Card 
              key={item.id} 
              className="group overflow-hidden border border-gray-200/50 hover:border-blue-300/60 hover:shadow-xl transition-all duration-500 bg-white/90 backdrop-blur-sm animate-slide-in-up"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <CardHeader className="p-0 relative">
                <img
                  src={item.image}
                  alt={item.name}
                  className="w-full h-40 object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute top-2 right-2 bg-white/90 backdrop-blur-sm rounded-full p-1">
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8 text-red-500 hover:bg-red-50 rounded-full"
                    onClick={() => removeSavedItem(item.id)}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              </CardHeader>
              
              <CardContent className="p-4 space-y-3">
                <div>
                  <CardTitle className="text-lg font-bold text-gray-900 line-clamp-2 group-hover:text-blue-600 transition-colors">
                    {item.name}
                  </CardTitle>
                  <div className="flex items-center gap-1 mt-1">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={`h-3 w-3 ${i < Math.floor(item.rating) ? 'text-yellow-400 fill-current' : 'text-gray-300'}`}
                      />
                    ))}
                    <span className="text-xs text-gray-500 ml-1">({item.reviews})</span>
                  </div>
                </div>
                
                <div className="flex items-center gap-2">
                  <span className="text-lg font-bold text-green-600">₹{item.price.toLocaleString()}</span>
                  {item.originalPrice > item.price && (
                    <span className="text-sm text-gray-400 line-through">₹{item.originalPrice.toLocaleString()}</span>
                  )}
                </div>
                
                <Button
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-lg transition-all duration-300 hover:shadow-lg"
                  onClick={() => moveToCart(item.id)}
                >
                  <ShoppingCart className="h-4 w-4 mr-2" />
                  Move to Cart
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    )
  );

  const renderTrustSection = () => (
    <div className="mt-16 bg-gradient-to-r from-gray-50 to-green-50/30 p-8 rounded-2xl animate-fade-in-up">
      <h2 className="text-2xl font-bold text-center text-gray-900 mb-8">Why Shop With Us?</h2>
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {[
          { icon: Truck, title: "Free Shipping", desc: "On orders above ₹2000", color: "green" },
          { icon: Shield, title: "Secure Payment", desc: "256-bit SSL encryption", color: "blue" },
          { icon: Headphones, title: "24/7 Support", desc: "Expert help anytime", color: "purple" },
          { icon: Package, title: "Easy Returns", desc: "30-day return policy", color: "orange" }
        ].map((feature, index) => (
          <Card key={index} className="text-center p-6 border-0 bg-white/80 backdrop-blur-sm hover:bg-white hover:shadow-lg transition-all duration-300 group">
            <div className={`w-16 h-16 mx-auto mb-4 rounded-full bg-${feature.color}-100 flex items-center justify-center group-hover:scale-110 transition-transform duration-300`}>
              <feature.icon className={`h-8 w-8 text-${feature.color}-600`} />
            </div>
            <h3 className="font-bold text-gray-900 mb-2">{feature.title}</h3>
            <p className="text-sm text-gray-600">{feature.desc}</p>
          </Card>
        ))}
      </div>
    </div>
  );

  const renderContactSection = () => (
    <div className="mt-12 bg-white p-6 rounded-xl border border-gray-200 shadow-sm">
      <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center gap-2">
        <Headphones className="h-5 w-5 text-green-600" />
        Need Help?
      </h3>
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Button variant="outline" className="flex items-center gap-2 hover:bg-green-50 transition-colors">
          <Phone className="h-4 w-4" />
          Call Us
        </Button>
        <Button variant="outline" className="flex items-center gap-2 hover:bg-blue-50 transition-colors">
          <Mail className="h-4 w-4" />
          Email Support
        </Button>
        <Button variant="outline" className="flex items-center gap-2 hover:bg-purple-50 transition-colors">
          <Headphones className="h-4 w-4" />
          Live Chat
        </Button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-green-50/20 to-blue-50/20 font-sans">
 

      <main className="container mx-auto px-6 py-10">
        {/* Enhanced Breadcrumb */}
        <div className="flex items-center gap-2 text-sm text-gray-500 mb-10 animate-fade-in">
          <span className="hover:text-green-600 transition-colors cursor-pointer">Home</span>
          <ChevronRight className="h-4 w-4" />
          <span className="hover:text-green-600 transition-colors cursor-pointer">Shop</span>
          <ChevronRight className="h-4 w-4" />
          <span className="text-gray-900 font-medium">Cart</span>
        </div>

        {/* Main Cart Content */}
        <div className="relative">
          {cartItems.length === 0 ? renderEmptyCart() : renderCartItems()}
        </div>

        {/* Saved Items Section */}
        {renderSavedItems()}

        {/* Trust Section */}
        {renderTrustSection()}

        {/* Contact Section */}
        {renderContactSection()}
      </main>

    

      {/* Custom Styles */}
      <style>{`
        @keyframes float {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-10px); }
        }
        @keyframes slide-in-right {
          0% { transform: translateX(50px); opacity: 0; }
          100% { transform: translateX(0); opacity: 1; }
        }
        @keyframes slide-in-left {
          0% { transform: translateX(-50px); opacity: 0; }
          100% { transform: translateX(0); opacity: 1; }
        }
        @keyframes slide-in-up {
          0% { transform: translateY(30px); opacity: 0; }
          100% { transform: translateY(0); opacity: 1; }
        }
        @keyframes fade-in-up {
          0% { transform: translateY(20px); opacity: 0; }
          100% { transform: translateY(0); opacity: 1; }
        }
        @keyframes fade-in-up-delay {
          0% { transform: translateY(20px); opacity: 0; }
          100% { transform: translateY(0); opacity: 1; }
        }
        @keyframes fade-in-up-delay-2 {
          0% { transform: translateY(20px); opacity: 0; }
          100% { transform: translateY(0); opacity: 1; }
        }
        @keyframes fade-in {
          0% { opacity: 0; }
          100% { opacity: 1; }
        }

        .animate-float { animation: float 3s ease-in-out infinite; }
        .animate-slide-in-right { animation: slide-in-right 0.6s ease-out forwards; }
        .animate-slide-in-left { animation: slide-in-left 0.6s ease-out forwards; }
        .animate-slide-in-up { animation: slide-in-up 0.6s ease-out forwards; }
        .animate-fade-in-up { animation: fade-in-up 0.8s ease-out forwards; }
        .animate-fade-in-up-delay { animation: fade-in-up-delay 0.8s ease-out 0.2s forwards; opacity: 0; }
        .animate-fade-in-up-delay-2 { animation: fade-in-up-delay-2 0.8s ease-out 0.4s forwards; opacity: 0; }
        .animate-fade-in { animation: fade-in 0.6s ease-out forwards; }

        .line-clamp-1 {
          display: -webkit-box;
          -webkit-line-clamp: 1;
          -webkit-box-orient: vertical;
          overflow: hidden;
        }
        .line-clamp-2 {
          display: -webkit-box;
          -webkit-line-clamp: 2;
          -webkit-box-orient: vertical;
          overflow: hidden;
        }
      `}</style>
    </div>
  );
};

export default Cart;