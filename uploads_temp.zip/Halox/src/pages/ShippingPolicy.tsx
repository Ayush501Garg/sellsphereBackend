import { useState } from "react";
import {
  Mail,
  Truck,
  Package,
  MapPin,
  Clock,
  CheckCircle,
  ArrowRight,
} from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import {
  Accordion,
  AccordionItem,
  AccordionTrigger,
  AccordionContent,
} from "@/components/ui/accordion";
import { Helmet } from "react-helmet-async";
import { motion } from "framer-motion";

const ShippingPolicy = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: "",
  });

  const faqs = [
    {
      question: "Where does Halox ship?",
      answer:
        "Halox currently ships exclusively to addresses within India. International shipping is not available at this time.",
    },
    {
      question: "How are shipping fees calculated?",
      answer:
        "Shipping fees are determined based on the weight of the products in your order and the delivery address. Fees are displayed during the checkout process.",
    },
    {
      question: "How long does shipping take?",
      answer:
        "Orders are typically processed and shipped within 7-10 business days after payment confirmation. Delivery times vary based on the shipping address and method, with estimates provided at checkout.",
    },
    {
      question: "Can I change my shipping address after placing an order?",
      answer:
        "If you need to update your shipping address, please contact our customer service team at info@thelivsmart.com as soon as possible.",
    },
    {
      question: "What if my order cannot be shipped due to restrictions?",
      answer:
        "Some products may have shipping restrictions due to size, weight, or other factors. If an order cannot be shipped, we will cancel it and issue a full refund to the original payment method.",
    },
  ];

  const faqLd = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: faqs.map((f) => ({
      "@type": "Question",
      name: f.question,
      acceptedAnswer: { "@type": "Answer", text: f.answer },
    })),
  };

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.MouseEvent<HTMLButtonElement>) => {
    e.preventDefault();
    console.log("Form submitted:", formData);
    setFormData({ name: "", email: "", message: "" });
  };

  const canonical =
    typeof window !== "undefined"
      ? `${window.location.origin}/shipping-policy`
      : "/shipping-policy";

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Halox Shipping Policy | LivSmart Automation</title>
        <meta
          name="description"
          content="Learn about Halox's shipping policy, including shipping zones, methods, fees, and delivery timeframes. We ship exclusively within India."
        />
        <link rel="canonical" href={canonical} />
        <script type="application/ld+json">{JSON.stringify(faqLd)}</script>
      </Helmet>

      <Header />

      <main>
        {/* Hero Section */}
        <section className="relative min-h-[80vh] flex items-center justify-center overflow-hidden bg-gradient-to-br from-blue-700 via-teal-600 to-indigo-700">
          <div className="absolute inset-0 opacity-20">
            <div className="absolute inset-0 bg-white/10 bg-[radial-gradient(circle_at_1px_1px,rgba(255,255,255,0.25)_1px,transparent_0)] bg-[length:20px_20px] animate-pulse"></div>
          </div>
          <div className="container mx-auto px-4 relative z-10">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="text-center space-y-8"
            >
              <div className="inline-flex items-center bg-white/20 text-white border border-white/40 backdrop-blur-md rounded-full px-5 py-2">
                <Truck className="h-5 w-5 mr-2" />
                Shipping Policy
              </div>
              <h1 className="text-4xl md:text-6xl lg:text-7xl font-extrabold text-white leading-tight">
                Seamless Shipping with Halox
                <span className="block text-orange-300 mt-2">Across India</span>
              </h1>
              <p className="text-lg md:text-xl text-white/80 max-w-3xl mx-auto">
                Discover our shipping policies, designed to ensure your orders are delivered efficiently and reliably within India.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="bg-orange-500 hover:bg-orange-600 text-white px-8 py-4 rounded-xl font-semibold shadow-lg transition-all flex items-center justify-center"
                >
                  <Mail className="mr-2 h-5 w-5" />
                  Contact Support
                </motion.button>
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="border border-white text-white hover:bg-white hover:text-teal-700 px-8 py-4 rounded-xl font-semibold transition-all flex items-center justify-center"
                >
                  <Package className="mr-2 h-5 w-5" />
                  View Policy
                </motion.button>
              </div>
            </motion.div>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.5, duration: 0.8 }}
              className="grid grid-cols-2 md:grid-cols-4 gap-6 mt-16 pt-8 border-t border-white/20"
            >
              {[
                {
                  label: "Shipping Zone",
                  value: "India Only",
                  icon: MapPin,
                },
                { label: "Processing Time", value: "7-10 Days", icon: Clock },
                { label: "Delivery Partners", value: "Trusted", icon: Truck },
                { label: "Transparency", value: "100%", icon: CheckCircle },
              ].map((stat) => (
                <div key={stat.label} className="text-center text-white">
                  <stat.icon className="h-6 w-6 mx-auto mb-2 text-orange-300" />
                  <div className="text-2xl font-bold">{stat.value}</div>
                  <div className="text-sm text-white/60">{stat.label}</div>
                </div>
              ))}
            </motion.div>
          </div>
        </section>

        {/* Shipping Information Section */}
        <section className="py-24 bg-gradient-to-b from-white to-gray-50">
          <div className="container mx-auto px-4">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
              className="text-center mb-16"
            >
              <div className="inline-block mb-4 bg-teal-100 text-teal-600 px-4 py-2 rounded-full text-sm font-medium">
                Shipping Overview
              </div>
              <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
                How We Ship Your Orders
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Learn about our shipping zones, methods, fees, and delivery timeframes to ensure a smooth shopping experience.
              </p>
            </motion.div>
            <div className="grid md:grid-cols-3 gap-8">
              {[
                {
                  icon: MapPin,
                  title: "Shipping Zones",
                  description:
                    "We ship exclusively within India, ensuring reliable delivery to all domestic addresses.",
                  color: "from-teal-400 to-teal-600",
                  bgColor: "from-teal-50 to-teal-100",
                  action: "Learn More",
                },
                {
                  icon: Truck,
                  title: "Shipping Methods",
                  description:
                    "We use trusted shipping partners for standard and expedited delivery options, tailored to your needs.",
                  color: "from-green-400 to-green-600",
                  bgColor: "from-green-50 to-green-100",
                  action: "See Details",
                },
                {
                  icon: Package,
                  title: "Shipping Fees",
                  description:
                    "Fees are calculated based on product weight and delivery address, displayed at checkout.",
                  color: "from-blue-400 to-blue-600",
                  bgColor: "from-blue-50 to-blue-100",
                  action: "Explore Fees",
                },
              ].map((option) => (
                <motion.div
                  key={option.title}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6 }}
                  className="group bg-gradient-to-br from-white to-gray-50 rounded-3xl p-8 border border-gray-100 hover:border-transparent hover:shadow-2xl transition-all duration-500 hover:transform hover:-translate-y-2 cursor-pointer relative overflow-hidden"
                >
                  <div
                    className={`absolute inset-0 bg-gradient-to-br ${option.bgColor} opacity-0 group-hover:opacity-100 transition-opacity duration-500`}
                  ></div>
                  <div
                    className={`w-16 h-16 rounded-2xl flex items-center justify-center mb-6 shadow-lg group-hover:shadow-xl transition-all duration-300 group-hover:scale-110 relative z-10 bg-gradient-to-br ${option.color}`}
                  >
                    <option.icon className="h-8 w-8 text-white transition-transform duration-300 group-hover:scale-110" />
                    <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-white/20 to-transparent"></div>
                  </div>
                  <div className="relative z-10">
                    <h3 className="text-2xl font-bold text-gray-900 mb-4 group-hover:text-teal-700 transition-colors duration-300">
                      {option.title}
                    </h3>
                    <p className="text-gray-600 mb-4 leading-relaxed group-hover:text-gray-700 transition-colors duration-300">
                      {option.description}
                    </p>
                    <button className="inline-flex items-center gap-2 text-sm font-semibold px-4 py-2 bg-teal-50 text-teal-600 rounded-full group-hover:bg-teal-100 transition-all duration-300">
                      <div className="w-2 h-2 bg-teal-400 rounded-full animate-pulse"></div>
                      {option.action}
                    </button>
                  </div>
                  <div
                    className={`absolute top-0 right-0 w-24 h-24 bg-gradient-to-br ${option.color} opacity-10 rounded-full transform translate-x-8 -translate-y-8 group-hover:scale-150 transition-transform duration-500`}
                  ></div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Contact Form Section */}
        <section className="py-24 bg-gray-50">
          <div className="container mx-auto px-4 max-w-3xl">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
              className="text-center mb-16"
            >
              <div className="inline-block mb-4 bg-orange-100 text-orange-600 px-4 py-2 rounded-full text-sm font-medium">
                Get in Touch
              </div>
              <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
                Questions About Shipping?
              </h2>
              <p className="text-xl text-gray-600">
                Contact our team for any shipping-related inquiries, and we’ll respond promptly.
              </p>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="bg-white rounded-3xl p-8 shadow-lg border border-gray-100"
            >
              <div className="space-y-6">
                <div>
                  <label
                    htmlFor="name"
                    className="block text-sm font-medium text-gray-700 mb-2"
                  >
                    Name
                  </label>
                  <input
                    type="text"
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-teal-500 focus:border-transparent transition-all"
                    placeholder="Your Name"
                    aria-required="true"
                  />
                </div>
                <div>
                  <label
                    htmlFor="email"
                    className="block text-sm font-medium text-gray-700 mb-2"
                  >
                    Email
                  </label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-teal-500 focus:border-transparent transition-all"
                    placeholder="Your Email"
                    aria-required="true"
                  />
                </div>
                <div>
                  <label
                    htmlFor="message"
                    className="block text-sm font-medium text-gray-700 mb-2"
                  >
                    Message
                  </label>
                  <textarea
                    id="message"
                    name="message"
                    value={formData.message}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-teal-500 focus:border-transparent transition-all h-32"
                    placeholder="How can we assist you with shipping?"
                    aria-required="true"
                  ></textarea>
                </div>
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={handleSubmit}
                  className="w-full bg-teal-600 hover:bg-teal-700 text-white px-8 py-3 rounded-lg font-semibold transition-all flex items-center justify-center"
                >
                  <Mail className="mr-2 h-5 w-5" />
                  Send Message
                </motion.button>
              </div>
            </motion.div>
          </div>
        </section>

        {/* FAQ Section */}
        <section className="py-24 bg-white">
          <div className="container mx-auto px-4 max-w-4xl">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
              className="text-center mb-16"
            >
              <div className="inline-block mb-4 bg-indigo-100 text-indigo-600 px-4 py-2 rounded-full text-sm font-medium">
                FAQ
              </div>
              <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
                Shipping FAQs
              </h2>
              <p className="text-xl text-gray-600">
                Find answers to common questions about our shipping policies and processes.
              </p>
            </motion.div>
            <Accordion type="single" collapsible className="w-full">
              {faqs.map((faq, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                >
                  <AccordionItem value={`item-${index}`}>
                    <AccordionTrigger className="text-left text-lg font-semibold">
                      {faq.question}
                    </AccordionTrigger>
                    <AccordionContent className="text-gray-600">
                      {faq.answer}
                    </AccordionContent>
                  </AccordionItem>
                </motion.div>
              ))}
            </Accordion>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-24 bg-gradient-to-br from-teal-600 via-blue-600 to-indigo-800 text-white">
          <div className="container mx-auto px-4 text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
              className="max-w-3xl mx-auto space-y-8"
            >
              <h2 className="text-4xl md:text-5xl font-bold">Ready to Shop with Confidence?</h2>
              <p className="text-xl text-white/80">
                Explore our shipping policies or contact us for any questions about delivery and order processing.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="bg-white text-teal-600 hover:bg-gray-100 px-8 py-4 rounded-xl font-semibold shadow-lg transition-all inline-flex items-center justify-center"
                >
                  <Package className="mr-2 h-5 w-5" />
                  View Full Policy
                </motion.button>
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="border border-white text-white hover:bg-white hover:text-teal-600 px-8 py-4 rounded-xl font-semibold transition-all inline-flex items-center justify-center"
                >
                  <Mail className="mr-2 h-5 w-5" />
                  Contact Support
                </motion.button>
              </div>
              <div className="flex flex-wrap justify-center items-center gap-8 pt-8 opacity-80">
                {[
                  { label: "India-Wide Shipping", icon: CheckCircle },
                  { label: "Trusted Partners", icon: CheckCircle },
                  { label: "Transparent Fees", icon: CheckCircle },
                  { label: "Fast Processing", icon: CheckCircle },
                ].map((item, index) => (
                  <motion.div
                    key={item.label}
                    initial={{ opacity: 0, scale: 0.8 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                    className="flex items-center gap-2"
                  >
                    <item.icon className="h-5 w-5" />
                    <span>{item.label}</span>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
};

export default ShippingPolicy;