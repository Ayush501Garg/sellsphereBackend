import { useEffect, useState } from "react";
import {
  Users,
  Briefcase,
  Award,
  Zap,
  ArrowRight,
  Building,
  HeartHandshake,
  Globe,
  Star,
  Home,
  Shield,
  Umbrella,
  GraduationCap,
  Laptop,
  Coffee,
  Smile,
  CheckCircle,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Accordion,
  AccordionItem,
  AccordionTrigger,
  AccordionContent,
} from "@/components/ui/accordion";
import { Link } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
const jobOpenings = [
  {
    title: "Frontend Developer (React.js)",
    type: "Full-time",
    location: "Remote / Bengaluru",
    desc: "Build performant and accessible React-based user interfaces impacting millions of users.",
    perks: ["Remote Friendly", "Stock Options", "Learning Stipend"],
  },
  {
    title: "IoT Embedded Firmware Engineer",
    type: "Full-time",
    location: "Bengaluru",
    desc: "Work hands-on with microcontrollers and embedded systems for next-gen smart devices.",
    perks: ["Device Discounts", "R&D Innovation", "Flexible Hours"],
  },
  {
    title: "Customer Success Manager",
    type: "Full-time",
    location: "Hybrid / Bengaluru",
    desc: "Lead client onboarding, support, and drive customer satisfaction initiatives.",
    perks: ["Paid Leave", "Wellness Programs", "Work From Home"],
  },
  {
    title: "UX/UI Product Designer",
    type: "Contract → Full-time",
    location: "Remote",
    desc: "Craft intuitive and visually stunning interfaces for our smart home product line.",
    perks: ["Remote Work", "Learning Budget", "Innovation Awards"],
  },
];

const perks = [
  { icon: Home, label: "Hybrid & Remote Work" },
  { icon: Shield, label: "Comprehensive Health Insurance" },
  { icon: GraduationCap, label: "Continuous Learning Budget" },
  { icon: Laptop, label: "Latest Tech Stack" },
  { icon: Coffee, label: "Casual & Fun Culture" },
  { icon: Umbrella, label: "Paid Leaves & Holidays" },
  { icon: Smile, label: "Wellness & Mental Health" },
  { icon: Award, label: "Recognition & Awards" },
];

const testimonials = [
  {
    quote:
      "Working at Halox has accelerated my career and given me the freedom to innovate daily.",
    name: "Aarav S.",
    role: "Senior IoT Engineer",
    avatar: "team-1.jpg",
  },
  {
    quote:
      "The culture here is collaborative and supportive — your ideas are valued.",
    name: "Priya M.",
    role: "UI/UX Designer",
    avatar: "team-2.jpg",
  },
  {
    quote:
      "Work-life balance is truly respected, making this the best place I’ve ever worked.",
    name: "Rahul D.",
    role: "Customer Success Manager",
    avatar: "team-1.jpg",
  },
];

const Careers = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    setIsVisible(true);
  }, []);

  const canonical =
    typeof window !== "undefined"
      ? `${window.location.origin}/careers`
      : "/careers";

  return (
    <div className="min-h-screen bg-background">
      <Header />

      {/* SEO Metadata */}
      <Helmet>
        <title>Careers at Halox | LivSmart Automation</title>
        <meta
          name="description"
          content="Join Halox, powered by LivSmart Automation and Security LLP, to innovate smart home solutions. Explore career opportunities and grow with us."
        />
        <link rel="canonical" href={canonical} />
      </Helmet>

      <section className="relative min-h-screen flex flex-col items-center justify-center overflow-hidden bg-gradient-to-br from-indigo-900 via-purple-900 to-pink-900 pt-24 pb-24 px-6">
        {/* Background */}
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute inset-0 bg-white/6 bg-[radial-gradient(circle_at_2px_2px,rgba(255,255,255,0.15)_2px,transparent_0)] bg-[length:30px_30px] animate-pulse opacity-50"></div>
          <div className="absolute top-16 left-12 w-48 h-48 bg-purple-500/30 rounded-full blur-3xl animate-pulse"></div>
          <div
            className="absolute bottom-20 right-12 w-72 h-72 bg-pink-500/30 rounded-full blur-3xl animate-pulse"
            style={{ animationDelay: "1s" }}
          ></div>
          <div
            className="absolute top-1/2 left-1/4 w-36 h-36 bg-indigo-500/20 rounded-full blur-2xl animate-pulse"
            style={{ animationDelay: "2s" }}
          ></div>
        </div>

        {/* Hero Content */}
        <div
          className={`relative max-w-5xl w-full text-center transition-all duration-1000 ease-out ${
            isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-12"
          }`}
        >
          <h1 className="text-5xl md:text-6xl font-extrabold text-white leading-tight mb-4">
            Job{" "}
            <span className="bg-gradient-to-r from-pink-400 via-purple-400 to-orange-400 bg-clip-text text-transparent underline">
              Opening
            </span>
          </h1>
          <hr />
          <br />
          <br />

          <div className="flex flex-wrap justify-center gap-4 mb-8">
            <Badge className="bg-white/20 text-white border-white/30 backdrop-blur-md">
              <Zap className="h-4 w-4 mr-2" />
              Innovation First
            </Badge>
            <Badge className="bg-purple-500/20 text-purple-300 border-purple-400/30 backdrop-blur-md">
              <Globe className="h-4 w-4 mr-2" />
              Remote Friendly
            </Badge>
            <Badge className="bg-pink-500/20 text-pink-300 border-pink-400/30 backdrop-blur-md">
              <Users className="h-4 w-4 mr-2" />
              People-Centric
            </Badge>
            <Badge className="bg-orange-500/20 text-orange-300 border-orange-400/30 backdrop-blur-md">
              <Star className="h-4 w-4 mr-2" />
              Growth Opportunities
            </Badge>
          </div>

          <h1 className="text-5xl md:text-6xl font-extrabold text-white leading-tight mb-4">
            Shape India’s{" "}
            <span className="bg-gradient-to-r from-pink-400 via-purple-400 to-orange-400 bg-clip-text text-transparent">
              Smart Future
            </span>
          </h1>

          <p className="text-lg md:text-xl text-white/90 max-w-3xl mx-auto mb-8">
            Join Halox — India’s fastest-growing smart home brand. Pioneer
            innovation that empowers millions to live smarter, safer, and
            better.
          </p>

          <div className="flex flex-col sm:flex-row justify-center gap-6">
            <Link to="/careers/openings">
              <Button className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-pink-700 text-white font-semibold px-10 py-4 rounded-lg shadow-lg transition transform hover:scale-105 flex items-center gap-2">
                View Open Roles <ArrowRight className="w-5 h-5" />
              </Button>
            </Link>
            <Link to="/apply">
              <Button
                size="lg"
                variant="outline"
                className="border-blue bg-[#0ea5c8] hover:text-white hover:bg-white/20 hover:border-white/90 px-10 py-4 rounded-lg font-semibold flex items-center justify-center transition-transform duration-300 ease-in-out hover:scale-105 active:scale-95"
              >
                Submit Resume
              </Button>
            </Link>
          </div>
        </div>

        {/* Perks Section */}
        <div className="w-full max-w-6xl mt-20 grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-6 text-white">
          {perks.map(({ icon: Icon, label }) => (
            <div
              key={label}
              className="flex flex-col items-center gap-2 p-4 bg-white/10 rounded-xl shadow-lg backdrop-blur-sm hover:bg-white/20 transition cursor-default"
              title={label}
            >
              <Icon className="h-8 w-8 text-pink-400" />
              <p className="text-sm font-medium">{label}</p>
            </div>
          ))}
        </div>

        {/* Job Openings */}
        <section className="mt-24 w-full max-w-4xl">
          <h2 className="text-3xl font-bold text-white text-center mb-10 underline">
            Current Openings
          </h2>
          <Accordion
            type="single"
            collapsible
            className="w-full bg-white/10 rounded-2xl p-4 backdrop-blur-lg border border-white/20 shadow-lg"
          >
            {jobOpenings.map(({ title, desc, location, perks, type }, idx) => (
              <AccordionItem key={title} value={`job-${idx}`}>
                <AccordionTrigger
                  className="flex flex-col sm:flex-row justify-between items-center px-4 py-3 text-white text-lg font-semibold hover:bg-pink-600/30 rounded-lg cursor-pointer select-none"
                  aria-label={`Toggle details for ${title}`}
                >
                  <div className="flex flex-col sm:flex-row sm:items-center gap-2">
                    <Briefcase className="h-6 w-6 text-pink-400" />
                    <span>{title}</span>
                    <span className="ml-2 text-sm text-white/70 font-normal">
                      ({type}, {location})
                    </span>
                  </div>
                  <Badge className="bg-green-500/90 text-white px-2 py-1">
                    Apply
                  </Badge>
                </AccordionTrigger>
                <AccordionContent className="px-6 py-4 text-white/90 bg-pink-900/70 rounded-b-lg">
                  <p className="mb-4">{desc}</p>
                  <div className="flex flex-wrap gap-2 mb-4">
                    {perks.map((perk) => (
                      <span
                        key={perk}
                        className="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-pink-700/80 text-xs font-semibold text-white/90"
                      >
                        <CheckCircle className="w-4 h-4 text-green-300" />
                        {perk}
                      </span>
                    ))}
                  </div>
                  <div className="flex justify-end">
                    <Link to="/apply">
                      <Button
                        size="sm"
                        className="bg-pink-600 hover:bg-pink-700 text-white font-semibold px-4 py-2"
                        aria-label={`Apply for ${title}`}
                      >
                        Apply for this role
                      </Button>
                    </Link>
                  </div>
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </section>

        {/* Testimonials */}
        <section className="mt-32 w-full max-w-6xl text-white">
          <h2 className="text-3xl font-bold mb-12 text-center underline">
            Life at Halox
          </h2>
          <div className="grid md:grid-cols-3 gap-10">
            {testimonials.map(({ name, role, quote, avatar }) => (
              <div
                key={name}
                className="bg-white/10 rounded-3xl p-8 flex flex-col items-center text-center shadow-lg backdrop-blur-sm hover:scale-[1.03] transition-transform duration-300"
              >
                <img
                  src={avatar}
                  alt={`${name}'s avatar`}
                  loading="lazy"
                  className="rounded-full w-20 h-20 mb-5 object-cover border-2 border-pink-400"
                  onError={(e) => {
                    e.currentTarget.src = "/team/placeholder.jpg"; // Fallback image
                  }}
                />
                <p className="italic mb-4">“{quote}”</p>
                <h4 className="font-bold text-lg">{name}</h4>
                <p className="text-pink-300 text-sm">{role}</p>
              </div>
            ))}
          </div>
        </section>

        {/* Why Join Us */}
        <section className="mt-32 w-full max-w-6xl grid md:grid-cols-3 gap-12 text-white">
          {[
            {
              icon: Briefcase,
              title: "Impactful Work",
              desc: "Build IoT solutions powering millions of homes and businesses.",
            },
            {
              icon: HeartHandshake,
              title: "Inclusive Culture",
              desc: "Thriving workplace where diversity and respect lead the way.",
            },
            {
              icon: Star,
              title: "Career Growth",
              desc: "Clear paths, mentorship, and chances to lead projects and teams.",
            },
            {
              icon: Building,
              title: "Strong Foundation",
              desc: "Backed by trusted LivSmart Automation & Security LLP.",
            },
            {
              icon: Users,
              title: "Collaborative Teams",
              desc: "Work alongside passionate and talented innovators.",
            },
            {
              icon: Zap,
              title: "Innovation Mindset",
              desc: "Encouraged to bring ideas and experiment continuously.",
            },
          ].map(({ icon: Icon, title, desc }) => (
            <div
              key={title}
              className="bg-white/10 rounded-3xl p-6 shadow-lg backdrop-blur-sm hover:scale-105 transition-transform duration-300"
            >
              <Icon className="w-10 h-10 mb-4 text-pink-400" />
              <h3 className="text-lg font-semibold mb-2">{title}</h3>
              <p className="text-white/90">{desc}</p>
            </div>
          ))}
        </section>
      </section>
      <Footer />
    </div>
  );
};

export default Careers;
