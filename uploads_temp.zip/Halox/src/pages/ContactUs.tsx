import { useState } from "react";
import {
  Mail,
  Phone,
  MapPin,
  MessageSquare,
  Send,
  CheckCircle,
  Globe,
  Clock,
  Users,
  Star,
} from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Accordion, AccordionItem, AccordionTrigger, AccordionContent } from "@/components/ui/accordion";
import { Helmet } from "react-helmet-async";

const ContactUs = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: "",
  });
  const [formStatus, setFormStatus] = useState(null);

  const faqs = [
    {
      question: "How can I get support for the Halox Smart app?",
      answer: "You can reach our support team 24/7 via email at support@haloxsmart.com, call us at +91-800-HALOX-SMART, or use the live chat feature in the app.",
    },
    {
      question: "What are your customer support hours?",
      answer: "We offer 24/7 customer support to ensure you get help whenever you need it, including weekends and holidays.",
    },
    {
      question: "Can I visit your office for in-person support?",
      answer: "Yes, you can visit our office in Bangalore during business hours (9 AM - 6 PM, Monday to Friday). Please schedule an appointment via email.",
    },
    {
      question: "How long does it take to get a response to my query?",
      answer: "We aim to respond to all queries within 24 hours. Urgent issues are prioritized and addressed within a few hours.",
    },
  ];

  const faqLd = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: faqs.map((f) => ({
      "@type": "Question",
      name: f.question,
      acceptedAnswer: { "@type": "Answer", text: f.answer },
    })),
  };

  const canonical = typeof window !== "undefined" ? `${window.location.origin}/contact` : "/contact";

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Simulate form submission
    setFormStatus("success");
    setTimeout(() => {
      setFormStatus(null);
      setFormData({ name: "", email: "", message: "" });
    }, 3000);
  };

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Contact Us | Halox Smart App</title>
        <meta
          name="description"
          content="Get in touch with Halox Smart. Reach out via email, phone, or our contact form for support, inquiries, or feedback."
        />
        <link rel="canonical" href={canonical} />
        <script type="application/ld+json">{JSON.stringify(faqLd)}</script>
      </Helmet>

      <Header />

      <main>
        {/* Hero Section */}
        <section className="relative min-h-[70vh] flex items-center justify-center overflow-hidden bg-[#30cfd0] bg-gradient-to-r from-[#330867] to-[#30cfd0] text-white">
          <div className="absolute inset-0 opacity-10">
            <div className="absolute inset-0 bg-white/5 bg-[radial-gradient(circle_at_1px_1px,rgba(255,255,255,0.15)_1px,transparent_0)] bg-[length:20px_20px] animate-pulse"></div>
          </div>
          <div className="container mx-auto px-4 relative z-10">
            <div className="text-center space-y-8">
              <div className="inline-flex items-center bg-white/20 text-white border border-white/30 backdrop-blur-sm rounded-full px-4 py-2">
                <MessageSquare className="h-3 w-3 mr-1" />
                We’re Here to Help
              </div>
              <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold text-white leading-tight">
                Contact <span className="block text-orange-300">Halox Smart</span>
              </h1>
              <p className="text-lg md:text-xl text-white/80 max-w-2xl mx-auto">
                Have questions or need support? Our team is available 24/7 to assist with your smart home journey.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <a
                  href="mailto:support@haloxsmart.com"
                  className="bg-orange-500 hover:bg-orange-600 text-white px-8 py-4 rounded-lg font-semibold shadow-lg transition-all flex items-center justify-center"
                >
                  <Mail className="mr-2 h-5 w-5" />
                  Email Us
                </a>
                <a
                  href="tel:+91800HALOXSMART"
                  className="border border-white text-white hover:bg-white hover:text-blue-600 px-8 py-4 rounded-lg font-semibold transition-all flex items-center justify-center"
                >
                  <Phone className="mr-2 h-5 w-5" />
                  Call Us
                </a>
              </div>
            </div>
          </div>
        </section>

        {/* Contact Form & Info Section */}
        <section className="py-24 bg-white">
          <div className="container mx-auto px-4">
            <div className="grid lg:grid-cols-2 gap-12">
              {/* Contact Form */}
              <div className="bg-gradient-to-br from-gray-50 to-white rounded-3xl p-8 shadow-lg border border-gray-100">
                <h2 className="text-3xl font-bold text-gray-900 mb-6">Send Us a Message</h2>
                <p className="text-gray-600 mb-8">Fill out the form below, and we’ll get back to you within 24 hours.</p>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div>
                    <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                      Name
                    </label>
                    <input
                      type="text"
                      id="name"
                      name="name"
                      value={formData.name}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                      placeholder="Your Name"
                      required
                    />
                  </div>
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                      Email
                    </label>
                    <input
                      type="email"
                      id="email"
                      name="email"
                      value={formData.email}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                      placeholder="Your Email"
                      required
                    />
                  </div>
                  <div>
                    <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-1">
                      Message
                    </label>
                    <textarea
                      id="message"
                      name="message"
                      value={formData.message}
                      onChange={handleInputChange}
                      rows="5"
                      className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                      placeholder="Your Message"
                      required
                    ></textarea>
                  </div>
                  <button
                    type="submit"
                    className="w-full bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg font-semibold transition-all flex items-center justify-center"
                  >
                    <Send className="mr-2 h-5 w-5" />
                    Send Message
                  </button>
                  {formStatus === "success" && (
                    <div className="flex items-center justify-center gap-2 text-green-600 mt-4">
                      <CheckCircle className="h-5 w-5" />
                      <span>Message sent successfully!</span>
                    </div>
                  )}
                </form>
              </div>
              {/* Contact Info */}
              <div className="space-y-8">
                <h2 className="text-3xl font-bold text-gray-900">Get in Touch</h2>
                <p className="text-gray-600 max-w-lg">
                  We’re here to answer your questions, provide support, or hear your feedback. Reach out to us anytime.
                </p>
                <div className="space-y-6">
                  {[
                    {
                      icon: Mail,
                      title: "Email Us",
                      value: "support@haloxsmart.com",
                      href: "mailto:support@haloxsmart.com",
                      color: "bg-blue-100 text-blue-600",
                    },
                    {
                      icon: Phone,
                      title: "Call Us",
                      value: "+91-800-HALOX-SMART",
                      href: "tel:+91800HALOXSMART",
                      color: "bg-green-100 text-green-600",
                    },
                    {
                      icon: MapPin,
                      title: "Visit Us",
                      value: "123 Smart Street, Bangalore, Karnataka, India",
                      href: "https://maps.google.com",
                      color: "bg-orange-100 text-orange-600",
                    },
                  ].map((contact, index) => (
                    <div
                      key={index}
                      className="group flex items-center gap-4 bg-gradient-to-br from-gray-50 to-white rounded-xl p-6 border border-gray-100 hover:shadow-lg transition-all duration-300"
                    >
                      <div className={`${contact.color} w-12 h-12 rounded-xl flex items-center justify-center shadow-md group-hover:scale-110 transition-transform duration-300`}>
                        <contact.icon className="h-6 w-6" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-gray-900">{contact.title}</h3>
                        <a
                          href={contact.href}
                          className="text-gray-600 hover:text-blue-600 transition-colors duration-300"
                        >
                          {contact.value}
                        </a>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="flex flex-wrap gap-6 pt-4">
                  <div className="flex items-center gap-2 text-gray-600">
                    <Clock className="h-5 w-5 text-blue-600" />
                    <span>24/7 Support</span>
                  </div>
                  <div className="flex items-center gap-2 text-gray-600">
                    <Globe className="h-5 w-5 text-blue-600" />
                    <span>Global Reach</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* FAQ Section */}
        <section className="py-24 bg-gray-50">
          <div className="container mx-auto px-4 max-w-4xl">
            <div className="text-center mb-16">
              <div className="inline-block mb-4 bg-indigo-100 text-indigo-600 px-4 py-2 rounded-full text-sm font-medium">
                FAQ
              </div>
              <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
                Frequently Asked Questions
              </h2>
              <p className="text-xl text-gray-600">
                Find answers to common questions about contacting Halox Smart.
              </p>
            </div>
            <Accordion type="single" collapsible className="w-full">
              {faqs.map((faq, index) => (
                <AccordionItem key={index} value={`item-${index}`}>
                  <AccordionTrigger>{faq.question}</AccordionTrigger>
                  <AccordionContent>{faq.answer}</AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-24 bg-[#3cba92] bg-gradient-to-r from-[#330867] to-[#30cfd0] text-white">
          <div className="container mx-auto px-4 text-center">
            <div className="max-w-3xl mx-auto space-y-8">
              <h2 className="text-4xl md:text-5xl font-bold">
                Ready to Connect?
              </h2>
              <p className="text-xl text-white/80">
                Our team is standing by to help you with any questions or support needs. Reach out today!
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <a
                  href="mailto:support@haloxsmart.com"
                  className="bg-white text-blue-600 hover:bg-gray-100 px-8 py-4 rounded-lg font-semibold shadow-lg transition-all inline-flex items-center justify-center"
                >
                  <Mail className="mr-2 h-5 w-5" />
                  Email Support
                </a>
                <a
                  href="tel:+91800HALOXSMART"
                  className="border border-white text-white hover:bg-white hover:text-blue-600 px-8 py-4 rounded-lg font-semibold transition-all inline-flex items-center justify-center"
                >
                  <Phone className="mr-2 h-5 w-5" />
                  Call Support
                </a>
              </div>
              <div className="flex flex-wrap justify-center items-center gap-8 pt-8 opacity-80">
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-5 w-5" />
                  <span>24/7 Availability</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-5 w-5" />
                  <span>Fast Response</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-5 w-5" />
                  <span>Friendly Team</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-5 w-5" />
                  <span>Secure Communication</span>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
};

export default ContactUs;