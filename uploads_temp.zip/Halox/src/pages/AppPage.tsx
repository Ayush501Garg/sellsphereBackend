import { useState, useEffect, useRef } from "react";
import {
  Download,
  Zap,
  Shield,
  Users,
  Smartphone,
  Timer,
  BarChart3,
  Home,
  Lock,
  Wifi,
  Moon,
  Sun,
  Play,
  Star,
  CheckCircle,
  ArrowRight,
  Bell,
  Settings,
  Heart,
  Thermometer,
  Camera,
  Battery,
  User,
  Key,
  Speaker,
  MessageSquare,
  TrendingUp,
  Fan,
  Tv,
  Lightbulb,
  BellOff,
  DoorClosed,
  Power,
  AlertCircle,
  Music,
} from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Accordion, AccordionItem, AccordionTrigger, AccordionContent } from "@/components/ui/accordion";
import { Helmet } from "react-helmet-async";

const AppPage = () => {
  const [activeFeature, setActiveFeature] = useState(0);
  const [currentScreen, setCurrentScreen] = useState("home");
  const [lightStatus, setLightStatus] = useState(true);
  const [securityStatus, setSecurityStatus] = useState(false);
  const [selectedRoom, setSelectedRoom] = useState(null);
  const [currentTime, setCurrentTime] = useState(
    new Date().toLocaleTimeString("en-IN", { hour12: false, hour: "2-digit", minute: "2-digit" })
  );

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTime(
        new Date().toLocaleTimeString("en-IN", { hour12: false, hour: "2-digit", minute: "2-digit" })
      );
    }, 60000);
    return () => clearInterval(interval);
  }, []);

  const toggleLights = () => setLightStatus(!lightStatus);
  const toggleSecurity = () => setSecurityStatus(!securityStatus);

  const features = [
    {
      icon: Zap,
      title: "Instant Control",
      description: "Control all your smart devices instantly with a single tap. Turn lights on/off, adjust brightness, and more.",
      color: "bg-blue-100 text-blue-600",
      demo: "Toggle 15 lights in 2.3 seconds",
    },
    {
      icon: Timer,
      title: "Smart Scheduling",
      description: "Set schedules and timers for your devices. Automate your daily routines effortlessly.",
      color: "bg-green-100 text-green-600",
      demo: "Schedule AC to turn on at 6 PM daily",
    },
    {
      icon: BarChart3,
      title: "Energy Analytics",
      description: "Monitor energy consumption and get insights to reduce your electricity bills.",
      color: "bg-purple-100 text-purple-600",
      demo: "Save ₹2,400 monthly on electricity",
    },
    {
      icon: Shield,
      title: "Privacy First",
      description: "Your data stays in India. End-to-end encryption ensures complete privacy and security.",
      color: "bg-orange-100 text-orange-600",
      demo: "256-bit AES encryption",
    },
    {
      icon: Users,
      title: "Family Sharing",
      description: "Share control with family members. Set permissions and manage access easily.",
      color: "bg-pink-100 text-pink-600",
      demo: "Add up to 8 family members",
    },
    {
      icon: Moon,
      title: "Scene Control",
      description: "Create custom scenes like 'Movie Time' or 'Good Night' to control multiple devices at once.",
      color: "bg-indigo-100 text-indigo-600",
      demo: "50+ pre-built scenes available",
    },
  ];

  const testimonials = [
    {
      name: "Priya Sharma",
      location: "Mumbai",
      rating: 5,
      text: "Halox Smart has completely transformed our home. The energy savings alone have paid for all our smart devices!",
      avatar: "PS",
    },
    {
      name: "Rajesh Kumar",
      location: "Delhi",
      rating: 5,
      text: "The app is so intuitive. Even my grandmother can control the lights and fans easily. Great work!",
      avatar: "RK",
    },
    {
      name: "Meena Patel",
      location: "Ahmedabad",
      rating: 5,
      text: "Privacy-first approach and data staying in India gives me complete peace of mind. Highly recommended!",
      avatar: "MP",
    },
  ];

  const faqs = [
    {
      question: "Is the Halox Smart app free to download?",
      answer: "Yes, the Halox Smart app is completely free to download and use. There are no subscription fees or hidden charges.",
    },
    {
      question: "Which devices are compatible with Halox Smart?",
      answer: "Our app works with 500+ smart devices including switches, plugs, bulbs, ACs, security cameras, and more from leading Indian and international brands.",
    },
    {
      question: "Is my data secure with Halox Smart?",
      answer: "Absolutely! We use end-to-end encryption and store all data in Indian servers. Your privacy is our top priority.",
    },
    {
      question: "Can I control devices when I'm away from home?",
      answer: "Yes, you can control all your smart devices remotely from anywhere in the world through our secure cloud connection.",
    },
    {
      question: "How much can I save on electricity bills?",
      answer: "Our users typically save 15-30% on their electricity bills through smart scheduling, energy monitoring, and automated controls.",
    },
  ];

  const faqLd = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: faqs.map((f) => ({
      "@type": "Question",
      name: f.question,
      acceptedAnswer: { "@type": "Answer", text: f.answer },
    })),
  };

  const roomDevices = [
    {
      name: "Living Room",
      count: 12,
      devices: [
        { name: "Smart TV", icon: Tv, status: "On", color: "text-red-500", bgColor: "bg-red-100", action: "Turn Off" },
        { name: "LED Strips", icon: Lightbulb, status: "50% Brightness", color: "text-amber-500", bgColor: "bg-amber-100", action: "Turn Off" },
        { name: "AC Unit", icon: Thermometer, status: "24°C", color: "text-blue-500", bgColor: "bg-blue-100", action: "Adjust" },
        { name: "Smart Speaker", icon: Speaker, status: "Playing", color: "text-purple-500", bgColor: "bg-purple-100", action: "Pause" },
        { name: "Motion Sensor", icon: AlertCircle, status: "Active", color: "text-green-500", bgColor: "bg-green-100", action: "Settings" },
        { name: "Smart Fan", icon: Fan, status: "Medium Speed", color: "text-cyan-500", bgColor: "bg-cyan-100", action: "Adjust" },
        { name: "Ceiling Light", icon: Lightbulb, status: "On", color: "text-yellow-500", bgColor: "bg-yellow-100", action: "Turn Off" },
        { name: "Curtains", icon: DoorClosed, status: "Open", color: "text-indigo-500", bgColor: "bg-indigo-100", action: "Close" },
        { name: "Power Plug", icon: Power, status: "On", color: "text-orange-500", bgColor: "bg-orange-100", action: "Turn Off" },
        { name: "Doorbell", icon: Bell, status: "Silent", color: "text-teal-500", bgColor: "bg-teal-100", action: "Settings" },
        { name: "Smart Lock", icon: Lock, status: "Locked", color: "text-gray-500", bgColor: "bg-gray-100", action: "Unlock" },
        { name: "Ambience Light", icon: Lightbulb, status: "Warm", color: "text-pink-500", bgColor: "bg-pink-100", action: "Adjust" },
      ],
    },
    {
      name: "Kitchen",
      count: 12,
      devices: [
        { name: "Smart Fridge", icon: Thermometer, status: "5°C", color: "text-blue-500", bgColor: "bg-blue-100", action: "Adjust" },
        { name: "Smart Oven", icon: Thermometer, status: "Off", color: "text-red-500", bgColor: "bg-red-100", action: "Turn On" },
        { name: "Ceiling Light", icon: Lightbulb, status: "On", color: "text-yellow-500", bgColor: "bg-yellow-100", action: "Turn Off" },
        { name: "Smoke Detector", icon: AlertCircle, status: "Active", color: "text-orange-500", bgColor: "bg-orange-100", action: "Test" },
        { name: "Smart Fan", icon: Fan, status: "Low Speed", color: "text-cyan-500", bgColor: "bg-cyan-100", action: "Adjust" },
        { name: "Coffee Maker", icon: Power, status: "Off", color: "text-brown-500", bgColor: "bg-brown-100", action: "Turn On" },
        { name: "Smart Plug", icon: Power, status: "On", color: "text-green-500", bgColor: "bg-green-100", action: "Turn Off" },
        { name: "Microwave", icon: Thermometer, status: "Off", color: "text-gray-500", bgColor: "bg-gray-100", action: "Turn On" },
        { name: "Water Purifier", icon: Power, status: "On", color: "text-blue-500", bgColor: "bg-blue-100", action: "Settings" },
        { name: "Motion Sensor", icon: AlertCircle, status: "Active", color: "text-purple-500", bgColor: "bg-purple-100", action: "Settings" },
        { name: "Smart Light", icon: Lightbulb, status: "Cool", color: "text-teal-500", bgColor: "bg-teal-100", action: "Adjust" },
        { name: "Ventilation Fan", icon: Fan, status: "Off", color: "text-indigo-500", bgColor: "bg-indigo-100", action: "Turn On" },
      ],
    },
    {
      name: "Bedroom",
      count: 12,
      devices: [
        { name: "Smart Light", icon: Lightbulb, status: "Warm", color: "text-amber-500", bgColor: "bg-amber-100", action: "Adjust" },
        { name: "AC Unit", icon: Thermometer, status: "22°C", color: "text-blue-500", bgColor: "bg-blue-100", action: "Adjust" },
        { name: "Smart Curtains", icon: DoorClosed, status: "Closed", color: "text-indigo-500", bgColor: "bg-indigo-100", action: "Open" },
        { name: "Smart Fan", icon: Fan, status: "Low Speed", color: "text-cyan-500", bgColor: "bg-cyan-100", action: "Adjust" },
        { name: "Bedside Lamp", icon: Lightbulb, status: "On", color: "text-yellow-500", bgColor: "bg-yellow-100", action: "Turn Off" },
        { name: "Smart TV", icon: Tv, status: "Off", color: "text-red-500", bgColor: "bg-red-100", action: "Turn On" },
        { name: "Smart Speaker", icon: Speaker, status: "Silent", color: "text-purple-500", bgColor: "bg-purple-100", action: "Play" },
        { name: "Motion Sensor", icon: AlertCircle, status: "Active", color: "text-green-500", bgColor: "bg-green-100", action: "Settings" },
        { name: "Smart Plug", icon: Power, status: "On", color: "text-orange-500", bgColor: "bg-orange-100", action: "Turn Off" },
        { name: "Humidifier", icon: Power, status: "Off", color: "text-teal-500", bgColor: "bg-teal-100", action: "Turn On" },
        { name: "Smart Lock", icon: Lock, status: "Locked", color: "text-gray-500", bgColor: "bg-gray-100", action: "Unlock" },
        { name: "Night Light", icon: Lightbulb, status: "Off", color: "text-pink-500", bgColor: "bg-pink-100", action: "Turn On" },
      ],
    },
    {
      name: "Guest Room",
      count: 12,
      devices: [
        { name: "Smart Light", icon: Lightbulb, status: "Warm", color: "text-amber-500", bgColor: "bg-amber-100", action: "Adjust" },
        { name: "AC Unit", icon: Thermometer, status: "22°C", color: "text-blue-500", bgColor: "bg-blue-100", action: "Adjust" },
        { name: "Smart TV", icon: Tv, status: "Netflix Ready", color: "text-red-500", bgColor: "bg-red-100", action: "Turn On" },
        { name: "Smart Lock", icon: Lock, status: "Locked", color: "text-green-500", bgColor: "bg-green-100", action: "Unlock" },
        { name: "Smart Curtains", icon: DoorClosed, status: "Open", color: "text-indigo-500", bgColor: "bg-indigo-100", action: "Close" },
        { name: "Motion Sensor", icon: AlertCircle, status: "Active", color: "text-purple-500", bgColor: "bg-purple-100", action: "Settings" },
        { name: "Smart Fan", icon: Fan, status: "Medium Speed", color: "text-cyan-500", bgColor: "bg-cyan-100", action: "Adjust" },
        { name: "Bedside Lamp", icon: Lightbulb, status: "On", color: "text-yellow-500", bgColor: "bg-yellow-100", action: "Turn Off" },
        { name: "Smart Plug", icon: Power, status: "On", color: "text-orange-500", bgColor: "bg-orange-100", action: "Turn Off" },
        { name: "Humidifier", icon: Power, status: "Off", color: "text-teal-500", bgColor: "bg-teal-100", action: "Turn On" },
        { name: "Smart Speaker", icon: Speaker, status: "Silent", color: "text-pink-500", bgColor: "bg-pink-100", action: "Play" },
        { name: "Night Light", icon: Lightbulb, status: "Off", color: "text-gray-500", bgColor: "bg-gray-100", action: "Turn On" },
      ],
    },
    {
      name: "Lobby",
      count: 12,
      devices: [
        { name: "Security Camera", icon: Camera, status: "Live", color: "text-red-500", bgColor: "bg-red-100", action: "View" },
        { name: "Smart Doorbell", icon: Bell, status: "No Visitors", color: "text-purple-500", bgColor: "bg-purple-100", action: "Settings" },
        { name: "Entrance Light", icon: Lightbulb, status: "Auto Mode", color: "text-yellow-500", bgColor: "bg-yellow-100", action: "Manual" },
        { name: "Motion Detector", icon: AlertCircle, status: "Monitoring", color: "text-blue-500", bgColor: "bg-blue-100", action: "History" },
        { name: "Security System", icon: Shield, status: "Armed", color: "text-green-500", bgColor: "bg-green-100", action: "Disarm" },
        { name: "Smart Lock", icon: Lock, status: "Locked", color: "text-gray-500", bgColor: "bg-gray-100", action: "Unlock" },
        { name: "Smart Light", icon: Lightbulb, status: "On", color: "text-amber-500", bgColor: "bg-amber-100", action: "Turn Off" },
        { name: "Smart Fan", icon: Fan, status: "Low Speed", color: "text-cyan-500", bgColor: "bg-cyan-100", action: "Adjust" },
        { name: "Smart Plug", icon: Power, status: "On", color: "text-orange-500", bgColor: "bg-orange-100", action: "Turn Off" },
        { name: "Ambience Light", icon: Lightbulb, status: "Warm", color: "text-pink-500", bgColor: "bg-pink-100", action: "Adjust" },
        { name: "Smart Speaker", icon: Speaker, status: "Silent", color: "text-teal-500", bgColor: "bg-teal-100", action: "Play" },
        { name: "Emergency Alarm", icon: AlertCircle, status: "Off", color: "text-red-500", bgColor: "bg-red-100", action: "Test" },
      ],
    },
  ];

  const HomeScreen = ({ setCurrentScreen, lightStatus, toggleLights, securityStatus, toggleSecurity, setSelectedRoom }) => {
    const [showHiddenRooms, setShowHiddenRooms] = useState(false);
    const roomListRef = useRef(null);

    useEffect(() => {
      const handleScroll = () => {
        if (roomListRef.current) {
          const { scrollTop, scrollHeight, clientHeight } = roomListRef.current;
          if (scrollTop > (scrollHeight - clientHeight) * 0.5) {
            setShowHiddenRooms(true);
          } else {
            setShowHiddenRooms(false);
          }
        }
      };

      const roomListElement = roomListRef.current;
      if (roomListElement) {
        roomListElement.addEventListener("scroll", handleScroll);
      }

      return () => {
        if (roomListElement) {
          roomListElement.removeEventListener("scroll", handleScroll);
        }
      };
    }, []);

    return (
      <div className="bg-gradient-to-br from-blue-50 to-purple-50 min-h-[540px] relative overflow-y-auto">
        <div className="flex justify-between items-center p-4 text-black text-sm">
          <span className="font-medium">{currentTime}</span>
          <div className="flex items-center gap-1">
            <div className="w-4 h-2 bg-green-500 rounded-sm"></div>
            <span className="text-xs">100%</span>
          </div>
        </div>
        <div className="px-6 py-4">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-2xl font-bold text-gray-900">Good Evening</h2>
              <p className="text-gray-600">Welcome home, Priya</p>
            </div>
            <div className="bg-white rounded-full p-3 shadow-sm cursor-pointer" onClick={() => setCurrentScreen("login")}>
              <User className="h-6 w-6 text-blue-600" />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3 mb-6">
            <div className="bg-white rounded-2xl p-4 shadow-sm cursor-pointer" onClick={toggleLights}>
              <div className="flex items-center justify-between mb-3">
                <Sun className="h-5 w-5 text-orange-500" />
              </div>
              <p className="text-sm font-medium text-gray-900">All Lights</p>
              <p className="text-xs text-gray-500">{lightStatus ? "8 devices ON" : "8 devices OFF"}</p>
            </div>
            <div className="bg-white rounded-2xl p-4 shadow-sm cursor-pointer" onClick={toggleSecurity}>
              <div className="flex items-center justify-between mb-3">
                <Shield className="h-5 w-5 text-green-500" />
              </div>
              <p className="text-sm font-medium text-gray-900">Security</p>
              <p className="text-xs text-gray-500">{securityStatus ? "Armed" : "Disarmed"}</p>
            </div>
          </div>
          <div className="space-y-3 max-h-[300px] overflow-y-auto" ref={roomListRef}>
            <h3 className="font-semibold text-gray-900">Rooms</h3>
            {roomDevices.map((room, index) => (
              <div 
                key={room.name} 
                className="bg-white rounded-xl p-4 shadow-sm flex items-center justify-between cursor-pointer hover:bg-gray-50 transition-colors"
                onClick={() => setSelectedRoom(room.name)}
              >
                <div className="flex items-center gap-3">
                  <div className={`h-10 w-10 rounded-full flex items-center justify-center ${
                    index % 3 === 0 ? "bg-blue-100" : index % 3 === 1 ? "bg-purple-100" : "bg-green-100"
                  }`}>
                    <Home className={`h-5 w-5 ${
                      index % 3 === 0 ? "text-blue-600" : index % 3 === 1 ? "text-purple-600" : "text-green-600"
                    }`} />
                  </div>
                  <div>
                    <p className="font-medium text-gray-900">{room.name}</p>
                    <p className="text-xs text-gray-500">{room.count} devices</p>
                  </div>
                </div>
                <div className="text-blue-600 text-sm font-medium">Tap to control</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  };

  const RoomControl = ({ roomName, setSelectedRoom }) => {
    const room = roomDevices.find(r => r.name === roomName);
    const bgColors = [
      "from-purple-50 to-pink-50",
      "from-blue-50 to-cyan-50",
      "from-green-50 to-teal-50",
      "from-yellow-50 to-orange-50",
      "from-gray-50 to-blue-50"
    ];
    const bgColor = bgColors[roomDevices.findIndex(r => r.name === roomName) % bgColors.length];
    const [isMounted, setIsMounted] = useState(false);

    useEffect(() => {
      setIsMounted(true);
      return () => setIsMounted(false);
    }, []);

    return (
      <div className={`bg-gradient-to-br ${bgColor} min-h-[540px] relative overflow-y-auto`}>
        <div className="flex justify-between items-center p-4 text-black text-sm">
          <button onClick={() => setSelectedRoom(null)} className="text-blue-600">← Back</button>
          <span className="font-medium">{roomName} Control</span>
          <div className="flex items-center gap-1">
            <div className="w-4 h-2 bg-green-500 rounded-sm"></div>
            <span className="text-xs">100%</span>
          </div>
        </div>
        
        <div className="px-6 py-4">
          <div className="text-center mb-6">
            <h2 className="text-2xl font-bold text-gray-900">{roomName}</h2>
            <p className="text-gray-600">Smart device controls</p>
          </div>

          <div className="grid grid-cols-2 gap-3 mb-6">
            {room.devices.map((device, index) => (
              <div 
                key={index} 
                className={`bg-white rounded-2xl p-4 shadow-sm transition-all duration-500 ease-out ${
                  isMounted ? 'opacity-100 translate-y-0' : 'opacity-0 -translate-y-10'
                }`}
                style={{ transitionDelay: `${index * 100}ms` }}
              >
                <device.icon className={`h-6 w-6 ${device.color} mb-2`} />
                <p className="text-sm font-medium">{device.name}</p>
                <p className="text-xs text-gray-500">{device.status}</p>
                <button className={`mt-2 text-xs ${device.bgColor} ${device.color.replace('text-', 'text-')} px-2 py-1 rounded`}>
                  {device.action}
                </button>
              </div>
            ))}
          </div>

          <div className="bg-white rounded-2xl p-4 shadow-sm mb-4">
            <h4 className="font-medium text-gray-900 mb-3">Room Preferences</h4>
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">Auto lights at dusk</span>
                <div className="w-8 h-4 bg-blue-500 rounded-full relative">
                  <div className="w-3 h-3 bg-white rounded-full absolute top-0.5 right-0.5"></div>
                </div>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">Motion detection</span>
                <div className="w-8 h-4 bg-gray-300 rounded-full relative">
                  <div className="w-3 h-3 bg-white rounded-full absolute top-0.5 left-0.5"></div>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-2xl p-4 shadow-sm">
            <h4 className="font-medium text-gray-900 mb-3">Recent Activity</h4>
            <div className="space-y-2">
              <div className="flex justify-between items-center text-sm">
                <span className="text-gray-600">Device activated</span>
                <span className="text-gray-400">{currentTime}</span>
              </div>
              <div className="flex justify-between items-center text-sm">
                <span className="text-gray-600">Status changed</span>
                <span className="text-gray-400">2 min ago</span>
              </div>
              <div className="flex justify-between items-center text-sm">
                <span className="text-gray-600">Schedule updated</span>
                <span className="text-gray-400">07:30</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  };

  const LoginScreen = ({ setCurrentScreen }) => (
    <div className="bg-gradient-to-br from-blue-50 to-purple-50 min-h-[540px] relative">
      <div className="flex justify-between items-center p-4 text-black text-sm">
        <span className="font-medium">{currentTime}</span>
        <div className="flex items-center gap-1">
          <div className="w-4 h-2 bg-green-500 rounded-sm"></div>
          <span className="text-xs">100%</span>
        </div>
      </div>
      <div className="px-6 py-8">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-gray-900">Login</h2>
          <p className="text-gray-600 mt-2">Access your smart home</p>
        </div>
        <div className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
            <input
              type="text"
              placeholder="Enter your email"
              className="w-full px-4 py-3 rounded-lg bg-white border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Password</label>
            <input
              type="password"
              placeholder="Enter your password"
              className="w-full px-4 py-3 rounded-lg bg-white border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <button className="w-full bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700 transition-all flex items-center justify-center">
            <Key className="h-5 w-5 mr-2" />
            Sign In
          </button>
          <button
            className="w-full bg-gray-100 text-gray-900 py-3 rounded-lg font-semibold hover:bg-gray-200 transition-all flex items-center justify-center"
            onClick={() => setCurrentScreen("register")}
          >
            <User className="h-5 w-5 mr-2" />
            Create Account
          </button>
        </div>
        <button
          className="mt-4 text-blue-600 hover:underline text-sm"
          onClick={() => setCurrentScreen("home")}
        >
          Back to Home
        </button>
      </div>
    </div>
  );

  const RegisterScreen = ({ setCurrentScreen }) => (
    <div className="bg-gradient-to-br from-blue-50 to-purple-50 min-h-[540px] relative">
      <div className="flex justify-between items-center p-4 text-black text-sm">
        <span className="font-medium">{currentTime}</span>
        <div className="flex items-center gap-1">
          <div className="w-4 h-2 bg-green-500 rounded-sm"></div>
          <span className="text-xs">100%</span>
        </div>
      </div>
      <div className="px-6 py-8">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-gray-900">Register</h2>
          <p className="text-gray-600 mt-2">Join the smart home revolution</p>
        </div>
        <div className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Full Name</label>
            <input
              type="text"
              placeholder="Enter your full name"
              className="w-full px-4 py-3 rounded-lg bg-white border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
            <input
              type="email"
              placeholder="Enter your email"
              className="w-full px-4 py-3 rounded-lg bg-white border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Password</label>
            <input
              type="password"
              placeholder="Create a password"
              className="w-full px-4 py-3 rounded-lg bg-white border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <button className="w-full bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700 transition-all flex items-center justify-center">
            <User className="h-5 w-5 mr-2" />
            Sign Up
          </button>
        </div>
        <button
          className="mt-4 text-blue-600 hover:underline text-sm"
          onClick={() => setCurrentScreen("home")}
        >
          Back to Home
        </button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Halox Smart App | Control Your Smart Home</title>
        <meta
          name="description"
          content="Control your smart home with Halox Smart, India's most advanced IoT app. Privacy-first, secure, and built for Indian homes."
        />
        <link rel="canonical" href="/" />
        <script type="application/ld+json">{JSON.stringify(faqLd)}</script>
      </Helmet>

      <Header />

      <main>
        <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-gradient-to-br from-blue-600 via-purple-600 to-blue-800">
          <div className="absolute inset-0 opacity-10">
            <div className="absolute inset-0 bg-white/5 bg-[radial-gradient(circle_at_1px_1px,rgba(255,255,255,0.15)_1px,transparent_0)] bg-[length:20px_20px] animate-pulse"></div>
          </div>

          <div className="container mx-auto px-4 relative z-10">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <div className="text-center space-y-8">
                <div className="inline-flex items-center bg-white/20 text-white border border-white/30 backdrop-blur-sm rounded-full px-4 py-2 mx-auto">
                  <Smartphone className="h-3 w-3 mr-1" />
                  Made in India 🇮🇳
                </div>
                <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold text-white leading-tight">
                  Halox Smart
                  <span className="block text-orange-300">App</span>
                </h1>
                <p className="text-lg md:text-xl text-white/80 max-w-2xl mx-auto">
                  Control your entire smart home ecosystem with India's most advanced IoT app.
                  Privacy-first, secure, and built for Indian homes.
                </p>
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <button className="bg-orange-500 hover:bg-orange-600 text-white px-8 py-4 rounded-lg font-semibold shadow-lg transition-all flex items-center justify-center">
                    <Download className="mr-2 h-5 w-5" />
                    Download Now
                  </button>
                  <button className="border border-white text-white hover:bg-white hover:text-blue-600 px-8 py-4 rounded-lg font-semibold transition-all flex items-center justify-center">
                    <Play className="mr-2 h-5 w-5" />
                    Watch Demo
                  </button>
                </div>
                <div className="flex flex-col sm:flex-row gap-4 items-center justify-center pt-4">
                  <span className="text-white/60 text-sm">Available on:</span>
                  <div className="flex gap-3">
                    <button className="bg-white/10 hover:bg-white/20 text-white px-4 py-2 rounded-lg text-sm transition-all flex items-center">
                      <Download className="mr-2 h-4 w-4" />
                      Play Store
                    </button>
                    <button className="bg-white/10 hover:bg-white/20 text-white px-4 py-2 rounded-lg text-sm transition-all flex items-center">
                      <Download className="mr-2 h-4 w-4" />
                      App Store
                    </button>
                  </div>
                </div>
              </div>
              <div className="relative">
                <div className="relative mx-auto max-w-xs mt-6 translate-x-12">
                  <div className="relative bg-gray-900 rounded-[3rem] p-3 shadow-2xl">
                    <div className="bg-black rounded-[2.5rem] overflow-hidden">
                      {selectedRoom && <RoomControl roomName={selectedRoom} setSelectedRoom={setSelectedRoom} />}
                      {currentScreen === "home" && !selectedRoom && (
                        <HomeScreen
                          setCurrentScreen={setCurrentScreen}
                          lightStatus={lightStatus}
                          toggleLights={toggleLights}
                          securityStatus={securityStatus}
                          toggleSecurity={toggleSecurity}
                          setSelectedRoom={setSelectedRoom}
                        />
                      )}
                      {currentScreen === "login" && !selectedRoom && <LoginScreen setCurrentScreen={setCurrentScreen} />}
                      {currentScreen === "register" && !selectedRoom && <RegisterScreen setCurrentScreen={setCurrentScreen} />}
                    </div>
                  </div>
                  <div className="absolute -top-6 -right-6 bg-orange-500/20 backdrop-blur-sm rounded-full p-4 animate-bounce">
                    <Wifi className="h-6 w-6 text-orange-500" />
                  </div>
                  <div className="absolute -bottom-6 -left-6 bg-blue-500/20 backdrop-blur-sm rounded-full p-4 animate-pulse">
                    <Lock className="h-6 w-6 text-blue-500" />
                  </div>
                </div>
              </div>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mt-16 pt-8 border-t border-white/20">
              {[
                { label: "App Downloads", value: "2.5M+", icon: Download },
                { label: "Daily Active Users", value: "850K", icon: Users },
                { label: "App Rating", value: "4.8★", icon: Star },
                { label: "Countries", value: "15+", icon: Shield },
              ].map((stat) => (
                <div key={stat.label} className="text-center text-white">
                  <stat.icon className="h-6 w-6 mx-auto mb-2 text-orange-300" />
                  <div className="text-2xl font-bold">{stat.value}</div>
                  <div className="text-sm text-white/60">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section className="py-24 bg-white">
          <div className="container mx-auto px-4">
            <div className="text-center mb-16">
              <div className="inline-block mb-4 bg-blue-100 text-blue-600 px-4 py-2 rounded-full text-sm font-medium">
                Features
              </div>
              <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
                Everything you need in one app
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                From simple device control to advanced automation, our app puts the power of smart living at your fingertips.
              </p>
            </div>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {features.map((feature, index) => (
                <div
                  key={feature.title}
                  className="group bg-gradient-to-br from-white to-gray-50 rounded-3xl p-8 border border-gray-100 hover:border-transparent hover:shadow-2xl transition-all duration-500 hover:transform hover:-translate-y-2 cursor-pointer relative overflow-hidden"
                  onMouseEnter={() => setActiveFeature(index)}
                >
                  <div className="absolute inset-0 bg-gradient-to-br from-blue-600/5 via-purple-600/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                  <div
                    className={`${feature.color} w-16 h-16 rounded-2xl flex items-center justify-center mb-6 shadow-lg group-hover:shadow-xl transition-all duration-300 group-hover:scale-110 relative z-10`}
                  >
                    <feature.icon className="h-8 w-8 transition-transform duration-300 group-hover:scale-110" />
                    <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-white/20 to-transparent"></div>
                  </div>
                  <div className="relative z-10">
                    <h3 className="text-2xl font-bold text-gray-900 mb-4 group-hover:text-blue-700 transition-colors duration-300">
                      {feature.title}
                    </h3>
                    <p className="text-gray-600 mb-4 leading-relaxed group-hover:text-gray-700 transition-colors duration-300">
                      {feature.description}
                    </p>
                    <div className="inline-flex items-center gap-2 text-sm font-semibold px-4 py-2 bg-blue-50 text-blue-600 rounded-full group-hover:bg-blue-100 transition-all duration-300">
                      <div className="w-2 h-2 bg-blue-400 rounded-full animate-pulse"></div>
                      {feature.demo}
                    </div>
                  </div>
                  <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-br from-blue-400/10 to-purple-400/10 rounded-full transform translate-x-8 -translate-y-8 group-hover:scale-150 transition-transform duration-500"></div>
                  <div className="absolute bottom-0 left-0 w-16 h-16 bg-gradient-to-tr from-orange-400/10 to-pink-400/10 rounded-full transform -translate-x-4 translate-y-4 group-hover:scale-125 transition-transform duration-500"></div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Device Compatibility Section */}
        <section className="py-24 bg-gray-50">
          <div className="container mx-auto px-4">
            <div className="text-center mb-20">
              <div className="inline-flex items-center gap-2 mb-6 bg-gradient-to-r from-green-100 to-emerald-100 text-green-600 px-6 py-3 rounded-full text-sm font-semibold shadow-sm">
                <Settings className="h-4 w-4" />
                Device Compatibility
              </div>
              <h2 className="text-5xl md:text-6xl font-black text-gray-900 mb-6 leading-tight">
                Works with
                <span className="bg-gradient-to-r from-green-600 via-emerald-600 to-teal-600 bg-clip-text text-transparent"> 500+ smart devices</span>
              </h2>
              <p className="text-xl md:text-2xl text-gray-600 max-w-4xl mx-auto font-light leading-relaxed">
                From lights and fans to ACs and security cameras, control everything from one powerful app ecosystem.
              </p>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
              {[
                { icon: Sun, name: "Smart Lights", count: "150+", color: "from-yellow-400 to-orange-500" },
                { icon: Thermometer, name: "AC Units", count: "50+", color: "from-blue-400 to-cyan-500" },
                { icon: Camera, name: "Security Cams", count: "80+", color: "from-purple-400 to-pink-500" },
                { icon: Lock, name: "Smart Locks", count: "25+", color: "from-gray-400 to-gray-600" },
                { icon: Bell, name: "Doorbells", count: "15+", color: "from-green-400 to-emerald-500" },
                { icon: Battery, name: "Power Plugs", count: "180+", color: "from-red-400 to-rose-500" },
              ].map((device) => (
                <div
                  key={device.name}
                  className="group bg-white rounded-2xl p-6 text-center hover:shadow-2xl transition-all duration-500 hover:transform hover:-translate-y-3 cursor-pointer relative overflow-hidden border border-gray-100 hover:border-transparent"
                >
                  <div className={`absolute inset-0 bg-gradient-to-br ${device.color} opacity-0 group-hover:opacity-10 transition-opacity duration-500`}></div>
                  <div
                    className={`relative w-16 h-16 mx-auto mb-4 bg-gradient-to-br ${device.color} rounded-2xl flex items-center justify-center shadow-lg group-hover:shadow-xl transition-all duration-300 group-hover:scale-110`}
                  >
                    <device.icon className="h-8 w-8 text-white transition-transform duration-300 group-hover:scale-110" />
                    <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-white/20 to-transparent"></div>
                  </div>
                  <div className="relative z-10">
                    <h4 className="font-bold text-gray-900 mb-2 text-lg group-hover:text-xl transition-all duration-300">
                      {device.name}
                    </h4>
                    <div className="inline-flex items-center gap-2 px-3 py-1 bg-gray-100 rounded-full group-hover:bg-gradient-to-r group-hover:from-gray-100 group-hover:to-gray-50 transition-all duration-300">
                      <div className={`w-2 h-2 bg-gradient-to-r ${device.color} rounded-full`}></div>
                      <span className="text-sm font-semibold text-gray-600">{device.count} models</span>
                    </div>
                  </div>
                  <div
                    className={`absolute top-0 right-0 w-8 h-8 bg-gradient-to-br ${device.color} opacity-20 transform rotate-45 translate-x-4 -translate-y-4 group-hover:scale-150 transition-transform duration-500`}
                  ></div>
                </div>
              ))}
            </div>
            <div className="text-center mt-12">
              <button className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 rounded-lg font-semibold transition-all inline-flex items-center">
                View All Compatible Devices
                <ArrowRight className="ml-2 h-4 w-4" />
              </button>
            </div>
          </div>
        </section>

        {/* How It Works Section */}
        <section className="py-24 bg-white">
          <div className="container mx-auto px-4">
            <div className="text-center mb-20">
              <div className="inline-flex items-center gap-2 mb-6 bg-gradient-to-r from-purple-100 to-indigo-100 text-purple-600 px-6 py-3 rounded-full text-sm font-semibold shadow-sm">
                <Play className="h-4 w-4" />
                Simple Process
              </div>
              <h2 className="text-5xl md:text-6xl font-black text-gray-900 mb-6 leading-tight">
                Get started in
                <span className="bg-gradient-to-r from-purple-600 via-indigo-600 to-purple-800 bg-clip-text text-transparent"> 3 simple steps</span>
              </h2>
              <p className="text-xl md:text-2xl text-gray-600 max-w-4xl mx-auto font-light leading-relaxed">
                Transform your home into a smart sanctuary in minutes, not hours.
              </p>
            </div>
            <div className="grid md:grid-cols-3 gap-12 relative">
              <div className="hidden md:block absolute top-20 left-1/3 right-1/3 h-0.5 bg-gradient-to-r from-blue-200 via-green-200 to-purple-200"></div>
              {[
                {
                  step: "01",
                  title: "Download & Setup",
                  description: "Download the Halox Smart app and create your account in under 2 minutes with our streamlined onboarding.",
                  icon: Download,
                  color: "from-blue-400 to-blue-600",
                  bgColor: "from-blue-50 to-blue-100",
                },
                {
                  step: "02",
                  title: "Add Devices",
                  description: "Connect your smart devices using our intelligent auto-discovery feature that finds all compatible devices instantly.",
                  icon: Zap,
                  color: "from-green-400 to-green-600",
                  bgColor: "from-green-50 to-green-100",
                },
                {
                  step: "03",
                  title: "Start Controlling",
                  description: "Control your entire home with voice commands, smart schedules, or intuitive manual controls from anywhere.",
                  icon: Home,
                  color: "from-purple-400 to-purple-600",
                  bgColor: "from-purple-50 to-purple-100",
                },
              ].map((step, index) => (
                <div key={step.step} className="text-center group relative">
                  <div
                    className={`bg-gradient-to-br ${step.bgColor} rounded-3xl p-8 hover:shadow-2xl transition-all duration-500 hover:transform hover:-translate-y-2 border border-gray-100`}
                  >
                    <div className="relative mb-8">
                      <div
                        className={`w-20 h-20 mx-auto bg-gradient-to-br ${step.color} rounded-2xl flex items-center justify-center shadow-xl group-hover:shadow-2xl transition-all duration-300 group-hover:scale-110`}
                      >
                        <step.icon className="h-10 w-10 text-white transition-transform duration-300 group-hover:scale-110" />
                        <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-white/20 to-transparent"></div>
                      </div>
                      <div
                        className={`absolute -top-3 -right-3 w-10 h-10 bg-gradient-to-br ${step.color} text-white text-sm font-black rounded-full flex items-center justify-center shadow-lg border-4 border-white`}
                      >
                        {step.step}
                      </div>
                    </div>
                    <h3 className="text-2xl font-black text-gray-900 mb-4 group-hover:scale-105 transition-transform duration-300">
                      {step.title}
                    </h3>
                    <p className="text-gray-600 leading-relaxed group-hover:text-gray-700 transition-colors duration-300">
                      {step.description}
                    </p>
                    <div
                      className={`absolute top-4 right-4 w-12 h-12 bg-gradient-to-br ${step.color} opacity-10 rounded-full group-hover:scale-150 transition-transform duration-500`}
                    ></div>
                    <div
                      className={`absolute bottom-4 left-4 w-8 h-8 bg-gradient-to-tr ${step.color} opacity-10 rounded-full group-hover:scale-125 transition-transform duration-500`}
                    ></div>
                  </div>
                  {index < 2 && (
                    <div className="hidden md:block absolute top-20 -right-6 z-10">
                      <ArrowRight className="h-8 w-8 text-gray-300 group-hover:text-gray-400 transition-colors duration-300" />
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Testimonials Section */}
        <section className="py-24 bg-gray-50">
          <div className="container mx-auto px-4">
            <div className="text-center mb-20">
              <div className="inline-flex items-center gap-2 mb-6 bg-gradient-to-r from-orange-100 to-yellow-100 text-orange-600 px-6 py-3 rounded-full text-sm font-semibold shadow-sm">
                <Heart className="h-4 w-4" />
                Customer Love
              </div>
              <h2 className="text-5xl md:text-6xl font-black text-gray-900 mb-6 leading-tight">
                Loved by
                <span className="bg-gradient-to-r from-orange-600 via-red-600 to-pink-600 bg-clip-text text-transparent"> millions of Indians</span>
              </h2>
              <p className="text-xl md:text-2xl text-gray-600 max-w-4xl mx-auto font-light leading-relaxed">
                See what our happy customers have to say about their smart home transformation journey.
              </p>
            </div>
            <div className="grid md:grid-cols-3 gap-8">
              {testimonials.map((testimonial, index) => (
                <div
                  key={index}
                  className="group bg-white rounded-3xl p-8 shadow-sm hover:shadow-2xl transition-all duration-500 hover:transform hover:-translate-y-2 border border-gray-100 hover:border-transparent relative overflow-hidden"
                >
                  <div className="absolute inset-0 bg-gradient-to-br from-orange-50/50 via-yellow-50/30 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                  <div className="absolute top-6 right-6 w-12 h-12 bg-gradient-to-br from-orange-100 to-yellow-100 rounded-full flex items-center justify-center opacity-20 group-hover:opacity-40 transition-opacity duration-300">
                    <MessageSquare className="h-6 w-6 text-orange-500" />
                  </div>
                  <div className="relative z-10">
                    <div className="flex items-center mb-6 gap-1">
                      {[...Array(testimonial.rating)].map((_, i) => (
                        <div key={i} className="relative">
                          <Star className="h-6 w-6 text-yellow-400 fill-current transition-transform duration-300 hover:scale-125" />
                          <div className="absolute inset-0 animate-pulse">
                            <Star className="h-6 w-6 text-yellow-300 fill-current opacity-50" />
                          </div>
                        </div>
                      ))}
                    </div>
                    <p className="text-gray-700 mb-8 italic leading-relaxed text-lg group-hover:text-gray-800 transition-colors duration-300 relative">
                      <span className="text-4xl text-orange-300 absolute -top-2 -left-2 font-serif">"</span>
                      {testimonial.text}
                      <span className="text-4xl text-orange-300 absolute -bottom-4 -right-2 font-serif">"</span>
                    </p>
                    <div className="flex items-center">
                      <div className="w-14 h-14 bg-gradient-to-br from-blue-400 to-purple-500 rounded-full flex items-center justify-center text-white font-bold text-lg mr-4 shadow-lg group-hover:shadow-xl transition-shadow duration-300">
                        {testimonial.avatar}
                      </div>
                      <div>
                        <h4 className="font-bold text-gray-900 text-lg group-hover:text-blue-700 transition-colors duration-300">
                          {testimonial.name}
                        </h4>
                        <div className="flex items-center gap-2">
                          <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                          <p className="text-gray-500 text-sm font-medium">{testimonial.location}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="absolute bottom-0 left-0 w-16 h-16 bg-gradient-to-tr from-orange-400/10 to-yellow-400/10 rounded-full transform -translate-x-8 translate-y-8 group-hover:scale-150 transition-transform duration-500"></div>
                </div>
              ))}
            </div>
            <div className="text-center mt-12">
              <div className="flex items-center justify-center gap-8 text-gray-600">
                <div className="flex items-center">
                  <TrendingUp className="h-5 w-5 mr-2" />
                  <span>4.8/5 Average Rating</span>
                </div>
                <div className="flex items-center">
                  <MessageSquare className="h-5 w-5 mr-2" />
                  <span>50K+ Reviews</span>
                </div>
                <div className="flex items-center">
                  <Heart className="h-5 w-5 mr-2" />
                  <span>98% Satisfaction</span>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* FAQ Section */}
        <section className="py-24 bg-white">
          <div className="container mx-auto px-4 max-w-4xl">
            <div className="text-center mb-16">
              <div className="inline-block mb-4 bg-indigo-100 text-indigo-600 px-4 py-2 rounded-full text-sm font-medium">
                FAQ
              </div>
              <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
                Frequently Asked Questions
              </h2>
              <p className="text-xl text-gray-600">
                Everything you need to know about Halox Smart app.
              </p>
            </div>
            <Accordion type="single" collapsible className="w-full">
              {faqs.map((faq, index) => (
                <AccordionItem key={index} value={`item-${index}`}>
                  <AccordionTrigger>{faq.question}</AccordionTrigger>
                  <AccordionContent>{faq.answer}</AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </div>
        </section>

        {/* Download CTA Section */}
        <section className="py-24 bg-gradient-to-br from-blue-600 via-purple-600 to-blue-800 text-white">
          <div className="container mx-auto px-4 text-center">
            <div className="max-w-3xl mx-auto space-y-8">
              <h2 className="text-4xl md:text-5xl font-bold">
                Ready to make your home smart?
              </h2>
              <p className="text-xl text-white/80">
                Join millions of Indians who trust Halox Smart for their connected homes.
                Download the app today and experience the future of living.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <button className="bg-white text-blue-600 hover:bg-gray-100 px-8 py-4 rounded-lg font-semibold shadow-lg transition-all inline-flex items-center justify-center">
                  <Download className="mr-2 h-5 w-5" />
                  Download for Android
                </button>
                <button className="border border-white text-white hover:bg-white hover:text-blue-600 px-8 py-4 rounded-lg font-semibold transition-all inline-flex items-center justify-center">
                  <Download className="mr-2 h-5 w-5" />
                  Download for iOS
                </button>
              </div>
              <div className="flex flex-wrap justify-center items-center gap-8 pt-8 opacity-80">
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-5 w-5" />
                  <span>Free Download</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-5 w-5" />
                  <span>No Ads</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-5 w-5" />
                  <span>Regular Updates</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-5 w-5" />
                  <span>24/7 Support</span>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
};

export default AppPage;