import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Search,
  Home,
  Star,
  Mail,
  ArrowRight,
  Heart,
  MessageSquare,
  Play,
} from "lucide-react";
import { Link } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { motion } from "framer-motion";

const blogPosts = [
  {
    id: 1,
    title: "The Future of Smart Homes in 2025",
    excerpt: "Explore the latest trends in smart home technology.",
    category: "Smart Home",
    date: "August 20, 2025",
    thumbnail: "https://via.placeholder.com/300x200",
  },
  {
    id: 2,
    title: "IoT Innovations for Energy Saving",
    excerpt: "Learn how IoT can reduce your energy bills.",
    category: "IoT",
    date: "August 18, 2025",
    thumbnail: "https://via.placeholder.com/300x200",
  },
  {
    id: 3,
    title: "Top 5 Smart Devices of the Year",
    excerpt: "Discover the best smart devices for your home.",
    category: "Tech",
    date: "August 15, 2025",
    thumbnail: "https://via.placeholder.com/300x200",
  },
  {
    id: 4,
    title: "Building a Sustainable Smart Home",
    excerpt: "Tips for creating an eco-friendly smart home.",
    category: "Sustainability",
    date: "August 12, 2025",
    thumbnail: "https://via.placeholder.com/300x200",
  },
];

const testimonials = [
  {
    name: "Amit Sharma",
    location: "Delhi",
    rating: 5,
    text: "Great insights on smart living! Highly recommend this blog.",
    avatar: "AS",
  },
  {
    name: "Priya Patel",
    location: "Mumbai",
    rating: 4,
    text: "Love the practical tips for home automation.",
    avatar: "PP",
  },
  {
    name: "Rohit Verma",
    location: "Bangalore",
    rating: 5,
    text: "The blog is a must-read for tech enthusiasts!",
    avatar: "RV",
  },
];

const Blog = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    setIsVisible(true);
  }, []);

  const filteredPosts = blogPosts.filter((post) =>
    post.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    post.excerpt.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-gray-50">
      <Helmet>
        <title>Smart Living Blog | Latest Insights</title>
        <meta
          name="description"
          content="Explore the latest insights on smart home technology and IoT innovations."
        />
        <link rel="canonical" href="/blog" />
      </Helmet>

      <Header />

      {/* Hero Section (Inspired by "Enjoy Your Dream Vacation") */}
      <section className="relative min-h-[60vh] flex items-center bg-gradient-to-r from-green-400 via-blue-500 to-purple-600 overflow-hidden">
        <div className="absolute inset-0 bg-[url('https://via.placeholder.com/1920x1080')] bg-cover bg-center opacity-20" />
        <div className="container mx-auto px-6 text-center lg:text-left grid lg:grid-cols-2 gap-12 z-10">
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1 }}
            className="space-y-6"
          >
            <span className="inline-flex items-center bg-white/20 text-white px-4 py-2 rounded-full text-sm">
              <Home className="h-4 w-4 mr-2" /> Smart Living
            </span>
            <h1 className="text-5xl md:text-6xl font-bold text-white leading-tight">
              Explore Smart <br />
              <span className="bg-gradient-to-r from-yellow-400 to-orange-500 bg-clip-text text-transparent">
                Living Insights
              </span>
            </h1>
            <p className="text-lg text-gray-200 max-w-xl">
              Stay updated with the latest trends in smart home technology and IoT.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 mt-6">
              <Link to="/blog/latest">
                <Button className="bg-yellow-500 hover:bg-yellow-600 text-white px-6 py-3 rounded-lg">
                  Latest Posts <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
              <Link to="/subscribe">
                <Button className="border border-white text-white hover:bg-white hover:text-yellow-600 px-6 py-3 rounded-lg">
                  <Mail className="mr-2 h-5 w-5" /> Subscribe
                </Button>
              </Link>
            </div>
            <div className="relative max-w-md mt-6">
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search blog posts..."
                className="w-full px-4 py-2 rounded-lg border border-white/30 bg-white/10 text-white placeholder-gray-300 focus:ring-2 focus:ring-yellow-400"
              />
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-white/70 h-5 w-5" />
            </div>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1, delay: 0.3 }}
            className="relative flex justify-center lg:justify-end"
          >
            <div className="bg-white/10 backdrop-blur-md rounded-xl p-6 shadow-lg max-w-sm">
              <h2 className="text-xl font-semibold text-white mb-4">Featured Posts</h2>
              <ul className="space-y-3">
                {blogPosts.slice(0, 3).map((post) => (
                  <li key={post.id} className="flex items-center gap-2 text-white/80">
                    <Star className="h-4 w-4 text-yellow-400" />
                    <span className="text-sm">{post.title}</span>
                  </li>
                ))}
              </ul>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Blog Posts Section (Inspired by "Entire city of choice") */}
      <section className="py-12 bg-white">
        <div className="container mx-auto px-6">
          <h2 className="text-4xl font-bold text-gray-900 text-center mb-8">
            Latest
            <span className="bg-gradient-to-r from-green-400 via-blue-500 to-purple-600 bg-clip-text text-transparent">
              {" "}
              Blog Posts
            </span>
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredPosts.length === 0 ? (
              <p className="text-center text-gray-600 col-span-full">No posts found.</p>
            ) : (
              filteredPosts.map((post) => (
                <motion.div
                  key={post.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5 }}
                  className="bg-white rounded-xl p-4 shadow-md hover:shadow-lg transition-shadow border border-gray-200"
                >
                  <img
                    src={post.thumbnail}
                    alt={post.title}
                    className="w-full h-40 object-cover rounded-lg mb-4"
                  />
                  <Badge className="bg-blue-100 text-blue-600 mb-2">{post.category}</Badge>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">{post.title}</h3>
                  <p className="text-sm text-gray-600 mb-4">{post.excerpt}</p>
                  <p className="text-xs text-gray-500 mb-4">{post.date}</p>
                  <Link to={`/blog/${post.id}`}>
                    <Button className="bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded-lg w-full">
                      Read More
                    </Button>
                  </Link>
                </motion.div>
              ))
            )}
          </div>
        </div>
      </section>

      {/* Testimonials Section (Inspired by "Resort Surprises") */}
      <section className="py-12 bg-gray-50">
        <div className="container mx-auto px-6">
          <h2 className="text-4xl font-bold text-gray-900 text-center mb-8">
            Reader
            <span className="bg-gradient-to-r from-green-400 via-blue-500 to-purple-600 bg-clip-text text-transparent">
              {" "}
              Favorites
            </span>
          </h2>
          <div className="flex flex-col md:flex-row items-center justify-center gap-8">
            <div className="w-full md:w-1/2 space-y-4">
              <h3 className="text-xl font-semibold text-gray-800">What Readers Say</h3>
              <ul className="space-y-2 text-gray-600">
                <li className="flex items-center gap-2"><Heart className="h-5 w-5 text-red-500" /> Insightful Content</li>
                <li className="flex items-center gap-2"><Heart className="h-5 w-5 text-red-500" /> Easy to Follow</li>
                <li className="flex items-center gap-2"><Heart className="h-5 w-5 text-red-500" /> Innovative Ideas</li>
              </ul>
            </div>
            <div className="w-full md:w-1/2">
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5 }}
                className="bg-white/10 backdrop-blur-md rounded-xl p-6 shadow-lg"
              >
                <img
                  src="https://via.placeholder.com/400x300"
                  alt="Reader Favorite"
                  className="w-full h-48 object-cover rounded-lg mb-4"
                />
                <div className="flex justify-end space-x-2 mb-4">
                  <button className="bg-gray-200 p-2 rounded-full"><Play className="h-5 w-5 text-gray-700" /></button>
                  <button className="bg-gray-200 p-2 rounded-full"><Heart className="h-5 w-5 text-gray-700" /></button>
                </div>
                <p className="text-sm text-gray-600 text-center">Play Your Favorite</p>
              </motion.div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section (Inspired by "Search for other Top Airlines" and "Get better work") */}
      <section className="py-12 bg-gradient-to-r from-green-400 via-blue-500 to-purple-600 text-white">
        <div className="container mx-auto px-6 text-center">
          <h2 className="text-4xl font-bold mb-6">Stay Informed</h2>
          <p className="text-lg mb-8 max-w-xl mx-auto">
            Subscribe to get the latest smart living tips and trends delivered to your inbox.
          </p>
          <Link to="/subscribe">
            <Button className="bg-white text-green-600 hover:bg-gray-100 px-6 py-3 rounded-lg">
              Subscribe Now <Mail className="ml-2 h-5 w-5" />
            </Button>
          </Link>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Blog;